plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.perso.stopapp"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.perso.stopapp"
        minSdk = 26
        targetSdk = 35
        versionCode = 5
        versionName = "2.0"
    }

    // Signature fixe : les mises à jour s'installent par-dessus sans désinstaller
    signingConfigs {
        create("perso") {
            storeFile = file("stopapp.keystore")
            storePassword = "stopapp123"
            keyAlias = "stopapp"
            keyPassword = "stopapp123"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("perso")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("perso")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
}
