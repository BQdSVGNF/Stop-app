package com.perso.stopapp

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent

/**
 * Protection anti-désinstallation : tant que stop#app est « administrateur de l'appareil »,
 * Android refuse de le désinstaller. Pour l'enlever, il faut passer par le questionnaire
 * de stop#app (qui retire lui-même cette protection à la fin).
 * Aucune règle n'est imposée au téléphone : c'est uniquement un verrou de désinstallation.
 */
class StopAdmin : DeviceAdminReceiver() {

    companion object {
        fun component(c: Context) = ComponentName(c, StopAdmin::class.java)

        fun isActive(c: Context): Boolean =
            (c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager).isAdminActive(component(c))

        /** Retire la protection (appelé seulement à la fin du questionnaire). */
        fun remove(c: Context) {
            runCatching {
                (c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager).removeActiveAdmin(component(c))
            }
        }

        /** Écran Android qui demande d'activer la protection. */
        fun activationIntent(c: Context): Intent =
            Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, component(c))
                .putExtra(
                    DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                    "Empêche de désinstaller stop#app sur un coup de tête. Pour l'enlever, " +
                        "il faudra passer par le questionnaire de stop#app."
                )
    }

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        "Passe plutôt par stop#app : le questionnaire retire cette protection proprement."
}
