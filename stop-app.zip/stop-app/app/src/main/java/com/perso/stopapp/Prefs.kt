package com.perso.stopapp

import android.content.Context
import java.util.Calendar

/** Stockage des réglages de stop#app. */
object Prefs {
    private const val FILE = "stopapp"
    private const val KEY_STARTED = "started"
    private const val KEY_ALLOWED = "allowed_apps"
    private const val KEY_SITES = "blocked_sites"
    private const val KEY_FREE = "free_windows"            // semaine (lundi → vendredi)
    private const val KEY_FREE_WE = "free_windows_weekend" // week-end (samedi, dimanche)
    private const val KEY_UNLOCK_AT = "unlock_requested_at"
    private const val KEY_EDIT_UNTIL = "edit_until"

    /** Attente avant de pouvoir modifier pendant le blocage : 5 minutes. */
    const val WAIT_MS = 5 * 60 * 1000L
    /** Durée max du mode modification avant reblocage automatique : 10 minutes. */
    const val EDIT_MS = 10 * 60 * 1000L

    /** Créneaux libres par défaut (non bloqués). */
    val DEFAULT_FREE = setOf("06:00-08:55", "15:30-17:30")
    val DEFAULT_FREE_WEEKEND = setOf("10:00-12:00", "15:00-19:00")

    private fun sp(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    /** false tant que l'utilisateur n'a pas appuyé une première fois sur « Démarrer ». */
    fun isStarted(c: Context) = sp(c).getBoolean(KEY_STARTED, false)
    fun setStarted(c: Context, v: Boolean) = sp(c).edit().putBoolean(KEY_STARTED, v).apply()

    fun allowedApps(c: Context): Set<String> = sp(c).getStringSet(KEY_ALLOWED, emptySet())!!.toSet()
    fun setAllowedApps(c: Context, v: Set<String>) = sp(c).edit().putStringSet(KEY_ALLOWED, v.toSet()).apply()

    fun blockedSites(c: Context): Set<String> = sp(c).getStringSet(KEY_SITES, emptySet())!!.toSet()
    fun setBlockedSites(c: Context, v: Set<String>) = sp(c).edit().putStringSet(KEY_SITES, v.toSet()).apply()

    /** Créneaux libres de la semaine (weekend = false) ou du week-end (weekend = true). */
    fun freeWindows(c: Context, weekend: Boolean = false): Set<String> =
        if (weekend) sp(c).getStringSet(KEY_FREE_WE, DEFAULT_FREE_WEEKEND)!!.toSet()
        else sp(c).getStringSet(KEY_FREE, DEFAULT_FREE)!!.toSet()

    fun setFreeWindows(c: Context, v: Set<String>, weekend: Boolean = false) =
        sp(c).edit().putStringSet(if (weekend) KEY_FREE_WE else KEY_FREE, v.toSet()).apply()

    fun unlockRequestedAt(c: Context) = sp(c).getLong(KEY_UNLOCK_AT, 0L)
    fun setUnlockRequestedAt(c: Context, v: Long) = sp(c).edit().putLong(KEY_UNLOCK_AT, v).apply()

    fun editUntil(c: Context) = sp(c).getLong(KEY_EDIT_UNTIL, 0L)
    fun setEditUntil(c: Context, v: Long) = sp(c).edit().putLong(KEY_EDIT_UNTIL, v).apply()

    // ---------- Horaires ----------

    /** "06:00-08:55" -> (360, 535) en minutes depuis minuit. */
    fun parseWindow(w: String): Pair<Int, Int>? = runCatching {
        val (a, b) = w.split("-")
        fun m(s: String) = s.trim().split(":").let { it[0].toInt() * 60 + it[1].toInt() }
        m(a) to m(b)
    }.getOrNull()

    fun nowMinutes(): Int {
        val cal = Calendar.getInstance()
        return cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
    }

    // ---------- Semaine / week-end ----------

    private fun isWeekend(cal: Calendar): Boolean {
        val d = cal.get(Calendar.DAY_OF_WEEK)
        return d == Calendar.SATURDAY || d == Calendar.SUNDAY
    }

    /** Sommes-nous samedi ou dimanche ? */
    fun isWeekendToday(): Boolean = isWeekend(Calendar.getInstance())

    /** Les créneaux libres qui s'appliquent au jour décalé de [dayOffset] (0 = aujourd'hui). */
    private fun windowsForDay(c: Context, dayOffset: Int): Set<String> {
        val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, dayOffset) }
        return freeWindows(c, isWeekend(cal))
    }

    private val dayNames = listOf("dimanche", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi")

    /**
     * Créneau libre en cours (ou null), selon le jour : horaires de semaine du lundi au vendredi,
     * horaires du week-end le samedi et le dimanche.
     * Un créneau qui passe minuit (ex. 22:00-07:00) compte pour le jour où il commence.
     */
    fun currentFreeWindow(c: Context, now: Int = nowMinutes()): String? {
        windowsForDay(c, 0).firstOrNull { w ->
            val (s, e) = parseWindow(w) ?: return@firstOrNull false
            if (s <= e) now in s until e else now >= s
        }?.let { return it }
        // Fin d'un créneau de nuit commencé hier
        return windowsForDay(c, -1).firstOrNull { w ->
            val (s, e) = parseWindow(w) ?: return@firstOrNull false
            s > e && now < e
        }
    }

    /** Prochain début de créneau libre : (minutes d'attente, libellé comme "15:30" ou "samedi 10:00"). */
    private fun nextFree(c: Context, now: Int = nowMinutes()): Pair<Int, String>? {
        for (offset in 0..7) {
            val starts = windowsForDay(c, offset).mapNotNull { parseWindow(it)?.first }
                .map { offset * 1440 + it }
                .filter { it > now }
            val first = starts.minOrNull() ?: continue
            val m = first % 1440
            val hhmm = "%02d:%02d".format(m / 60, m % 60)
            val label = when (offset) {
                0 -> hhmm
                1 -> "demain $hhmm"
                else -> {
                    val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, offset) }
                    "${dayNames[cal.get(Calendar.DAY_OF_WEEK) - 1]} $hhmm"
                }
            }
            return (first - now) to label
        }
        return null
    }

    /** Prochain début de créneau libre, ex. "15:30" ou "demain 06:00". */
    fun nextFreeStart(c: Context, now: Int = nowMinutes()): String? = nextFree(c, now)?.second

    fun inEditMode(c: Context) = System.currentTimeMillis() < editUntil(c)

    // ---------- Pause bonus : 20 minutes, une seule fois par jour ----------

    const val PASS_MS = 20 * 60 * 1000L
    private const val KEY_PASS_DAY = "pass_day"
    private const val KEY_PASS_UNTIL = "pass_until"

    fun today(): String {
        val c = Calendar.getInstance()
        return "%04d%02d%02d".format(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
    }

    private fun yesterday(): String {
        val c = Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, -1) }
        return "%04d%02d%02d".format(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
    }

    fun passUntil(c: Context) = sp(c).getLong(KEY_PASS_UNTIL, 0L)
    fun inPass(c: Context) = System.currentTimeMillis() < passUntil(c)
    fun passUsedToday(c: Context) = sp(c).getString(KEY_PASS_DAY, "") == today()

    /** Lance la pause bonus si elle n'a pas déjà été utilisée aujourd'hui. */
    fun startPass(c: Context): Boolean {
        if (passUsedToday(c)) return false
        sp(c).edit()
            .putString(KEY_PASS_DAY, today())
            .putLong(KEY_PASS_UNTIL, System.currentTimeMillis() + PASS_MS)
            .apply()
        return true
    }

    /** Termine la pause bonus en avance (elle reste comptée comme utilisée). */
    fun endPass(c: Context) = sp(c).edit().putLong(KEY_PASS_UNTIL, 0L).apply()

    // ---------- Statistiques ----------

    private const val KEY_STAT_DAY = "stat_day"
    private const val KEY_BLOCKS_TODAY = "blocks_today"
    private const val KEY_BLOCKS_TOTAL = "blocks_total"
    private const val KEY_STREAK = "streak"
    private const val KEY_STREAK_DAY = "streak_day"

    /** Minutes gagnées estimées pour chaque tentative bloquée. */
    const val MINUTES_PER_BLOCK = 5

    private fun rollDay(c: Context) {
        val t = today()
        if (sp(c).getString(KEY_STAT_DAY, "") != t) {
            sp(c).edit().putString(KEY_STAT_DAY, t).putInt(KEY_BLOCKS_TODAY, 0).apply()
        }
    }

    fun blocksToday(c: Context): Int { rollDay(c); return sp(c).getInt(KEY_BLOCKS_TODAY, 0) }
    fun blocksTotal(c: Context) = sp(c).getInt(KEY_BLOCKS_TOTAL, 0)

    fun addBlock(c: Context) {
        rollDay(c)
        sp(c).edit()
            .putInt(KEY_BLOCKS_TODAY, sp(c).getInt(KEY_BLOCKS_TODAY, 0) + 1)
            .putInt(KEY_BLOCKS_TOTAL, sp(c).getInt(KEY_BLOCKS_TOTAL, 0) + 1)
            .apply()
    }

    private const val KEY_BEST_STREAK = "best_streak"
    private const val KEY_DAYS_TOTAL = "days_total"

    /** Nombre de jours d'affilée où stop#app a protégé le téléphone. */
    fun streak(c: Context): Int {
        if (!isStarted(c)) return 0
        val t = today()
        val last = sp(c).getString(KEY_STREAK_DAY, "")
        var s = sp(c).getInt(KEY_STREAK, 0)
        if (last != t) {
            s = if (last == yesterday()) s + 1 else 1
            sp(c).edit()
                .putString(KEY_STREAK_DAY, t)
                .putInt(KEY_STREAK, s)
                .putInt(KEY_DAYS_TOTAL, sp(c).getInt(KEY_DAYS_TOTAL, 0) + 1)
                .putInt(KEY_BEST_STREAK, maxOf(s, sp(c).getInt(KEY_BEST_STREAK, 0)))
                .apply()
        }
        return s
    }

    fun bestStreak(c: Context): Int { streak(c); return sp(c).getInt(KEY_BEST_STREAK, 0) }
    fun daysTotal(c: Context): Int { streak(c); return sp(c).getInt(KEY_DAYS_TOTAL, 0) }

    // ---------- Mode Focus : tout est bloqué, même pendant un créneau libre ----------

    private const val KEY_FOCUS_UNTIL = "focus_until"
    private const val KEY_FOCUS_SESSIONS = "focus_sessions"
    private const val KEY_FOCUS_MINUTES = "focus_minutes"
    private const val KEY_FOCUS_TOTAL = "focus_total_ms"

    /** Durée totale de la session Focus en cours (pour l'anneau de progression). */
    fun focusTotalMs(c: Context) = sp(c).getLong(KEY_FOCUS_TOTAL, 1L).coerceAtLeast(1L)

    fun focusUntil(c: Context) = sp(c).getLong(KEY_FOCUS_UNTIL, 0L)
    fun inFocus(c: Context) = System.currentTimeMillis() < focusUntil(c)
    fun focusSessions(c: Context) = sp(c).getInt(KEY_FOCUS_SESSIONS, 0)
    fun focusMinutes(c: Context) = sp(c).getInt(KEY_FOCUS_MINUTES, 0)

    /** Lance une session Focus de [minutes]. Impossible de l'annuler une fois lancée. */
    fun startFocus(c: Context, minutes: Int) {
        sp(c).edit()
            .putLong(KEY_FOCUS_UNTIL, System.currentTimeMillis() + minutes * 60_000L)
            .putLong(KEY_FOCUS_TOTAL, minutes * 60_000L)
            .putInt(KEY_FOCUS_SESSIONS, focusSessions(c) + 1)
            .putInt(KEY_FOCUS_MINUTES, focusMinutes(c) + minutes)
            .putLong(KEY_PASS_UNTIL, 0L)   // une pause bonus en cours s'arrête
            .putLong(KEY_EDIT_UNTIL, 0L)   // le mode modification aussi
            .putLong(KEY_UNLOCK_AT, 0L)
            .apply()
    }

    // ---------- Badges déjà annoncés ----------

    private const val KEY_BADGES_SEEN = "badges_seen"
    fun badgesSeen(c: Context): Set<String> = sp(c).getStringSet(KEY_BADGES_SEEN, emptySet())!!.toSet()
    fun setBadgesSeen(c: Context, v: Set<String>) = sp(c).edit().putStringSet(KEY_BADGES_SEEN, v.toSet()).apply()

    // ---------- Désinstallation ----------

    private const val KEY_UNINSTALL_OK = "uninstall_ok_until"
    fun uninstallAllowed(c: Context) = System.currentTimeMillis() < sp(c).getLong(KEY_UNINSTALL_OK, 0L)
    fun allowUninstallFor(c: Context, ms: Long) =
        sp(c).edit().putLong(KEY_UNINSTALL_OK, System.currentTimeMillis() + ms).apply()

    /** Le blocage s'applique-t-il en ce moment ? */
    fun isBlockingNow(c: Context): Boolean =
        inFocus(c) || (isStarted(c) && currentFreeWindow(c) == null && !inEditMode(c) && !inPass(c))

    /** Minutes avant le prochain créneau libre (ou null). */
    fun minutesToNextFree(c: Context, now: Int = nowMinutes()): Int? = nextFree(c, now)?.first

    /** Peut-on modifier les réglages en ce moment ? */
    fun canEdit(c: Context) = !inFocus(c) &&
        (!isStarted(c) || currentFreeWindow(c) != null || inEditMode(c))  // la pause bonus ne donne pas accès aux réglages

    /** Nettoie une saisie : "https://www.YouTube.com/watch" -> "youtube.com" */
    fun normalizeSite(raw: String): String =
        raw.trim().lowercase()
            .removePrefix("https://").removePrefix("http://")
            .removePrefix("www.")
            .substringBefore("/")
            .trim()
}
