package com.perso.stopapp

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

/**
 * Blocage d'une PARTIE d'application :
 * - Snapchat : messages et caméra OK ; onglets Stories et Spotlight bloqués ;
 *   une story ou un snap reçu peut être regardé 30 secondes maximum.
 * - YouTube : vidéos OK ; Shorts bloqués.
 *
 * Fonctionne en lisant les boutons affichés à l'écran (comme le ferait un lecteur d'écran).
 * Si Snapchat ou YouTube renomment leurs boutons, il faudra ajuster les mots ci-dessous.
 */
class PartialBlocker(private val service: AccessibilityService) {

    companion object {
        const val SNAPCHAT = "com.snapchat.android"
        const val YOUTUBE = "com.google.android.youtube"
        val PACKAGES = setOf(SNAPCHAT, YOUTUBE)

        /** Durée max pour regarder une story / un snap reçu. */
        const val STORY_MAX_MS = 30_000L
    }

    private var lastCheck = 0L
    private var lastAction = 0L
    private var viewerSince = 0L
    private var lastDiag = 0L

    /** À appeler à chaque événement venant de Snapchat ou YouTube. */
    fun onEvent(pkg: String, isWindowChange: Boolean) {
        val now = System.currentTimeMillis()
        if (!isWindowChange && now - lastCheck < 600) return
        lastCheck = now
        if (now - lastAction < 1500) return
        // Snapchat n'est pas toujours « la fenêtre active » (caméra, surcouches…) :
        // on cherche la fenêtre de l'appli parmi toutes les fenêtres à l'écran.
        val active = service.rootInActiveWindow
        val root = if (active?.packageName?.toString() == pkg) active else runCatching {
            service.windows.mapNotNull { it.root }.firstOrNull { it.packageName?.toString() == pkg }
        }.getOrNull()
        val diagDue = isWindowChange || now - lastDiag > 3000
        if (pkg == SNAPCHAT && diagDue) {
            android.util.Log.d("STOPAPP", "SNAP partial: root=${root?.packageName} children=${root?.childCount}")
        }
        if (root == null) {
            if (diagDue) {
                lastDiag = now
                runCatching {
                    Diagnostic.note(service, pkg,
                        "écran illisible — fenêtre active : ${active?.packageName ?: "aucune"}, " +
                            "fenêtres : ${runCatching { service.windows.joinToString { (it.root?.packageName ?: "?").toString() } }.getOrDefault("?")}")
                }
            }
            return
        }
        // Diagnostic : on garde une trace de ce qui est à l'écran (bouton Diagnostic dans stop#app)
        if (diagDue) {
            lastDiag = now
            runCatching { Diagnostic.record(service, pkg, root) }
        }
        when (pkg) {
            SNAPCHAT -> checkSnapchat(root, now)
            YOUTUBE -> checkYouTube(root, now)
        }
    }

    // ---------------- Snapchat ----------------

    // Titres de page affichés en haut de Snapchat (relevés avec le diagnostic)
    private val snapBlockedTitles = listOf("Spotlight", "Stories", "Découvrir", "Discover")
    private val snapChatTabId = "com.snapchat.android:id/ngs_chat_icon_container"
    private val snapChatTab = listOf("Chat", "Discussions")

    private fun checkSnapchat(root: AccessibilityNodeInfo, now: Long) {
        // 1) Page Stories ou Spotlight : le TITRE en haut de l'écran porte ce nom
        //    (les boutons du bas ont seulement une description, pas un texte)
        val onBlockedPage = snapBlockedTitles.any { title -> hasExactText(root, title) }
        if (onBlockedPage) {
            viewerSince = 0
            act("Stories et Spotlight sont bloqués. Tes messages restent accessibles.")
            val chat = root.findAccessibilityNodeInfosByViewId(snapChatTabId)?.firstOrNull { it.isClickable }
            val clicked = chat?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true || clickFirst(root, snapChatTab)
            if (!clicked) service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            return
        }

        // 2) Lecteur de story / snap ouvert depuis tes messages : 30 secondes maximum.
        //    Le lecteur de Snapchat porte une description « opera_content_index… ».
        val inViewer = hasDescStartingWith(root, "opera_content_index")
        if (inViewer) {
            if (viewerSince == 0L) viewerSince = now
            else if (now - viewerSince > STORY_MAX_MS) {
                viewerSince = 0
                act("30 secondes écoulées. Retour à tes messages.")
                service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            }
        } else {
            viewerSince = 0
        }
    }

    /** Un élément a exactement ce TEXTE (pas une simple description). */
    private fun hasExactText(root: AccessibilityNodeInfo, label: String): Boolean =
        root.findAccessibilityNodeInfosByText(label)?.any { n ->
            n.text?.toString()?.trim()?.equals(label, ignoreCase = true) == true
        } == true

    /** Un élément a une description qui commence par ce mot. */
    private fun hasDescStartingWith(root: AccessibilityNodeInfo, prefix: String): Boolean {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var seen = 0
        while (queue.isNotEmpty() && seen < 300) {
            val n = queue.removeFirst(); seen++
            if (n.contentDescription?.toString()?.startsWith(prefix) == true) return true
            for (i in 0 until n.childCount) n.getChild(i)?.let { queue.add(it) }
        }
        return false
    }

    // ---------------- YouTube ----------------

    private val ytShortsIds = listOf(
        "com.google.android.youtube:id/reel_recycler",
        "com.google.android.youtube:id/reel_player_page_container",
        "com.google.android.youtube:id/reel_watch_player",
        "com.google.android.youtube:id/reel_time_bar"
    )
    private val ytHomeTab = listOf("Accueil", "Home")

    private fun checkYouTube(root: AccessibilityNodeInfo, now: Long) {
        val inShorts = ytShortsIds.any { id ->
            root.findAccessibilityNodeInfosByViewId(id)?.any { it.isVisibleToUser } == true
        } || isSelectedTab(root, "Shorts")
        if (inShorts) {
            act("Les Shorts sont bloqués. Le reste de YouTube reste accessible.")
            if (!clickFirst(root, ytHomeTab)) service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
        }
    }

    // ---------------- Outils ----------------

    private fun act(message: String) {
        lastAction = System.currentTimeMillis()
        runCatching { Toast.makeText(service, message, Toast.LENGTH_SHORT).show() }
        Prefs.addBlock(service)
    }

    /** Un bouton/onglet portant ce nom est-il sélectionné (lui ou son parent) ? */
    private fun isSelectedTab(root: AccessibilityNodeInfo, label: String): Boolean =
        root.findAccessibilityNodeInfosByText(label)?.any { n ->
            val same = (n.text?.toString() ?: n.contentDescription?.toString() ?: "")
                .trim().equals(label, ignoreCase = true) ||
                (n.contentDescription?.toString() ?: "").startsWith(label, ignoreCase = true)
            val desc = (n.contentDescription?.toString() ?: "").lowercase()
            same && (n.isSelected || n.isChecked || n.parent?.isSelected == true ||
                desc.contains("sélectionné") || desc.contains("selected"))
        } == true

    /** Un élément porte exactement ce nom (texte ou description), pas juste un mot dans une phrase. */
    private fun hasExactLabel(root: AccessibilityNodeInfo, label: String): Boolean =
        root.findAccessibilityNodeInfosByText(label)?.any { n ->
            (n.text?.toString()?.trim()?.equals(label, true) == true) ||
                (n.contentDescription?.toString()?.trim()?.equals(label, true) == true)
        } == true

    /** Clique sur le premier bouton trouvé parmi ces noms. */
    private fun clickFirst(root: AccessibilityNodeInfo, labels: List<String>): Boolean {
        for (label in labels) {
            root.findAccessibilityNodeInfosByText(label)?.filter { n ->
                (n.text?.toString()?.trim()?.equals(label, true) == true) ||
                    (n.contentDescription?.toString()?.trim()?.equals(label, true) == true)
            }?.forEach { n ->
                var node: AccessibilityNodeInfo? = n
                var depth = 0
                while (node != null && depth < 4) {
                    if (node.isClickable) return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    node = node.parent; depth++
                }
            }
        }
        return false
    }

    /** Liste qui défile (conversation, liste d'amis…) ou champ de texte actif = pas un lecteur de story. */
    private fun hasScrollableOrFocusedInput(root: AccessibilityNodeInfo): Boolean {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var seen = 0
        while (queue.isNotEmpty() && seen < 400) {
            val n = queue.removeFirst(); seen++
            if (n.isScrollable) return true
            if (n.isEditable && n.isFocused) return true
            for (i in 0 until n.childCount) n.getChild(i)?.let { queue.add(it) }
        }
        return false
    }
}
