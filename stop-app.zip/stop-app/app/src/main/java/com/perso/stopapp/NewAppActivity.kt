package com.perso.stopapp

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * Fenêtre au milieu de l'écran quand une nouvelle appli vient d'être installée :
 * « Bloquer » ou « Laisser passer ».
 * - Hors blocage (pause, mode modification) : laissée passer tout de suite.
 * - Pendant un blocage : laissée passer au début de la prochaine pause
 *   (sinon il suffirait d'installer une appli pour contourner stop#app).
 */
class NewAppActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PKG = "pkg"
    }

    private var pkg: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_app)
        setFinishOnTouchOutside(false)
        show(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        show(intent)
    }

    private fun show(i: Intent?) {
        pkg = i?.getStringExtra(EXTRA_PKG) ?: run { finish(); return }
        val pm = packageManager
        val info = runCatching { pm.getApplicationInfo(pkg, 0) }.getOrNull() ?: run { finish(); return }
        findViewById<TextView>(R.id.txt_name).text = pm.getApplicationLabel(info)
        findViewById<ImageView>(R.id.img_icon).setImageDrawable(pm.getApplicationIcon(info))

        val note = findViewById<TextView>(R.id.txt_note)
        val allow = findViewById<Button>(R.id.btn_allow)
        val now = Prefs.canEdit(this)
        if (now) {
            note.visibility = View.GONE
            allow.text = "✅  Laisser passer"
        } else {
            val next = Prefs.nextFreeStart(this)
            note.visibility = View.VISIBLE
            note.text = if (next != null)
                "Blocage en cours : si tu la laisses passer, elle sera autorisée dès ta prochaine pause ($next)."
            else
                "Blocage en cours : si tu la laisses passer, elle sera autorisée dès ta prochaine pause."
            allow.text = "✅  Laisser passer (dès la pause)"
        }

        findViewById<Button>(R.id.btn_block).setOnClickListener {
            // Une nouvelle appli est bloquée par défaut : on s'assure juste qu'elle n'est pas autorisée.
            if (Prefs.canEdit(this)) Prefs.setAllowedApps(this, Prefs.allowedApps(this) - pkg)
            Toast.makeText(this, "Bloquée pendant les heures de blocage. 💪", Toast.LENGTH_SHORT).show()
            finish()
        }
        allow.setOnClickListener {
            if (Prefs.canEdit(this)) {
                Prefs.setAllowedApps(this, Prefs.allowedApps(this) + pkg)
                Toast.makeText(this, "Autorisée ✅", Toast.LENGTH_SHORT).show()
            } else {
                Prefs.addPendingAllow(this, pkg)
                Toast.makeText(this, "Elle sera autorisée dès ta prochaine pause.", Toast.LENGTH_LONG).show()
            }
            finish()
        }
    }
    // Retour / fermeture = choix par défaut : l'appli reste bloquée.
}
