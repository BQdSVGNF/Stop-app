package com.perso.stopapp

import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CompoundButton
import android.widget.EditText
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/** Liste des applications installées : coche celles qui restent autorisées. */
class AppPickerActivity : AppCompatActivity() {

    data class AppItem(val pkg: String, val label: String, val icon: Drawable)

    private val selected = mutableSetOf<String>()
    private var all = listOf<AppItem>()
    private var shown = listOf<AppItem>()
    private lateinit var adapter: Adapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Sécurité : pas de modification pendant que le blocage est actif
        if (!Prefs.canEdit(this)) { finish(); return }

        setContentView(R.layout.activity_app_picker)
        selected.addAll(Prefs.allowedApps(this))

        val list = findViewById<RecyclerView>(R.id.list)
        val progress = findViewById<ProgressBar>(R.id.progress)
        adapter = Adapter()
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter

        findViewById<EditText>(R.id.search).doAfterTextChanged { filter(it?.toString() ?: "") }

        Thread {
            val pm = packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val apps = pm.queryIntentActivities(intent, 0)
                .map { it.activityInfo.packageName }
                .distinct()
                .filter { it != packageName }
                .map { p ->
                    val info = pm.getApplicationInfo(p, 0)
                    AppItem(p, pm.getApplicationLabel(info).toString(), pm.getApplicationIcon(info))
                }
                .sortedWith(compareBy({ it.pkg !in selected }, { it.label.lowercase() }))
            runOnUiThread {
                all = apps
                filter("")
                progress.visibility = View.GONE
            }
        }.start()
    }

    private fun filter(q: String) {
        val s = q.trim().lowercase()
        shown = if (s.isEmpty()) all else all.filter { it.label.lowercase().contains(s) }
        adapter.notifyDataSetChanged()
    }

    override fun onPause() {
        super.onPause()
        if (Prefs.canEdit(this)) Prefs.setAllowedApps(this, selected)
    }

    inner class Adapter : RecyclerView.Adapter<Adapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val icon: ImageView = v.findViewById(R.id.icon)
            val label: TextView = v.findViewById(R.id.label)
            val check: CompoundButton = v.findViewById(R.id.check)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false))

        override fun getItemCount() = shown.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val app = shown[position]
            h.icon.setImageDrawable(app.icon)
            h.label.text = app.label
            h.check.setOnCheckedChangeListener(null)
            h.check.isChecked = app.pkg in selected
            h.check.setOnCheckedChangeListener { _, checked ->
                if (checked) selected.add(app.pkg) else selected.remove(app.pkg)
            }
            h.itemView.setOnClickListener { h.check.toggle() }
        }
    }
}
