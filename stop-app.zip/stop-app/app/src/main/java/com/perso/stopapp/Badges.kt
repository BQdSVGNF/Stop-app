package com.perso.stopapp

import android.content.Context

/** Niveaux (XP) et badges de stop#app. */
object Badges {

    class Badge(val id: String, val emoji: String, val name: String, val desc: String, val check: (Stats) -> Boolean)

    /** Tout ce qui sert à calculer les badges et l'XP. */
    class Stats(
        val started: Boolean,
        val blocks: Int,
        val streak: Int,
        val bestStreak: Int,
        val days: Int,
        val focusSessions: Int,
        val focusMinutes: Int
    ) {
        /** Points d'expérience : chaque bonne action en rapporte. */
        val xp: Int get() = blocks * 5 + days * 20 + focusSessions * 30 + focusMinutes / 2
    }

    fun stats(c: Context) = Stats(
        started = Prefs.isStarted(c),
        blocks = Prefs.blocksTotal(c),
        streak = Prefs.streak(c),
        bestStreak = Prefs.bestStreak(c),
        days = Prefs.daysTotal(c),
        focusSessions = Prefs.focusSessions(c),
        focusMinutes = Prefs.focusMinutes(c)
    )

    // ---------- Niveaux ----------

    private val thresholds = listOf(0, 50, 150, 300, 500, 800, 1200, 1700, 2300, 3000, 4000)
    private val names = listOf(
        "Débutant", "Curieux", "Motivé", "Concentré", "Discipliné",
        "Déterminé", "Maître du temps", "Esprit zen", "Inarrêtable", "Légende", "stop#master"
    )

    class Level(val number: Int, val name: String, val xp: Int, val from: Int, val to: Int?) {
        /** Progression vers le niveau suivant, de 0 à 100. */
        val percent: Int get() = if (to == null) 100 else ((xp - from) * 100 / (to - from)).coerceIn(0, 100)
        val remaining: Int get() = if (to == null) 0 else (to - xp).coerceAtLeast(0)
    }

    fun level(xp: Int): Level {
        val i = thresholds.indexOfLast { xp >= it }.coerceAtLeast(0)
        return Level(i + 1, names[i], xp, thresholds[i], thresholds.getOrNull(i + 1))
    }

    // ---------- Badges ----------

    val all = listOf(
        Badge("start", "🚀", "Premier pas", "Démarrer stop#app") { it.started },
        Badge("block1", "🛡️", "Première victoire", "Résister une première fois") { it.blocks >= 1 },
        Badge("block50", "🧱", "Mur de fer", "Résister 50 fois") { it.blocks >= 50 },
        Badge("block200", "🏰", "Forteresse", "Résister 200 fois") { it.blocks >= 200 },
        Badge("streak3", "🥉", "3 jours", "3 jours d'affilée") { it.bestStreak >= 3 },
        Badge("streak7", "🥈", "Une semaine", "7 jours d'affilée") { it.bestStreak >= 7 },
        Badge("streak30", "🥇", "Un mois", "30 jours d'affilée") { it.bestStreak >= 30 },
        Badge("focus1", "🎯", "Premier Focus", "Terminer une session Focus") { it.focusSessions >= 1 },
        Badge("focus10", "🧠", "Esprit d'acier", "10 sessions Focus") { it.focusSessions >= 10 },
        Badge("focus600", "⏱️", "10 h de Focus", "Cumuler 10 heures de Focus") { it.focusMinutes >= 600 },
        Badge("level5", "⭐", "Niveau 5", "Atteindre le niveau 5") { level(it.xp).number >= 5 },
        Badge("level10", "👑", "Légende", "Atteindre le niveau 10") { level(it.xp).number >= 10 }
    )

    fun unlocked(s: Stats): List<Badge> = all.filter { it.check(s) }

    /** Badges débloqués qui n'ont pas encore été annoncés (et on les marque comme vus). */
    fun takeNew(c: Context): List<Badge> {
        val seen = Prefs.badgesSeen(c)
        val now = unlocked(stats(c))
        val fresh = now.filter { it.id !in seen }
        if (fresh.isNotEmpty()) Prefs.setBadgesSeen(c, seen + fresh.map { it.id })
        return fresh
    }
}
