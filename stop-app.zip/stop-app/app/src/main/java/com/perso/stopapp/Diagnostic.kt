package com.perso.stopapp

import android.content.Context
import android.view.accessibility.AccessibilityNodeInfo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Outil de diagnostic : enregistre les boutons visibles dans Snapchat et YouTube
 * (nom, description, identifiant, état sélectionné…). Sert à régler le blocage
 * des Stories / Spotlight / Shorts. Aucune donnée ne quitte le téléphone.
 */
object Diagnostic {
    private const val PREFS = "stopapp_diag"
    private const val MAX_SCREENS = 6

    fun record(c: Context, pkg: String, root: AccessibilityNodeInfo) {
        val lines = mutableListOf<String>()
        val queue = ArrayDeque<Pair<AccessibilityNodeInfo, Int>>()
        queue.add(root to 0)
        var seen = 0
        while (queue.isNotEmpty() && seen < 250) {
            val (n, d) = queue.removeFirst(); seen++
            val text = n.text?.toString()?.take(40)?.replace("\n", " ")
            val desc = n.contentDescription?.toString()?.take(60)?.replace("\n", " ")
            val id = n.viewIdResourceName?.substringAfter(":id/")
            val flags = buildString {
                if (n.isSelected) append("[SEL]")
                if (n.isChecked) append("[CHK]")
                if (n.isClickable) append("[clic]")
                if (n.isScrollable) append("[défile]")
                if (n.isEditable) append("[texte]")
            }
            // On ne garde que les éléments qui portent une info (pas les conteneurs vides)
            if (!text.isNullOrBlank() || !desc.isNullOrBlank() || (id != null && flags.isNotEmpty())) {
                lines.add(buildString {
                    append(" ".repeat(minOf(d, 8)))
                    if (!text.isNullOrBlank()) append("«$text» ")
                    if (!desc.isNullOrBlank()) append("desc=«$desc» ")
                    if (id != null) append("id=$id ")
                    append(flags)
                })
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { queue.add(it to d + 1) }
        }
        val app = if (pkg == PartialBlocker.SNAPCHAT) "Snapchat" else "YouTube"
        val time = SimpleDateFormat("HH:mm:ss", Locale.FRANCE).format(Date())
        val screen = "=== $app $time ===\n" + lines.take(80).joinToString("\n")

        save(c, if (lines.isEmpty()) "$screen(aucun bouton lisible)" else screen)
    }

    /** Ajoute une simple ligne (quand l'écran ne peut pas être lu). */
    fun note(c: Context, pkg: String, message: String) {
        val app = if (pkg == PartialBlocker.SNAPCHAT) "Snapchat" else "YouTube"
        val time = SimpleDateFormat("HH:mm:ss", Locale.FRANCE).format(Date())
        save(c, "=== $app $time ===\n$message")
    }

    private fun save(c: Context, screen: String) {
        val sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val old = sp.getString("screens", "") ?: ""
        val screens = (listOf(screen) + old.split("\n\n").filter { it.isNotBlank() }).take(MAX_SCREENS)
        sp.edit().putString("screens", screens.joinToString("\n\n")).apply()
    }

    fun read(c: Context): String =
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("screens", "")
            ?.ifBlank { null } ?: "Aucun écran enregistré. Ouvre Snapchat ou YouTube, puis reviens ici."

    fun clear(c: Context) =
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove("screens").apply()
}
