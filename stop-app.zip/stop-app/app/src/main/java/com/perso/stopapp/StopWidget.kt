package com.perso.stopapp

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Widget d'écran d'accueil : état, série, niveau et prochaine pause. */
class StopWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { manager.updateAppWidget(it, build(context)) }
    }

    companion object {
        private var lastUpdate = 0L

        /** Met à jour tous les widgets posés sur l'écran d'accueil (au plus toutes les 20 s). */
        fun updateAll(context: Context, force: Boolean = false) {
            val now = System.currentTimeMillis()
            if (!force && now - lastUpdate < 20_000) return
            lastUpdate = now
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, StopWidget::class.java))
            if (ids.isEmpty()) return
            val views = build(context)
            ids.forEach { manager.updateAppWidget(it, views) }
        }

        private fun hhmm(ms: Long) = SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(ms))

        private fun build(c: Context): RemoteViews {
            val v = RemoteViews(c.packageName, R.layout.widget_stop)
            val stats = Badges.stats(c)
            val level = Badges.level(stats.xp)

            val (icon, title, sub) = when {
                !Prefs.isStarted(c) && !Prefs.inFocus(c) ->
                    Triple(R.drawable.ic_w_play, "Pas démarré", "Ouvre stop#app pour commencer")
                Prefs.inFocus(c) ->
                    Triple(R.drawable.ic_w_focus, "Focus", "Jusqu'à ${hhmm(Prefs.focusUntil(c))}")
                Prefs.inPass(c) ->
                    Triple(R.drawable.ic_w_coffee, "Pause bonus", "Jusqu'à ${hhmm(Prefs.passUntil(c))}")
                Prefs.inEditMode(c) ->
                    Triple(R.drawable.ic_w_edit, "Modification", "Reblocage à ${hhmm(Prefs.editUntil(c))}")
                Prefs.currentFreeWindow(c) != null ->
                    Triple(R.drawable.ic_w_lock_open, "Créneau libre", "Jusqu'à ${Prefs.currentFreeWindow(c)!!.substringAfter("-")}")
                else ->
                    Triple(R.drawable.ic_w_lock, "Blocage actif", Prefs.nextFreeStart(c)?.let { "Prochaine pause : $it" } ?: "Blocage en cours")
            }

            v.setImageViewResource(R.id.w_icon, icon)
            v.setTextViewText(R.id.w_title, title)
            v.setTextViewText(R.id.w_sub, sub)
            v.setTextViewText(R.id.w_streak, "Série ${stats.streak} j")
            v.setTextViewText(R.id.w_level, "Niveau ${level.number}")
            v.setTextViewText(R.id.w_today, "${Prefs.blocksToday(c)} évitées")
            v.setProgressBar(R.id.w_progress, 100, level.percent, false)

            val open = PendingIntent.getActivity(
                c, 0,
                Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            v.setOnClickPendingIntent(R.id.w_root, open)
            return v
        }
    }
}
