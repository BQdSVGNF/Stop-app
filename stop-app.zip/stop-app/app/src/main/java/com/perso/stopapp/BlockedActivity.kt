package com.perso.stopapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

/** Écran rouge affiché quand une app ou un site est bloqué. */
class BlockedActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_REASON = "reason"
        const val EXTRA_WHAT = "what"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_blocked)
        show(intent)

        findViewById<Button>(R.id.btn_home).setOnClickListener { goHome() }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = goHome()
        })
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        show(intent)
    }

    private fun show(i: Intent) {
        findViewById<TextView>(R.id.txt_reason).text = i.getStringExtra(EXTRA_REASON) ?: "Bloqué"
        findViewById<TextView>(R.id.txt_what).text = i.getStringExtra(EXTRA_WHAT) ?: ""
    }

    private fun goHome() {
        startActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        finish()
    }
}
