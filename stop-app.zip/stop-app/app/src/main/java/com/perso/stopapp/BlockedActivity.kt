package com.perso.stopapp

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.animation.OvershootInterpolator
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

/** Écran affiché quand une app ou un site est bloqué, avec une idée pour remplacer le scroll. */
class BlockedActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_REASON = "reason"
        const val EXTRA_WHAT = "what"
    }

    private lateinit var txtIdea: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_blocked)
        txtIdea = findViewById(R.id.txt_idea)
        show(intent)

        findViewById<Button>(R.id.btn_home).setOnClickListener { goHome() }
        findViewById<Button>(R.id.btn_idea_next).setOnClickListener {
            txtIdea.text = Encouragements.other(Encouragements.ideas, txtIdea.text)
            txtIdea.alpha = 0f
            txtIdea.animate().alpha(1f).setDuration(250).start()
        }
        findViewById<Button>(R.id.btn_idea_done).setOnClickListener {
            Toast.makeText(this, "Bien joué ! 💪 Reviens quand c'est fait.", Toast.LENGTH_SHORT).show()
            goHome()
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = goHome()
        })
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        show(intent)
    }

    private fun show(i: Intent) {
        findViewById<TextView>(R.id.txt_reason).text = i.getStringExtra(EXTRA_REASON) ?: "Bloqué"
        findViewById<TextView>(R.id.txt_what).text = i.getStringExtra(EXTRA_WHAT) ?: ""
        findViewById<TextView>(R.id.txt_quote).text =
            if (Prefs.inFocus(this)) Encouragements.random(Encouragements.focus)
            else Encouragements.random(Encouragements.blocked)
        txtIdea.text = Encouragements.random(Encouragements.ideas)

        val n = Prefs.blocksToday(this)
        findViewById<TextView>(R.id.txt_count).text = buildString {
            append("🛡️ Tu as résisté $n fois aujourd'hui")
            if (Prefs.inFocus(this@BlockedActivity)) {
                val left = ((Prefs.focusUntil(this@BlockedActivity) - System.currentTimeMillis()) / 60000).toInt() + 1
                append("\n🎯 Fin du Focus dans ${QuitActivity.formatMinutes(left)}")
            } else {
                Prefs.minutesToNextFree(this@BlockedActivity)?.let {
                    append("\n⏳ Prochaine pause dans ${QuitActivity.formatMinutes(it)}")
                }
            }
        }

        // Petite animation d'arrivée
        val hand = findViewById<View>(R.id.blocked_hand)
        hand.scaleX = 0.4f; hand.scaleY = 0.4f
        hand.animate().scaleX(1f).scaleY(1f).setDuration(450).setInterpolator(OvershootInterpolator()).start()
    }

    private fun goHome() {
        startActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        finish()
    }
}
