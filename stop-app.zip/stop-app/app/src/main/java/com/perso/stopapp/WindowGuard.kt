package com.perso.stopapp

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Bloque les applis mises en FENÊTRE (pop-up) ou en ÉCRAN PARTAGÉ.
 * Dans ces modes, l'écran de blocage et l'appli peuvent être visibles en même temps :
 * on pose alors un cache stop#app directement sur la fenêtre de l'appli bloquée.
 * Le cache prend tous les appuis : l'appli dessous est inutilisable.
 */
class WindowGuard(private val service: AccessibilityService) {

    private class Cover(val view: View, var rect: Rect, val pkg: String)

    private val wm = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val covers = HashMap<Int, Cover>()   // identifiant de fenêtre -> cache

    /** Petite bande laissée libre en haut d'une fenêtre pop-up pour pouvoir la fermer ou la déplacer. */
    private val handlePx = (26 * service.resources.displayMetrics.density).toInt()

    /** @param targets fenêtres à cacher : id de fenêtre -> (position à l'écran, appli) */
    fun update(targets: Map<Int, Pair<Rect, String>>) {
        // Enlever les caches devenus inutiles
        val gone = covers.keys - targets.keys
        for (id in gone) remove(id)
        // Ajouter / déplacer
        for ((id, t) in targets) {
            val (rect, pkg) = t
            val existing = covers[id]
            if (existing != null && existing.pkg == pkg) {
                if (existing.rect != rect) {
                    existing.rect = Rect(rect)
                    runCatching { wm.updateViewLayout(existing.view, params(rect)) }
                }
                continue
            }
            if (existing != null) remove(id)
            add(id, rect, pkg)
        }
    }

    fun clear() {
        for (id in covers.keys.toList()) remove(id)
    }

    // ---------- Bouclier plein écran (désinstallation) ----------
    // Posé INSTANTANÉMENT dès que la fenêtre « Désinstaller stop#app ? » apparaît :
    // il prend tous les appuis, y compris ceux d'un auto-clicker, le temps de fermer
    // la fenêtre et d'ouvrir le questionnaire.

    private var shield: View? = null
    private var shieldUntil = 0L
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private val shieldEnd = Runnable { maybeHideShield() }

    fun showShield(ms: Long) {
        shieldUntil = maxOf(shieldUntil, System.currentTimeMillis() + ms)
        if (shield == null) {
            val v = FrameLayout(service).apply {
                background = Look.gradient(Look.current(service))
                isClickable = true
                isFocusable = false
                addView(TextView(service).apply {
                    text = "🛡️\nstop#app protège ta décision…"
                    setTextColor(Color.WHITE)
                    textSize = 20f
                    gravity = Gravity.CENTER
                }, FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT
                ))
            }
            val p = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START }
            if (runCatching { wm.addView(v, p) }.isSuccess) shield = v
        }
        handler.removeCallbacks(shieldEnd)
        handler.postDelayed(shieldEnd, ms)
    }

    private fun maybeHideShield() {
        val left = shieldUntil - System.currentTimeMillis()
        if (left > 50) { handler.postDelayed(shieldEnd, left); return }
        shield?.let { runCatching { wm.removeViewImmediate(it) } }
        shield = null
    }

    fun hasShield() = shield != null

    fun isEmpty() = covers.isEmpty()

    private fun add(id: Int, rect: Rect, pkg: String) {
        val view = buildView(pkg)
        val ok = runCatching { wm.addView(view, params(rect)) }.isSuccess
        if (ok) {
            covers[id] = Cover(view, Rect(rect), pkg)
            runCatching { Prefs.addBlock(service) }
        }
    }

    private fun remove(id: Int) {
        covers.remove(id)?.let { c -> runCatching { wm.removeViewImmediate(c.view) } }
    }

    private fun params(r: Rect): WindowManager.LayoutParams {
        // En pop-up, on laisse la poignée du haut libre (pour fermer la fenêtre).
        val top = if (r.height() > handlePx * 4) r.top + handlePx else r.top
        return WindowManager.LayoutParams(
            r.width().coerceAtLeast(1),
            (r.bottom - top).coerceAtLeast(1),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = r.left
            y = top
        }
    }

    private fun dp(v: Int) = (v * service.resources.displayMetrics.density).toInt()

    private fun buildView(pkg: String): View {
        val ctx = service
        val label = runCatching {
            ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pkg, 0)).toString()
        }.getOrDefault(pkg)

        val root = FrameLayout(ctx).apply {
            background = Look.gradient(Look.current(ctx), alpha = 0xF2)
            isClickable = true      // avale tous les appuis
            isFocusable = false
        }
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(20), dp(12), dp(20), dp(12))
        }
        col.addView(ImageView(ctx).apply {
            setImageResource(R.drawable.ic_w_lock)
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
        })
        col.addView(TextView(ctx).apply {
            text = "Bloqué par stop#app"
            setTextColor(Color.WHITE)
            textSize = 20f
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        })
        col.addView(TextView(ctx).apply {
            text = "$label reste bloquée, même en fenêtre ou en écran partagé."
            setTextColor(Color.parseColor("#E6FFFFFF"))
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(12))
        })
        col.addView(Button(ctx).apply {
            text = "Retour à l'accueil"
            setAllCaps(false)
            setTextColor(Color.parseColor("#6C5CE7"))
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat()
                setColor(Color.WHITE)
            }
            setPadding(dp(22), 0, dp(22), 0)
            setOnClickListener { service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME) }
        })
        root.addView(col, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT
        ))
        return root
    }
}
