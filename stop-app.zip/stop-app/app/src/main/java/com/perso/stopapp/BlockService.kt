package com.perso.stopapp

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.telecom.TelecomManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.inputmethod.InputMethodManager

/**
 * Le cœur de stop#app : surveille l'application au premier plan.
 * - Si le blocage est actif et que l'app n'est pas autorisée -> retour à l'accueil + écran "bloqué".
 * - Dans Chrome, Edge et Google : lit l'adresse / la recherche et bloque les sites de la liste.
 */
class BlockService : AccessibilityService() {

    /** Navigateurs surveillés et l'identifiant de leur barre d'adresse. */
    private val browsers = mapOf(
        "com.android.chrome" to listOf("com.android.chrome:id/url_bar"),
        "com.chrome.beta" to listOf("com.chrome.beta:id/url_bar"),
        "com.microsoft.emmx" to listOf(
            "com.microsoft.emmx:id/url_bar",
            "com.microsoft.emmx:id/search_box_text"
        ),
        "com.google.android.googlequicksearchbox" to listOf(
            "com.google.android.googlequicksearchbox:id/googleapp_search_box",
            "com.google.android.googlequicksearchbox:id/search_box"
        )
    )

    private var lastBlockTime = 0L
    private var systemAllowed: Set<String> = emptySet()

    override fun onServiceConnected() {
        super.onServiceConnected()
        systemAllowed = computeSystemAllowed()
    }

    /** Apps qu'on ne bloque jamais : stop#app, l'écran d'accueil, le clavier, le téléphone (urgences)... */
    private fun computeSystemAllowed(): Set<String> {
        val set = mutableSetOf(
            packageName,
            "android",
            "com.android.systemui",
            "com.google.android.permissioncontroller",
            "com.android.permissioncontroller",
            "com.google.android.packageinstaller",
            "com.android.packageinstaller",
            "com.android.emergency",
            "com.google.android.dialer",
            "com.android.dialer",
            "com.samsung.android.dialer",
            "com.android.phone",
            "com.android.incallui"
        )
        // Écran d'accueil (launcher)
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        packageManager.queryIntentActivities(home, 0).forEach { set.add(it.activityInfo.packageName) }
        // Application téléphone par défaut
        runCatching {
            (getSystemService(TELECOM_SERVICE) as TelecomManager).defaultDialerPackage?.let { set.add(it) }
        }
        // Claviers
        runCatching {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.enabledInputMethodList.forEach { set.add(it.packageName) }
        }
        return set
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (!Prefs.isBlockingNow(this)) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg in systemAllowed) return

        val allowed = Prefs.allowedApps(this)

        // 1) Application non autorisée -> bloquée
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && pkg !in allowed) {
            block("📵 Application bloquée", appLabel(pkg))
            return
        }

        // 2) Navigateur autorisé -> vérifier les sites
        val ids = browsers[pkg] ?: return
        if (pkg !in allowed) return
        val sites = Prefs.blockedSites(this)
        if (sites.isEmpty()) return

        val root = rootInActiveWindow ?: return
        val texts = mutableListOf<String>()
        for (id in ids) {
            root.findAccessibilityNodeInfosByViewId(id)?.forEach { n ->
                n.text?.toString()?.let { texts.add(it) }
            }
        }
        if (texts.isEmpty()) collectEditableTexts(root, texts, 0)

        for (t in texts) {
            val lower = t.lowercase()
            val hit = sites.firstOrNull { site -> site.isNotBlank() && lower.contains(site) }
            if (hit != null) {
                performGlobalAction(GLOBAL_ACTION_BACK)
                block("🌐 Site bloqué", hit)
                return
            }
        }
    }

    /** Si on ne trouve pas la barre d'adresse, on lit les champs de saisie visibles. */
    private fun collectEditableTexts(node: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (node == null || depth > 25 || out.size > 10) return
        if (node.isEditable) node.text?.toString()?.let { out.add(it) }
        for (i in 0 until node.childCount) collectEditableTexts(node.getChild(i), out, depth + 1)
    }

    private fun block(reason: String, what: String) {
        val now = System.currentTimeMillis()
        if (now - lastBlockTime < 800) return
        lastBlockTime = now
        performGlobalAction(GLOBAL_ACTION_HOME)
        val i = Intent(this, BlockedActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra(BlockedActivity.EXTRA_REASON, reason)
            .putExtra(BlockedActivity.EXTRA_WHAT, what)
        startActivity(i)
    }

    private fun appLabel(pkg: String): String = runCatching {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    }.getOrDefault(pkg)

    override fun onInterrupt() {}
}
