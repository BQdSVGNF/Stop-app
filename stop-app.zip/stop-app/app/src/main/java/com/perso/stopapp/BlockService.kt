package com.perso.stopapp

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.telecom.TelecomManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.inputmethod.InputMethodManager

/**
 * Le cœur de stop#app : surveille l'application au premier plan.
 * - Si le blocage est actif et que l'app n'est pas autorisée -> écran "bloqué" par-dessus.
 * - Dans Chrome, Edge et Google : lit l'adresse et bloque les sites de la liste
 *   (jamais pendant que tu tapes, pour ne pas ralentir le clavier).
 * - Si quelqu'un essaie de désinstaller stop#app -> écran "Tu es sûr ?".
 */
class BlockService : AccessibilityService() {

    /** Navigateurs surveillés et l'identifiant de leur barre d'adresse. */
    private val browsers = mapOf(
        "com.android.chrome" to listOf("com.android.chrome:id/url_bar"),
        "com.chrome.beta" to listOf("com.chrome.beta:id/url_bar"),
        "com.microsoft.emmx" to listOf(
            "com.microsoft.emmx:id/url_bar",
            "com.microsoft.emmx:id/search_box_text"
        ),
        "com.google.android.googlequicksearchbox" to listOf(
            "com.google.android.googlequicksearchbox:id/googleapp_search_box",
            "com.google.android.googlequicksearchbox:id/search_box"
        )
    )

    /** Fenêtres de désinstallation d'Android. */
    private val installers = setOf(
        "com.google.android.packageinstaller",
        "com.android.packageinstaller",
        "com.samsung.android.packageinstaller"
    )

    private var lastBlockTime = 0L
    private var lastAppCheck = 0L
    private var lastWebCheck = 0L
    private var systemAllowed: Set<String> = emptySet()
    private var launchers: Set<String> = emptySet()

    override fun onServiceConnected() {
        super.onServiceConnected()
        systemAllowed = computeSystemAllowed()
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        launchers = packageManager.queryIntentActivities(home, 0).map { it.activityInfo.packageName }.toSet()
    }

    /** Apps qu'on ne bloque jamais : stop#app, l'écran d'accueil, le clavier, le téléphone (urgences)... */
    private fun computeSystemAllowed(): Set<String> {
        val set = mutableSetOf(
            packageName,
            "android",
            "com.android.systemui",
            "com.google.android.permissioncontroller",
            "com.android.permissioncontroller",
            "com.google.android.packageinstaller",
            "com.android.packageinstaller",
            "com.samsung.android.packageinstaller",
            "com.android.emergency",
            "com.google.android.dialer",
            "com.android.dialer",
            "com.samsung.android.dialer",
            "com.android.phone",
            "com.android.incallui",
            // Claviers courants (en plus de ceux détectés plus bas)
            "com.samsung.android.honeyboard",
            "com.google.android.inputmethod.latin",
            "com.touchtype.swiftkey"
        )
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        packageManager.queryIntentActivities(home, 0).forEach { set.add(it.activityInfo.packageName) }
        runCatching {
            (getSystemService(TELECOM_SERVICE) as TelecomManager).defaultDialerPackage?.let { set.add(it) }
        }
        runCatching {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.enabledInputMethodList.forEach { set.add(it.packageName) }
        }
        return set
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        val isWindowChange = event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED

        // 0) Tentative de désinstallation de stop#app (vérifié à toute heure)
        // (fenêtre système de désinstallation, ou boîte de dialogue de l'écran d'accueil Samsung)
        val isUninstallWindow = pkg in installers ||
            (pkg in launchers && event.className?.toString()?.contains("Dialog") == true)
        if (isWindowChange && isUninstallWindow && !Prefs.uninstallAllowed(this)) {
            if (looksLikeUninstallOfMe()) {
                performGlobalAction(GLOBAL_ACTION_BACK)
                startActivity(
                    Intent(this, QuitActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                )
                return
            }
        }

        if (pkg in systemAllowed) return
        if (!Prefs.isBlockingNow(this)) return

        val allowed = Prefs.allowedApps(this)

        // 1) Application non autorisée -> bloquée tout de suite
        if (pkg !in allowed) {
            if (isWindowChange) {
                block("📵 Application bloquée", appLabel(pkg))
            } else {
                // Rattrapage : certaines applis s'affichent sans « changement de fenêtre ».
                val now = System.currentTimeMillis()
                if (now - lastAppCheck < 500) return
                lastAppCheck = now
                if (rootInActiveWindow?.packageName?.toString() == pkg) {
                    block("📵 Application bloquée", appLabel(pkg))
                }
            }
            return
        }

        // 2) Navigateur autorisé -> vérifier les sites
        val ids = browsers[pkg] ?: return
        val sites = Prefs.blockedSites(this)
        if (sites.isEmpty()) return
        // Pendant la frappe il y a énormément d'événements : on ne vérifie qu'au plus
        // toutes les 1,2 s, pour que le clavier reste fluide.
        val now = System.currentTimeMillis()
        if (!isWindowChange && now - lastWebCheck < 1200) return
        lastWebCheck = now

        val root = rootInActiveWindow ?: return
        val texts = mutableListOf<String>()
        for (id in ids) {
            root.findAccessibilityNodeInfosByViewId(id)?.forEach { n ->
                // Barre d'adresse active = tu es en train d'écrire : on ne touche à rien.
                if (n.isFocused) return
                n.text?.toString()?.let { texts.add(it) }
            }
        }
        // Recherche complète seulement à l'ouverture d'une page (jamais pendant la frappe)
        if (texts.isEmpty() && isWindowChange) collectEditableTexts(root, texts, 0)

        for (t in texts) {
            val lower = t.lowercase()
            val hit = sites.firstOrNull { site -> site.isNotBlank() && lower.contains(site) }
            if (hit != null) {
                performGlobalAction(GLOBAL_ACTION_BACK)
                block("🌐 Site bloqué", hit)
                return
            }
        }
    }

    /** La fenêtre de désinstallation parle-t-elle de stop#app ? */
    private fun looksLikeUninstallOfMe(): Boolean {
        val root = rootInActiveWindow ?: return false
        val name = getString(R.string.app_name)
        val mentionsMe = !root.findAccessibilityNodeInfosByText(name).isNullOrEmpty()
        if (!mentionsMe) return false
        return listOf("désinstaller", "desinstaller", "uninstall").any {
            !root.findAccessibilityNodeInfosByText(it).isNullOrEmpty()
        }
    }

    /** Si on ne trouve pas la barre d'adresse, on lit les champs de saisie non actifs. */
    private fun collectEditableTexts(node: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (node == null || depth > 25 || out.size > 10) return
        if (node.isEditable && !node.isFocused) node.text?.toString()?.let { out.add(it) }
        for (i in 0 until node.childCount) collectEditableTexts(node.getChild(i), out, depth + 1)
    }

    private fun block(reason: String, what: String) {
        val now = System.currentTimeMillis()
        if (now - lastBlockTime < 600) return
        lastBlockTime = now
        Prefs.addBlock(this)
        // L'écran de blocage s'affiche PAR-DESSUS l'appli.
        val i = Intent(this, BlockedActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra(BlockedActivity.EXTRA_REASON, reason)
            .putExtra(BlockedActivity.EXTRA_WHAT, what)
        startActivity(i)
    }

    private fun appLabel(pkg: String): String = runCatching {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    }.getOrDefault(pkg)

    override fun onInterrupt() {}
}
