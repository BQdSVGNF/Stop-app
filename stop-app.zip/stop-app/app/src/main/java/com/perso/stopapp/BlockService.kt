package com.perso.stopapp

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Rect
import android.os.Build
import android.telecom.TelecomManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.view.inputmethod.InputMethodManager

/**
 * Le cœur de stop#app : surveille l'application au premier plan.
 * - Si le blocage est actif et que l'app n'est pas autorisée -> écran "bloqué" par-dessus.
 * - Dans Chrome, Edge et Google : lit l'adresse et bloque les sites de la liste
 *   (jamais pendant que tu tapes, pour ne pas ralentir le clavier).
 * - Si quelqu'un essaie de désinstaller ou d'arrêter stop#app (désinstallation, ou page
 *   de stop#app dans les Paramètres) -> questionnaire pour être sûr, puis accès autorisé.
 * - Les Paramètres, le menu d'extinction et les fenêtres système ne sont jamais bloqués.
 */
class BlockService : AccessibilityService() {

    /** Navigateurs surveillés et l'identifiant de leur barre d'adresse. */
    private val browsers = mapOf(
        "com.android.chrome" to listOf("com.android.chrome:id/url_bar"),
        "com.chrome.beta" to listOf("com.chrome.beta:id/url_bar"),
        "com.microsoft.emmx" to listOf(
            "com.microsoft.emmx:id/url_bar",
            "com.microsoft.emmx:id/search_box_text"
        ),
        "com.google.android.googlequicksearchbox" to listOf(
            "com.google.android.googlequicksearchbox:id/googleapp_search_box",
            "com.google.android.googlequicksearchbox:id/search_box"
        )
    )

    /** Fenêtres de désinstallation d'Android. */
    private val installers = setOf(
        "com.google.android.packageinstaller",
        "com.android.packageinstaller",
        "com.samsung.android.packageinstaller"
    )

    private var lastBlockTime = 0L
    private var lastAppCheck = 0L
    private var lastWebCheck = 0L
    private var systemAllowed: Set<String> = emptySet()
    private var launchers: Set<String> = emptySet()
    private val handler = Handler(Looper.getMainLooper())

    /** Paramètres du téléphone : jamais bloqués, mais surveillés pour la page de stop#app. */
    private val settingsPkgs = setOf("com.android.settings", "com.samsung.android.settings")

    /** Applis « ouvrables » (avec une icône). On ne bloque QUE celles-là : le menu
     *  d'extinction, les pop-ups système, etc. n'en font pas partie. */
    private var launchable: Set<String> = emptySet()
    private var launchableAt = 0L

    private fun isLaunchable(pkg: String): Boolean {
        val now = System.currentTimeMillis()
        if (now - launchableAt > 120_000 || launchable.isEmpty()) {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            launchable = packageManager.queryIntentActivities(i, 0).map { it.activityInfo.packageName }.toSet()
            launchableAt = now
        }
        return pkg in launchable
    }

    private var lastSnapLog = 0L
    private var lastGuardCheck = 0L
    private var lastGuardShown = 0L

    /**
     * Applis « outils » qu'une appli autorisée peut ouvrir (appareil photo, galerie,
     * contacts, fichiers, SMS de vérification, Play Store…). Ouvertes DEPUIS une appli
     * autorisée, elles sont autorisées le temps de revenir à l'accueil.
     */
    private val helperPkgs = setOf(
        "com.sec.android.app.camera", "com.google.android.GoogleCamera", "com.android.camera", "com.android.camera2",
        "com.sec.android.gallery3d", "com.google.android.apps.photos",
        "com.samsung.android.app.contacts", "com.samsung.android.contacts", "com.google.android.contacts", "com.android.contacts",
        "com.sec.android.app.myfiles", "com.google.android.apps.nbu.files",
        "com.samsung.android.messaging", "com.google.android.apps.messaging",
        "com.android.vending", "com.samsung.android.samsungpass", "com.osp.app.signin",
        "com.samsung.android.app.notes", "com.google.android.apps.docs"
    )
    /** Blocage d'une partie de Snapchat (Stories/Spotlight) et YouTube (Shorts). */
    private val partial by lazy { PartialBlocker(this) }

    /** Dernier moment où une appli autorisée était à l'écran. */
    private var lastAllowedAt = 0L
    /** Applis ouvertes depuis une appli autorisée (autorisées jusqu'au retour à l'accueil). */
    private val followed = mutableSetOf<String>()

    /** Vérifie toutes les 30 s : notifications de prévention et widget. */
    private val ticker = object : Runnable {
        override fun run() {
            runCatching { Notifier.check(this@BlockService) }
            // Nouvelles applis « laisser passer » choisies pendant un blocage : autorisées à la pause
            runCatching { Prefs.applyPendingAllow(this@BlockService) }
            runCatching { StopWidget.updateAll(this@BlockService) }
            handler.postDelayed(this, 30_000)
        }
    }

    /** Caches posés sur les applis bloquées en fenêtre / écran partagé. */
    private val guard by lazy { WindowGuard(this) }

    /**
     * Vérifie CHAQUE SECONDE, à toute heure, sans attendre un « événement » :
     * - Shorts (YouTube) et Stories/Spotlight (Snapchat) : bloqués en permanence ;
     * - applis bloquées mises en fenêtre ou en écran partagé.
     */
    private val fastTicker = object : Runnable {
        override fun run() {
            runCatching { scanWindows() }
            handler.postDelayed(this, 1_000)
        }
    }

    /** Nouvelle appli installée -> fenêtre « Bloquer / Laisser passer ». */
    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.getBooleanExtra(Intent.EXTRA_REPLACING, false)) return   // simple mise à jour
            val newPkg = intent.data?.schemeSpecificPart ?: return
            launchableAt = 0   // la liste des applis a changé
            if (newPkg == packageName) return
            // Laisser le Play Store finir l'installation avant d'afficher la question
            handler.postDelayed({ askAboutNewApp(newPkg) }, 1_200)
        }
    }

    private fun askAboutNewApp(newPkg: String) {
        // Seulement les vraies applis (avec une icône) qui ne sont pas déjà autorisées
        if (packageManager.getLaunchIntentForPackage(newPkg) == null) return
        if (newPkg in Prefs.allowedApps(this) || newPkg in systemAllowed) return
        runCatching {
            startActivity(
                Intent(this, NewAppActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    .putExtra(NewAppActivity.EXTRA_PKG, newPkg)
            )
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        handler.removeCallbacks(fastTicker)
        runCatching { unregisterReceiver(packageReceiver) }
        runCatching { guard.clear() }
        super.onDestroy()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Prefs.migrate(this)
        Notifier.ensureChannel(this)
        handler.removeCallbacks(ticker)
        handler.post(ticker)
        handler.removeCallbacks(fastTicker)
        handler.postDelayed(fastTicker, 1_000)
        runCatching { unregisterReceiver(packageReceiver) }
        runCatching {
            val f = IntentFilter(Intent.ACTION_PACKAGE_ADDED).apply { addDataScheme("package") }
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(packageReceiver, f, RECEIVER_EXPORTED)
            else registerReceiver(packageReceiver, f)
        }
        systemAllowed = computeSystemAllowed() - PartialBlocker.PACKAGES
        android.util.Log.d("STOPAPP", "systemAllowed=$systemAllowed")
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        launchers = packageManager.queryIntentActivities(home, 0).map { it.activityInfo.packageName }.toSet()
    }

    /** Apps qu'on ne bloque jamais : stop#app, l'écran d'accueil, le clavier, le téléphone (urgences)... */
    private fun computeSystemAllowed(): Set<String> {
        val set = mutableSetOf(
            packageName,
            "android",
            "com.android.settings",
            "com.samsung.android.settings",
            "com.android.systemui",
            "com.google.android.permissioncontroller",
            "com.android.permissioncontroller",
            "com.google.android.packageinstaller",
            "com.android.packageinstaller",
            "com.samsung.android.packageinstaller",
            "com.android.emergency",
            "com.google.android.dialer",
            "com.android.dialer",
            "com.samsung.android.dialer",
            "com.android.phone",
            "com.android.incallui",
            "com.samsung.android.incallui",
            "com.android.server.telecom",
            // Fenêtres système ouvertes PAR une appli autorisée (partage, fichiers, photos,
            // connexion Google, navigateur intégré…) : ne jamais les bloquer.
            "com.android.intentresolver",
            "com.android.documentsui",
            "com.google.android.documentsui",
            "com.android.providers.media.module",
            "com.google.android.providers.media.module",
            "com.google.android.gms",
            "com.google.android.webview",
            "com.android.webview",
            "com.google.android.captiveportallogin",
            "com.samsung.android.app.sharelive",
            "com.samsung.android.app.smartcapture",
            "com.android.credentialmanager",
            // Claviers courants (en plus de ceux détectés plus bas)
            "com.samsung.android.honeyboard",
            "com.google.android.inputmethod.latin",
            "com.touchtype.swiftkey"
        )
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        // Seul l'écran d'accueil réellement utilisé (avant : toutes les applis qui se
        // déclaraient « accueil », ce qui faisait passer Snapchat pour une appli système)
        packageManager.resolveActivity(home, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)
            ?.activityInfo?.packageName?.let { if (it != "android") set.add(it) }
        val homes = packageManager.queryIntentActivities(home, 0).map { it.activityInfo.packageName }
        android.util.Log.d("STOPAPP", "HOME candidats=$homes")
        homes.filter { it.contains("launcher") || it.contains("home") || it == "com.sec.android.app.launcher" }
            .forEach { set.add(it) }
        runCatching {
            (getSystemService(TELECOM_SERVICE) as TelecomManager).defaultDialerPackage?.let { set.add(it) }
        }
        runCatching {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.enabledInputMethodList.forEach { set.add(it.packageName) }
        }
        return set
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        // Fenêtres déplacées / redimensionnées / écran partagé : on revérifie tout de suite
        if (event.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED) {
            runCatching { scanWindows() }
            return
        }
        val pkg = event.packageName?.toString() ?: return
        val isWindowChange = event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
        if (pkg.contains("snapchat") && (isWindowChange || System.currentTimeMillis() - lastSnapLog > 2000)) {
            lastSnapLog = System.currentTimeMillis()
            android.util.Log.d("STOPAPP", "SNAP event type=${event.eventType} class=${event.className} " +
                "active=${rootInActiveWindow?.packageName} systemAllowed=${pkg in systemAllowed} " +
                "blocking=${Prefs.isBlockingNow(this)} allowed=${pkg in Prefs.allowedApps(this)}")
        }

        // 0) Protection de stop#app (à toute heure) :
        //    - fenêtre de désinstallation de stop#app
        //    - page de stop#app dans les Paramètres (infos de l'appli, accessibilité)
        if (!Prefs.uninstallAllowed(this)) {
            val isUninstallWindow = pkg in installers ||
                (pkg in launchers && event.className?.toString()?.contains("Dialog") == true)
            if (isWindowChange && isUninstallWindow && looksLikeUninstallOfMe()) {
                showGuard(QuitActivity.MODE_UNINSTALL)
                return
            }
            if (pkg in settingsPkgs) {
                val now = System.currentTimeMillis()
                if (isWindowChange || now - lastGuardCheck > 700) {
                    lastGuardCheck = now
                    if (looksLikeMySettingsPage()) {
                        showGuard(QuitActivity.MODE_SETTINGS)
                        return
                    }
                }
            }
        }

        // Retour à l'écran d'accueil : on oublie les applis « suivies »
        if (isWindowChange && pkg in launchers) followed.clear()

        // Snapchat (Stories, Spotlight) et YouTube (Shorts) : vérifiés AVANT tout le reste,
        // à toute heure (même pendant les pauses, la pause bonus et le mode modification)
        if (pkg in PartialBlocker.PACKAGES) partial.onEvent(pkg, isWindowChange)

        if (pkg in systemAllowed && pkg !in PartialBlocker.PACKAGES) return

        if (!Prefs.isBlockingNow(this)) return
        // Seules les vraies applis (avec une icône) peuvent être bloquées :
        // le menu Éteindre / Redémarrer et les fenêtres système passent toujours.
        if (!isLaunchable(pkg)) return

        // Mode Focus : les applis autorisées passent, sauf si le Focus strict est activé
        val focus = Prefs.inFocus(this)
        val baseAllowed = if (focus && Prefs.focusStrict(this)) emptySet() else Prefs.allowedApps(this)
        val allowed = baseAllowed + followed
        val reason = if (focus) "Mode Focus en cours" else "Application bloquée"
        val now0 = System.currentTimeMillis()

        if (pkg in allowed) {
            lastAllowedAt = now0
        } else if (isWindowChange && baseAllowed.isNotEmpty() && now0 - lastAllowedAt < 4000) {
            // Écran ouvert DEPUIS une appli autorisée : navigateur intégré (lien),
            // appareil photo, galerie, contacts… -> on le laisse passer.
            val cls = event.className?.toString() ?: ""
            if (pkg in helperPkgs || cls.contains("CustomTab", ignoreCase = true)) {
                followed.add(pkg)
                lastAllowedAt = now0
                return
            }
        }

        // 1) Application non autorisée -> bloquée tout de suite
        if (pkg !in allowed) {
            if (isWindowChange) {
                // On ne bloque que les vrais écrans d'appli (pas les bulles, toasts ou
                // petites fenêtres qu'une autre appli affiche par-dessus ton appli autorisée)
                if (isRealScreen(pkg, event.className?.toString())) block(reason, appLabel(pkg))
            } else {
                // Rattrapage : certaines applis s'affichent sans « changement de fenêtre ».
                val now = System.currentTimeMillis()
                if (now - lastAppCheck < 500) return
                lastAppCheck = now
                if (rootInActiveWindow?.packageName?.toString() == pkg) block(reason, appLabel(pkg))
            }
            return
        }

        // 2) Navigateur autorisé -> vérifier les sites
        val ids = browsers[pkg] ?: return
        val sites = Prefs.blockedSites(this)
        if (sites.isEmpty()) return
        // Pendant la frappe il y a énormément d'événements : on ne vérifie qu'au plus
        // toutes les 1,2 s, pour que le clavier reste fluide.
        val now = System.currentTimeMillis()
        if (!isWindowChange && now - lastWebCheck < 1200) return
        lastWebCheck = now

        val root = rootInActiveWindow ?: return
        val texts = mutableListOf<String>()
        for (id in ids) {
            root.findAccessibilityNodeInfosByViewId(id)?.forEach { n ->
                // Barre d'adresse active = tu es en train d'écrire : on ne touche à rien.
                if (n.isFocused) return
                n.text?.toString()?.let { texts.add(it) }
            }
        }
        // Recherche complète seulement à l'ouverture d'une page (jamais pendant la frappe)
        if (texts.isEmpty() && isWindowChange) collectEditableTexts(root, texts, 0)

        for (t in texts) {
            val lower = t.lowercase()
            val hit = sites.firstOrNull { site -> site.isNotBlank() && lower.contains(site) }
            if (hit != null) {
                performGlobalAction(GLOBAL_ACTION_BACK)
                block("Site bloqué", hit)
                return
            }
        }
    }

    /**
     * Parcourt toutes les fenêtres visibles (plein écran, écran partagé, pop-up) :
     * 1) YouTube / Snapchat visibles -> vérification Shorts / Stories, à toute heure ;
     * 2) pendant un blocage, appli bloquée visible À CÔTÉ d'une autre fenêtre -> cache par-dessus.
     */
    private fun scanWindows() {
        val wins = runCatching { windows }.getOrNull() ?: return
        val apps = wins.filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION }
        val roots = apps.mapNotNull { w -> w.root?.packageName?.toString()?.let { w to it } }

        // 1) Blocage partiel permanent
        roots.map { it.second }.filter { it in PartialBlocker.PACKAGES }.distinct()
            .forEach { partial.onEvent(it, false) }

        // 2) Multi-fenêtre
        if (!Prefs.isBlockingNow(this)) {
            if (!guard.isEmpty()) guard.clear()
            return
        }
        val screen = Rect(0, 0, resources.displayMetrics.widthPixels, resources.displayMetrics.heightPixels)
        val multi = roots.map { it.second }.distinct().size >= 2
        val targets = HashMap<Int, Pair<Rect, String>>()
        val now = System.currentTimeMillis()
        fun isFull(r: Rect) = r.width() >= screen.width() * 0.95 && r.height() >= screen.height() * 0.85
        // L'écran de blocage de stop#app est déjà en plein écran : rien à cacher en plein écran
        val myFull = roots.any { (w, p) -> p == packageName && isFull(Rect().also { w.getBoundsInScreen(it) }) }
        for ((w, p) in roots) {
            if (!isBlockedPkg(p)) continue
            // Appareil photo, galerie… ouverts depuis une appli autorisée : on laisse
            if (p in helperPkgs && now - lastAllowedAt < 4000) continue
            val r = Rect().also { w.getBoundsInScreen(it) }
            if (r.isEmpty) continue
            // Plein écran tout seul : déjà géré par l'écran de blocage normal
            if (isFull(r) && (!multi || myFull)) continue
            targets[w.id] = r to p
        }
        guard.update(targets)
    }

    /** Cette appli doit-elle être bloquée en ce moment ? */
    private fun isBlockedPkg(p: String): Boolean {
        if (p == packageName || p in systemAllowed || p in launchers) return false
        if (!isLaunchable(p)) return false
        val focus = Prefs.inFocus(this)
        val baseAllowed = if (focus && Prefs.focusStrict(this)) emptySet() else Prefs.allowedApps(this)
        return p !in baseAllowed && p !in followed
    }

    private val screenCache = HashMap<String, Boolean>()

    /**
     * Vrai si la fenêtre est un écran d'appli (Activity) au premier plan.
     * Les toasts, bulles et pop-ups d'une autre appli n'en sont pas : on les ignore.
     */
    private fun isRealScreen(pkg: String, cls: String?): Boolean {
        if (cls.isNullOrEmpty()) return rootInActiveWindow?.packageName?.toString() == pkg
        return screenCache.getOrPut("$pkg/$cls") {
            runCatching { packageManager.getActivityInfo(ComponentName(pkg, cls), 0); true }
                .getOrElse { rootInActiveWindow?.packageName?.toString() == pkg }
        }
    }

    /**
     * Quitte d'abord la fenêtre (retour), PUIS affiche le questionnaire un peu après.
     * (Avant, le « retour » arrivait sur le questionnaire et le fermait aussitôt.)
     */
    private fun showGuard(mode: String) {
        val now = System.currentTimeMillis()
        if (now - lastGuardShown < 2500) return
        lastGuardShown = now
        performGlobalAction(GLOBAL_ACTION_BACK)
        handler.postDelayed({
            startActivity(
                Intent(this, QuitActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    .putExtra(QuitActivity.EXTRA_MODE, mode)
            )
        }, 450)
    }

    /** Page de stop#app dans les Paramètres : infos de l'appli ou réglage d'accessibilité. */
    private fun looksLikeMySettingsPage(): Boolean {
        val root = rootInActiveWindow ?: return false
        if (root.findAccessibilityNodeInfosByText(getString(R.string.app_name)).isNullOrEmpty()) return false
        val keys = listOf(
            "Désinstaller", "Forcer l'arrêt", "Forcer arrêt", "Arrêt forcé", "Uninstall", "Force stop",
            "Utiliser stop#app", "Use stop#app",
            // description du service, affichée sur la page d'accessibilité de stop#app
            "bloque toutes les applications"
        )
        return keys.any { !root.findAccessibilityNodeInfosByText(it).isNullOrEmpty() }
    }

    /** La fenêtre de désinstallation parle-t-elle de stop#app ? */
    private fun looksLikeUninstallOfMe(): Boolean {
        val root = rootInActiveWindow ?: return false
        val name = getString(R.string.app_name)
        val mentionsMe = !root.findAccessibilityNodeInfosByText(name).isNullOrEmpty()
        if (!mentionsMe) return false
        return listOf("désinstaller", "desinstaller", "uninstall").any {
            !root.findAccessibilityNodeInfosByText(it).isNullOrEmpty()
        }
    }

    /** Si on ne trouve pas la barre d'adresse, on lit les champs de saisie non actifs. */
    private fun collectEditableTexts(node: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (node == null || depth > 25 || out.size > 10) return
        if (node.isEditable && !node.isFocused) node.text?.toString()?.let { out.add(it) }
        for (i in 0 until node.childCount) collectEditableTexts(node.getChild(i), out, depth + 1)
    }

    private fun block(reason: String, what: String) {
        val now = System.currentTimeMillis()
        if (now - lastBlockTime < 600) return
        lastBlockTime = now
        Prefs.addBlock(this)
        StopWidget.updateAll(this)
        // L'écran de blocage s'affiche PAR-DESSUS l'appli.
        val i = Intent(this, BlockedActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra(BlockedActivity.EXTRA_REASON, reason)
            .putExtra(BlockedActivity.EXTRA_WHAT, what)
        startActivity(i)
    }

    private fun appLabel(pkg: String): String = runCatching {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    }.getOrDefault(pkg)

    override fun onInterrupt() {}
}
