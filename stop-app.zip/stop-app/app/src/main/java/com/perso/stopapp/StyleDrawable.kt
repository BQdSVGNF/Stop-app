package com.perso.stopapp

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

/**
 * Fond « design » de stop#app, aux couleurs du thème choisi :
 * dégradé, Soft 3D, lignes de niveau, trame ou blueprint.
 * Le dessin est calculé une fois par taille puis gardé en mémoire.
 */
class StyleDrawable(
    context: Context,
    private val style: Look.Style,
    private val theme: Look.Theme,
    private val bottomRadius: Float = 0f,
    private val alpha255: Int = 255
) : Drawable() {

    private val density = context.resources.displayMetrics.density
    private var cache: Bitmap? = null
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)

    override fun onBoundsChange(bounds: Rect) {
        super.onBoundsChange(bounds)
        cache?.recycle()
        cache = null
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        if (b.width() <= 0 || b.height() <= 0) return
        val bmp = cache ?: render(b.width(), b.height()).also { cache = it }
        bmpPaint.alpha = alpha255
        canvas.drawBitmap(bmp, b.left.toFloat(), b.top.toFloat(), bmpPaint)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT

    // ------------------------------------------------------------------

    private fun render(w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        if (bottomRadius > 0f) {
            // Coins du bas arrondis (en-tête)
            val clip = Path().apply {
                addRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()),
                    floatArrayOf(0f, 0f, 0f, 0f, bottomRadius, bottomRadius, bottomRadius, bottomRadius), Path.Direction.CW)
            }
            c.clipPath(clip)
        }
        when (style) {
            Look.Style.MINIMAL -> c.drawColor(Color.parseColor("#F2F2F7"))
            Look.Style.GRADIENT -> gradient(c, w, h)
            Look.Style.SOFT3D -> soft3d(c, w, h)
            Look.Style.CONTOUR -> contour(c, w, h)
            Look.Style.HALFTONE -> halftone(c, w, h)
            Look.Style.BLUEPRINT -> blueprint(c, w, h)
        }
        return bmp
    }

    private fun gradient(c: Canvas, w: Int, h: Int) {
        val p = Paint()
        p.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), theme.colors, null, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
    }

    // ---------- Soft 3D : formes douces avec ombres et reflets (couleurs du modèle) ----------

    private class Tone(val base: Int, val light: Int, val dark: Int, val shadow: Int)
    private val violet = Tone(c("#9A7BF5"), c("#F4F0FF"), c("#7350E6"), c("#8C7BE0"))
    private val peach = Tone(c("#FF9A6E"), c("#FFF3EC"), c("#FF7A45"), c("#F0A080"))
    private val mint = Tone(c("#5BD3B2"), c("#F0FFFA"), c("#2DB38F"), c("#7FD0C0"))
    private val sun = Tone(c("#FAD36A"), c("#FFFBEA"), c("#F2B935"), c("#E9C070"))

    private fun soft3d(cv: Canvas, w: Int, h: Int) {
        val bg = Paint()
        bg.shader = LinearGradient(0f, 0f, w * 0.6f, h * 1f,
            intArrayOf(c("#F3E6FF"), c("#E6ECFF"), c("#FDEFE6")), null, Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bg)

        val s = min(w, h).toFloat()
        when {
            w < 150 * density -> {
                // Petit aperçu : la composition du modèle
                sphere(cv, w * 0.25f, h * 0.36f, s * 0.20f, violet)
                blob(cv, w * 0.52f, h * 0.47f, s * 0.17f, s * 0.135f, 12f, peach)
                blob(cv, w * 0.74f, h * 0.27f, s * 0.15f, s * 0.135f, -20f, mint)
                sphere(cv, w * 0.77f, h * 0.62f, s * 0.08f, sun)
            }
            h < w * 0.75f -> {
                // Bandeau (en-tête) : le texte est à gauche, les formes à droite et en bas
                sphere(cv, w * 0.80f, h * 0.58f, s * 0.22f, violet)
                blob(cv, w * 0.99f, h * 0.95f, s * 0.15f, s * 0.12f, -18f, mint)
                blob(cv, w * 0.60f, h * 1.02f, s * 0.13f, s * 0.10f, 12f, peach)
                sphere(cv, w * 0.64f, h * 0.70f, s * 0.05f, sun)
            }
            else -> {
                // Écran entier : formes à moitié sorties sur les bords, le texte reste lisible
                sphere(cv, w * 1.00f, h * 0.10f, s * 0.26f, violet)
                blob(cv, w * 0.00f, h * 0.42f, s * 0.17f, s * 0.15f, -20f, mint)
                blob(cv, w * 1.00f, h * 0.70f, s * 0.19f, s * 0.15f, 12f, peach)
                sphere(cv, w * 0.10f, h * 0.94f, s * 0.11f, sun)
            }
        }
    }

    private fun c(hex: String) = Color.parseColor(hex)

    /** Ombre floue sous la forme, légèrement décalée vers le bas. */
    private fun shadowPaint(t: Tone, r: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = withAlpha(t.shadow, 115)
        maskFilter = BlurMaskFilter(r * 0.25f, BlurMaskFilter.Blur.NORMAL)
    }

    /** Reflet : lumière en haut à gauche, couleur pleine, bord plus foncé. */
    private fun shine(cx: Float, cy: Float, r: Float, t: Tone) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = RadialGradient(cx - r * 0.38f, cy - r * 0.42f, r * 1.75f,
            intArrayOf(t.light, t.base, t.dark), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
    }

    private fun sphere(cv: Canvas, cx: Float, cy: Float, r: Float, t: Tone) {
        cv.drawCircle(cx, cy + r * 0.35f, r * 0.9f, shadowPaint(t, r))
        cv.drawCircle(cx, cy, r, shine(cx, cy, r, t))
    }

    private fun blob(cv: Canvas, cx: Float, cy: Float, rw: Float, rh: Float, angle: Float, t: Tone) {
        cv.save()
        cv.rotate(angle, cx, cy)
        val rect = RectF(cx - rw, cy - rh, cx + rw, cy + rh)
        val rad = rh * 0.72f
        cv.drawRoundRect(RectF(rect).apply { offset(0f, rh * 0.35f) }, rad, rad, shadowPaint(t, rh))
        cv.drawRoundRect(rect, rad, rad, shine(cx, cy, maxOf(rw, rh), t))
        cv.restore()
    }

    // ---------- Lignes de niveau (carte topographique) ----------

    private fun contour(c: Canvas, w: Int, h: Int) {
        // Couleurs du modèle : vert forêt profond et lignes vert citron
        c.drawColor(Color.parseColor("#0F2A21"))
        val line = Color.parseColor("#B9E772")
        val step = (7 * density).coerceAtLeast(6f)
        val gw = (w / step).toInt() + 2
        val gh = (h / step).toInt() + 2
        val f = Array(gh) { FloatArray(gw) }
        // Relief : quelques collines et creux, toujours les mêmes
        val bumps = listOf(
            floatArrayOf(0.15f, 0.12f, 1.0f, 0.28f), floatArrayOf(0.80f, 0.20f, -0.9f, 0.30f),
            floatArrayOf(0.45f, 0.48f, 0.8f, 0.25f), floatArrayOf(0.10f, 0.75f, -0.7f, 0.30f),
            floatArrayOf(0.85f, 0.70f, 1.1f, 0.28f), floatArrayOf(0.50f, 0.95f, -0.8f, 0.30f),
            floatArrayOf(0.30f, 0.30f, -0.5f, 0.18f)
        )
        val diag = hypot(w.toFloat(), h.toFloat())
        var lo = Float.MAX_VALUE
        var hi = -Float.MAX_VALUE
        for (j in 0 until gh) for (i in 0 until gw) {
            val x = i * step
            val y = j * step
            var v = 0f
            for (b in bumps) {
                val dx = (x - b[0] * w) / (b[3] * diag)
                val dy = (y - b[1] * h) / (b[3] * diag)
                v += b[2] * exp(-(dx * dx + dy * dy))
            }
            v += 0.08f * sin(x / diag * 9f + y / diag * 5f)
            f[j][i] = v
            if (v < lo) lo = v
            if (v > hi) hi = v
        }
        val levels = 40
        val thin = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = density * 0.9f; color = withAlpha(line, 95) }
        val bold = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = density * 1.4f; color = withAlpha(line, 220) }
        for (k in 1 until levels) {
            val iso = lo + (hi - lo) * k / levels
            val path = Path()
            for (j in 0 until gh - 1) for (i in 0 until gw - 1) {
                val a = f[j][i]; val b = f[j][i + 1]; val cc = f[j + 1][i + 1]; val d = f[j + 1][i]
                val pts = ArrayList<Float>(8)
                fun edge(v1: Float, v2: Float, x1: Float, y1: Float, x2: Float, y2: Float) {
                    if ((v1 < iso) != (v2 < iso)) {
                        val t = (iso - v1) / (v2 - v1)
                        pts.add(x1 + (x2 - x1) * t); pts.add(y1 + (y2 - y1) * t)
                    }
                }
                val x0 = i * step; val y0 = j * step; val x1 = x0 + step; val y1 = y0 + step
                edge(a, b, x0, y0, x1, y0)
                edge(b, cc, x1, y0, x1, y1)
                edge(cc, d, x1, y1, x0, y1)
                edge(d, a, x0, y1, x0, y0)
                var p = 0
                while (p + 3 < pts.size) {
                    path.moveTo(pts[p], pts[p + 1]); path.lineTo(pts[p + 2], pts[p + 3]); p += 4
                }
            }
            c.drawPath(path, if (k % 6 == 0) bold else thin)
        }
    }

    // ---------- Trame (points) ----------

    private fun halftone(c: Canvas, w: Int, h: Int) {
        gradient(c, w, h)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(60, 255, 255, 255) }
        val step = 14 * density
        var y = step / 2
        while (y < h) {
            var x = step / 2
            while (x < w) {
                val t = ((x / w) + (y / h)) / 2f
                c.drawCircle(x, y, step * (0.08f + 0.30f * t), p)
                x += step
            }
            y += step
        }
    }

    // ---------- Blueprint (plan quadrillé) ----------

    private fun blueprint(c: Canvas, w: Int, h: Int) {
        c.drawColor(mix(theme.colors[0], Color.parseColor("#0D1B2A"), 0.75f))
        val step = 22 * density
        val thin = Paint().apply { color = Color.argb(28, 255, 255, 255); strokeWidth = 1f }
        val bold = Paint().apply { color = Color.argb(55, 255, 255, 255); strokeWidth = density }
        var i = 0
        var x = 0f
        while (x < w) { c.drawLine(x, 0f, x, h.toFloat(), if (i % 4 == 0) bold else thin); x += step; i++ }
        i = 0
        var y = 0f
        while (y < h) { c.drawLine(0f, y, w.toFloat(), y, if (i % 4 == 0) bold else thin); y += step; i++ }
        val circle = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = density; color = Color.argb(70, 255, 255, 255) }
        c.drawCircle(w * 0.85f, h * 0.18f, min(w, h) * 0.22f, circle)
        c.drawCircle(w * 0.85f, h * 0.18f, min(w, h) * 0.12f, circle)
    }

    companion object {
        fun mix(a: Int, b: Int, t: Float): Int = Color.rgb(
            (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
        )
        fun darken(a: Int, f: Float): Int = Color.rgb((Color.red(a) * f).toInt(), (Color.green(a) * f).toInt(), (Color.blue(a) * f).toInt())
        fun withAlpha(a: Int, alpha: Int): Int = Color.argb(alpha, Color.red(a), Color.green(a), Color.blue(a))
    }
}
