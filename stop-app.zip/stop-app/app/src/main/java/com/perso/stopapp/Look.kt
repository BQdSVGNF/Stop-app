package com.perso.stopapp

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable

/**
 * Thèmes de couleurs de stop#app : en-tête, écran de blocage, questionnaire
 * et cache posé sur les fenêtres bloquées.
 */
object Look {

    class Theme(val id: String, val name: String, val emoji: String, hex: List<String>, accentHex: String) {
        val colors: IntArray = hex.map { Color.parseColor(it) }.toIntArray()
        val accent: Int = Color.parseColor(accentHex)
    }

    val themes = listOf(
        Theme("corail", "Corail", "🔥", listOf("#FF416C", "#FF4B2B", "#6C5CE7"), "#FF416C"),
        Theme("ocean", "Océan", "🌊", listOf("#0052D4", "#4364F7", "#4FACFE"), "#0052D4"),
        Theme("foret", "Forêt", "🌿", listOf("#0B6E4F", "#11998E", "#38D98E"), "#0B8457"),
        Theme("aurore", "Aurore", "🌌", listOf("#4A00E0", "#8E2DE2", "#FF6CAB"), "#7B2FF7"),
        Theme("soleil", "Soleil", "☀️", listOf("#FF5E62", "#FF8A3D", "#F7B733"), "#F0643C"),
        Theme("nuit", "Nuit", "🌙", listOf("#0F2027", "#203A43", "#2C5364"), "#2C7DA0")
    )

    private const val KEY = "look_theme"

    fun current(c: Context): Theme {
        val id = c.getSharedPreferences("stopapp", Context.MODE_PRIVATE).getString(KEY, "corail")
        return themes.firstOrNull { it.id == id } ?: themes[0]
    }

    fun set(c: Context, id: String) =
        c.getSharedPreferences("stopapp", Context.MODE_PRIVATE).edit().putString(KEY, id).apply()

    /** Dégradé du thème. [alpha] 0..255 ; [bottomRadius] en pixels (coins du bas arrondis). */
    fun gradient(t: Theme, reversed: Boolean = false, alpha: Int = 255, bottomRadius: Float = 0f): GradientDrawable {
        val cols = (if (reversed) t.colors.reversedArray() else t.colors)
            .map { Color.argb(alpha, Color.red(it), Color.green(it), Color.blue(it)) }.toIntArray()
        return GradientDrawable(GradientDrawable.Orientation.TL_BR, cols).apply {
            if (bottomRadius > 0f) cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, bottomRadius, bottomRadius, bottomRadius, bottomRadius)
        }
    }

    /** Barres du haut et du bas aux couleurs du thème. */
    @Suppress("DEPRECATION")
    fun applyBars(a: Activity, t: Theme, reversed: Boolean = false) {
        val first = if (reversed) t.colors.last() else t.colors.first()
        val last = if (reversed) t.colors.first() else t.colors.last()
        a.window.statusBarColor = first
        a.window.navigationBarColor = last
    }
}
