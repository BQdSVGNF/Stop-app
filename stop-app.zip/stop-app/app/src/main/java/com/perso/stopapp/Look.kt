package com.perso.stopapp

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable

/**
 * Thèmes de couleurs de stop#app : en-tête, écran de blocage, questionnaire
 * et cache posé sur les fenêtres bloquées.
 */
object Look {

    class Theme(val id: String, val name: String, val emoji: String, hex: List<String>, accentHex: String) {
        val colors: IntArray = hex.map { Color.parseColor(it) }.toIntArray()
        val accent: Int = Color.parseColor(accentHex)
    }

    val themes = listOf(
        Theme("corail", "Corail", "🔥", listOf("#FF416C", "#FF4B2B", "#6C5CE7"), "#FF416C"),
        Theme("ocean", "Océan", "🌊", listOf("#0052D4", "#4364F7", "#4FACFE"), "#0052D4"),
        Theme("foret", "Forêt", "🌿", listOf("#0B6E4F", "#11998E", "#38D98E"), "#0B8457"),
        Theme("aurore", "Aurore", "🌌", listOf("#4A00E0", "#8E2DE2", "#FF6CAB"), "#7B2FF7"),
        Theme("soleil", "Soleil", "☀️", listOf("#FF5E62", "#FF8A3D", "#F7B733"), "#F0643C"),
        Theme("nuit", "Nuit", "🌙", listOf("#0F2027", "#203A43", "#2C5364"), "#2C7DA0")
    )

    // ---------- Designs (le fond) ----------

    enum class Style(val label: String, val emoji: String, val light: Boolean = false) {
        GRADIENT("Dégradé", "🌈"),
        SOFT3D("Soft 3D", "🫧", light = true),
        CONTOUR("Lignes de niveau", "🗺️"),
        HALFTONE("Trame", "⚫"),
        BLUEPRINT("Blueprint", "📐");
    }

    private const val KEY_STYLE = "look_style"

    fun style(c: Context): Style {
        val n = c.getSharedPreferences("stopapp", Context.MODE_PRIVATE).getString(KEY_STYLE, Style.GRADIENT.name)
        return Style.values().firstOrNull { it.name == n } ?: Style.GRADIENT
    }

    fun setStyle(c: Context, s: Style) =
        c.getSharedPreferences("stopapp", Context.MODE_PRIVATE).edit().putString(KEY_STYLE, s.name).apply()

    /** Fond complet (design + thème) pour un écran. */
    fun background(c: Context, bottomRadius: Float = 0f, alpha: Int = 255): android.graphics.drawable.Drawable =
        StyleDrawable(c, style(c), current(c), bottomRadius, alpha)

    private val INK = Color.parseColor("#1E1B2E")

    /**
     * Design clair (Soft 3D) : les textes et icônes blancs passent en foncé, sinon on les remet en blanc.
     * Les boutons gardent leurs couleurs.
     */
    fun tintTree(v: android.view.View, light: Boolean) {
        when (v) {
            is android.widget.Button -> return
            is android.widget.TextView -> {
                val orig = (v.getTag(R.id.orig_text_color) as? Int) ?: v.currentTextColor.also { v.setTag(R.id.orig_text_color, it) }
                val whiteish = Color.red(orig) > 225 && Color.green(orig) > 225 && Color.blue(orig) > 225
                if (whiteish) v.setTextColor(if (light) Color.argb(Color.alpha(orig), Color.red(INK), Color.green(INK), Color.blue(INK)) else orig)
            }
            is android.widget.ImageView -> {
                val orig = (v.getTag(R.id.orig_tint) as? android.content.res.ColorStateList)
                    ?: v.imageTintList?.also { v.setTag(R.id.orig_tint, it) }
                val white = orig?.defaultColor?.let { Color.red(it) > 225 && Color.green(it) > 225 && Color.blue(it) > 225 } == true
                if (white) v.imageTintList = if (light) android.content.res.ColorStateList.valueOf(INK) else orig
            }
            is android.view.ViewGroup -> for (i in 0 until v.childCount) tintTree(v.getChildAt(i), light)
        }
    }

    private const val KEY = "look_theme"

    fun current(c: Context): Theme {
        val id = c.getSharedPreferences("stopapp", Context.MODE_PRIVATE).getString(KEY, "corail")
        return themes.firstOrNull { it.id == id } ?: themes[0]
    }

    fun set(c: Context, id: String) =
        c.getSharedPreferences("stopapp", Context.MODE_PRIVATE).edit().putString(KEY, id).apply()

    /** Dégradé du thème. [alpha] 0..255 ; [bottomRadius] en pixels (coins du bas arrondis). */
    fun gradient(t: Theme, reversed: Boolean = false, alpha: Int = 255, bottomRadius: Float = 0f): GradientDrawable {
        val cols = (if (reversed) t.colors.reversedArray() else t.colors)
            .map { Color.argb(alpha, Color.red(it), Color.green(it), Color.blue(it)) }.toIntArray()
        return GradientDrawable(GradientDrawable.Orientation.TL_BR, cols).apply {
            if (bottomRadius > 0f) cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, bottomRadius, bottomRadius, bottomRadius, bottomRadius)
        }
    }

    /** Barres du haut et du bas aux couleurs du thème. */
    @Suppress("DEPRECATION")
    fun applyBars(a: Activity, t: Theme, reversed: Boolean = false) {
        // Barres transparentes : le design passe dessous ; icônes foncées si le design est clair
        val light = style(a).light
        if (android.os.Build.VERSION.SDK_INT >= 35) {
            a.window.statusBarColor = Color.TRANSPARENT
            a.window.navigationBarColor = Color.TRANSPARENT
        } else {
            val first = if (reversed) t.colors.last() else t.colors.first()
            val last = if (reversed) t.colors.first() else t.colors.last()
            a.window.statusBarColor = if (light) StyleDrawable.mix(first, Color.WHITE, 0.88f) else if (style(a) == Style.CONTOUR || style(a) == Style.BLUEPRINT) StyleDrawable.mix(first, Color.BLACK, 0.8f) else first
            a.window.navigationBarColor = if (light) StyleDrawable.mix(last, Color.WHITE, 0.9f) else if (style(a) == Style.CONTOUR || style(a) == Style.BLUEPRINT) StyleDrawable.mix(first, Color.BLACK, 0.8f) else last
        }
        androidx.core.view.WindowCompat.getInsetsController(a.window, a.window.decorView).apply {
            isAppearanceLightStatusBars = light
            isAppearanceLightNavigationBars = light
        }
    }
}
