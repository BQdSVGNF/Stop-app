package com.perso.stopapp

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.View

/**
 * Thèmes de couleurs de stop#app : en-tête, écran de blocage, questionnaire
 * et cache posé sur les fenêtres bloquées.
 */
object Look {

    class Theme(val id: String, val name: String, val emoji: String, hex: List<String>, accentHex: String) {
        val colors: IntArray = hex.map { Color.parseColor(it) }.toIntArray()
        val accent: Int = Color.parseColor(accentHex)
    }

    val themes = listOf(
        Theme("corail", "Corail", "🔥", listOf("#FF416C", "#FF4B2B", "#6C5CE7"), "#FF416C"),
        Theme("ocean", "Océan", "🌊", listOf("#0052D4", "#4364F7", "#4FACFE"), "#0052D4"),
        Theme("foret", "Forêt", "🌿", listOf("#0B6E4F", "#11998E", "#38D98E"), "#0B8457"),
        Theme("aurore", "Aurore", "🌌", listOf("#4A00E0", "#8E2DE2", "#FF6CAB"), "#7B2FF7"),
        Theme("soleil", "Soleil", "☀️", listOf("#FF5E62", "#FF8A3D", "#F7B733"), "#F0643C"),
        Theme("nuit", "Nuit", "🌙", listOf("#0F2027", "#203A43", "#2C5364"), "#2C7DA0")
    )

    // ---------- Designs (le fond) ----------

    enum class Style(val label: String, val emoji: String, val light: Boolean = false) {
        MINIMAL("Minimal", "⚪", light = true),
        GRADIENT("Dégradé", "🌈"),
        SOFT3D("Soft 3D", "🫧", light = true),
        CONTOUR("Lignes de niveau", "🗺️"),
        HALFTONE("Trame", "⚫"),
        BLUEPRINT("Blueprint", "📐");
    }

    private const val KEY_STYLE = "look_style"

    fun style(c: Context): Style {
        val sp = c.getSharedPreferences("stopapp", Context.MODE_PRIVATE)
        // Nouveau style par défaut : Minimal (une seule fois, ensuite le choix de l'utilisateur compte)
        if (!sp.getBoolean("look_minimal_v1", false)) {
            sp.edit().putBoolean("look_minimal_v1", true).putString(KEY_STYLE, Style.MINIMAL.name).apply()
        }
        val n = sp.getString(KEY_STYLE, Style.MINIMAL.name)
        return Style.values().firstOrNull { it.name == n } ?: Style.MINIMAL
    }

    fun setStyle(c: Context, s: Style) =
        c.getSharedPreferences("stopapp", Context.MODE_PRIVATE).edit().putString(KEY_STYLE, s.name).apply()

    /** Fond complet (design + thème) pour un écran. */
    fun background(c: Context, bottomRadius: Float = 0f, alpha: Int = 255): android.graphics.drawable.Drawable =
        StyleDrawable(c, style(c), current(c), bottomRadius, alpha)

    private val INK = Color.parseColor("#1E1B2E")

    /**
     * Design clair (Soft 3D) : les textes et icônes blancs passent en foncé, sinon on les remet en blanc.
     * Les boutons gardent leurs couleurs.
     */
    fun tintTree(v: android.view.View, light: Boolean) {
        when (v) {
            is android.widget.Button -> return
            is android.widget.TextView -> {
                val orig = (v.getTag(R.id.orig_text_color) as? Int) ?: v.currentTextColor.also { v.setTag(R.id.orig_text_color, it) }
                val whiteish = Color.red(orig) > 225 && Color.green(orig) > 225 && Color.blue(orig) > 225
                if (whiteish) v.setTextColor(if (light) Color.argb(Color.alpha(orig), Color.red(INK), Color.green(INK), Color.blue(INK)) else orig)
            }
            is android.widget.ImageView -> {
                val orig = (v.getTag(R.id.orig_tint) as? android.content.res.ColorStateList)
                    ?: v.imageTintList?.also { v.setTag(R.id.orig_tint, it) }
                val white = orig?.defaultColor?.let { Color.red(it) > 225 && Color.green(it) > 225 && Color.blue(it) > 225 } == true
                if (white) v.imageTintList = if (light) android.content.res.ColorStateList.valueOf(INK) else orig
            }
            is android.view.ViewGroup -> for (i in 0 until v.childCount) tintTree(v.getChildAt(i), light)
        }
    }

    // ---------- Toute l'appli dans le design choisi ----------

    /** Le design couvre-t-il toute l'appli ? (« Dégradé » garde le style classique) */
    fun fullApp(c: Context) = style(c) != Style.GRADIENT

    /**
     * Habille un écran entier : le design en fond de fenêtre, puis [dress] sur le contenu.
     * À appeler juste après setContentView.
     */
    fun dressActivity(a: Activity) {
        if (!fullApp(a)) return
        if (style(a) == Style.MINIMAL) {
            // En-tête de l'écran principal : pas de dégradé, gros titre noir
            a.findViewById<View>(R.id.header)?.background = null
        }
        a.window.setBackgroundDrawable(background(a))
        applyBars(a, current(a))
        dress(a.findViewById(android.R.id.content))
    }

    private fun lum(c: Int) = (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0

    private fun solidColor(d: android.graphics.drawable.Drawable?): Int? = when (d) {
        is android.graphics.drawable.ColorDrawable -> d.color
        is android.graphics.drawable.GradientDrawable -> d.color?.defaultColor
        else -> null
    }

    /** Fond clair et opaque (carte blanche, pastille claire…) */
    private fun isLightSolid(d: android.graphics.drawable.Drawable?): Boolean {
        val c = solidColor(d) ?: return false
        return Color.alpha(c) >= 0x80 && lum(c) > 0.6
    }

    private fun recolorBg(v: View, color: Int) {
        when (val d = v.background?.mutate()) {
            is android.graphics.drawable.ColorDrawable -> d.color = color
            is android.graphics.drawable.GradientDrawable -> d.setColor(color)
        }
    }

    /** Couleur des cartes « verre » selon le design. */
    private fun glass(c: Context): Int = when (style(c)) {
        Style.MINIMAL -> Color.WHITE
        Style.SOFT3D -> Color.argb(0xCC, 255, 255, 255)
        Style.CONTOUR -> Color.argb(0xE0, 0x0F, 0x2A, 0x21)
        Style.BLUEPRINT -> Color.argb(0xE0, 0x10, 0x20, 0x33)
        else -> Color.argb(0x66, 0, 0, 0)
    }

    private fun glassStroke(c: Context): Int = when (style(c)) {
        Style.SOFT3D -> Color.argb(0xFF, 255, 255, 255)
        Style.CONTOUR -> Color.argb(0x55, 0xB9, 0xE7, 0x72)
        else -> Color.argb(0x40, 255, 255, 255)
    }

    /** Texte foncé -> clair (designs sombres). Les gris deviennent du blanc un peu transparent. */
    private fun lighten(col: Int): Int {
        if (lum(col) >= 0.45) return col
        val r = Color.red(col); val g = Color.green(col); val b = Color.blue(col)
        val sat = (maxOf(r, g, b) - minOf(r, g, b)) / 255.0
        return if (sat < 0.25) {
            if (lum(col) < 0.2) Color.argb(Color.alpha(col), 255, 255, 255) else Color.argb(0xC0, 255, 255, 255)
        } else StyleDrawable.mix(col, Color.WHITE, 0.5f)
    }

    /**
     * Adapte une partie d'écran au design : cartes en verre, fonds clairs adoucis,
     * textes lisibles. Peut être rappelé sans risque (listes reconstruites, etc.).
     */
    fun dress(root: View?) {
        root ?: return
        val c = root.context
        if (!fullApp(c)) return
        val light = style(c).light
        val headerState = androidx.core.content.ContextCompat.getDrawable(c, R.drawable.bg_header)?.constantState
        dressNode(root, c, light, false, headerState)
    }

    private fun dressNode(v: View, c: Context, light: Boolean, header: Boolean, headerState: android.graphics.drawable.Drawable.ConstantState?) {
        var inHeader = header
        // En-tête dégradé : le design de la fenêtre le remplace
        if (v.background != null && v.background.constantState != null && v.background.constantState == headerState) {
            v.background = null
            inHeader = true
        }
        // Fond de page uni : transparent pour laisser voir le design
        val bgc = solidColor(v.background)
        if (bgc != null && (bgc == Color.parseColor("#F5F3FB") || bgc == c.getColor(R.color.bg))) v.background = null

        when (v) {
            is com.google.android.material.card.MaterialCardView -> {
                v.setCardBackgroundColor(glass(c))
                v.cardElevation = 0f
                if (style(c) == Style.MINIMAL) {
                    // Style iPhone : cartes blanches plates, coins plus doux, sans contour
                    v.strokeWidth = 0
                    v.radius = 20 * c.resources.displayMetrics.density
                } else {
                    v.strokeWidth = (1 * c.resources.displayMetrics.density).toInt().coerceAtLeast(1)
                    v.strokeColor = glassStroke(c)
                }
            }
            is com.google.android.material.button.MaterialButton -> {
                // Bouton « contour » ou texte seul : texte clair sur design sombre
                val tint = v.backgroundTintList?.defaultColor
                if (!light && (tint == null || Color.alpha(tint) < 0x80)) v.setTextColor(lighten(v.currentTextColor))
                return
            }
            is android.widget.Button -> return
            is android.widget.TextView -> {
                if (inHeader || isWhite(v.currentTextColor) || v.getTag(R.id.orig_text_color) != null) {
                    tintTree(v, light)
                }
                // Minimal : pastilles de l'en-tête en gris clair (au lieu de blanc transparent)
                if (style(c) == Style.MINIMAL && inHeader && v.background != null) {
                    v.background = GradientDrawable().apply {
                        cornerRadius = 100f
                        setColor(Color.parseColor("#E5E5EA"))
                    }
                }
                if (!light) {
                    if (isLightSolid(v.background)) recolorBg(v, Color.argb(0x26, 255, 255, 255))
                    v.setTextColor(lighten(v.currentTextColor))
                    v.setHintTextColor(Color.argb(0x99, 255, 255, 255))
                }
                return
            }
            is android.widget.ImageView -> {
                if (inHeader) tintTree(v, light)
                return
            }
        }
        if (!light && v !is com.google.android.material.card.MaterialCardView && isLightSolid(v.background)) {
            recolorBg(v, Color.argb(0x1F, 255, 255, 255))
        }
        if (v is android.view.ViewGroup) for (i in 0 until v.childCount) dressNode(v.getChildAt(i), c, light, inHeader, headerState)
    }

    private fun isWhite(col: Int) = Color.red(col) > 225 && Color.green(col) > 225 && Color.blue(col) > 225

    private const val KEY = "look_theme"

    fun current(c: Context): Theme {
        val id = c.getSharedPreferences("stopapp", Context.MODE_PRIVATE).getString(KEY, "corail")
        return themes.firstOrNull { it.id == id } ?: themes[0]
    }

    fun set(c: Context, id: String) =
        c.getSharedPreferences("stopapp", Context.MODE_PRIVATE).edit().putString(KEY, id).apply()

    /** Dégradé du thème. [alpha] 0..255 ; [bottomRadius] en pixels (coins du bas arrondis). */
    fun gradient(t: Theme, reversed: Boolean = false, alpha: Int = 255, bottomRadius: Float = 0f): GradientDrawable {
        val cols = (if (reversed) t.colors.reversedArray() else t.colors)
            .map { Color.argb(alpha, Color.red(it), Color.green(it), Color.blue(it)) }.toIntArray()
        return GradientDrawable(GradientDrawable.Orientation.TL_BR, cols).apply {
            if (bottomRadius > 0f) cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, bottomRadius, bottomRadius, bottomRadius, bottomRadius)
        }
    }

    /** Barres du haut et du bas aux couleurs du thème. */
    @Suppress("DEPRECATION")
    fun applyBars(a: Activity, t: Theme, reversed: Boolean = false) {
        // Barres transparentes : le design passe dessous ; icônes foncées si le design est clair
        val light = style(a).light
        if (android.os.Build.VERSION.SDK_INT >= 35) {
            a.window.statusBarColor = Color.TRANSPARENT
            a.window.navigationBarColor = Color.TRANSPARENT
        } else {
            val first = if (reversed) t.colors.last() else t.colors.first()
            val last = if (reversed) t.colors.first() else t.colors.last()
            a.window.statusBarColor = if (style(a) == Style.MINIMAL) Color.parseColor("#F2F2F7") else if (light) StyleDrawable.mix(first, Color.WHITE, 0.88f) else if (style(a) == Style.CONTOUR || style(a) == Style.BLUEPRINT) StyleDrawable.mix(first, Color.BLACK, 0.8f) else first
            a.window.navigationBarColor = if (style(a) == Style.MINIMAL) Color.parseColor("#F2F2F7") else if (light) StyleDrawable.mix(last, Color.WHITE, 0.9f) else if (style(a) == Style.CONTOUR || style(a) == Style.BLUEPRINT) StyleDrawable.mix(first, Color.BLACK, 0.8f) else last
        }
        androidx.core.view.WindowCompat.getInsetsController(a.window, a.window.decorView).apply {
            isAppearanceLightStatusBars = light
            isAppearanceLightNavigationBars = light
        }
    }
}
