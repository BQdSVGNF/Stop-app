package com.perso.stopapp

/** Petites phrases pour garder la motivation. */
object Encouragements {

    /** Affichées sur l'écran d'accueil de stop#app. */
    val home = listOf(
        "Chaque minute reprise t'appartient.",
        "Tu construis une meilleure version de toi, un jour à la fois.",
        "Le scroll peut attendre. Ta vie, non.",
        "Petit à petit, tu reprends le contrôle.",
        "Ce que tu fais de ton temps, c'est ce que tu deviens.",
        "Fier de toi d'avoir mis stop#app en place.",
        "La discipline, c'est choisir ce que tu veux le plus plutôt que ce que tu veux maintenant.",
        "Un téléphone plus calme, une tête plus libre.",
        "Tu n'as pas besoin de motivation tous les jours, juste de régularité.",
        "Aujourd'hui compte. Fais-en un bon jour."
    )

    /** Affichées sur l'écran rouge quand une appli ou un site est bloqué. */
    val blocked = listOf(
        "Pas maintenant. Tu vaux mieux que le scroll.",
        "Respire un coup. Qu'est-ce que tu voulais vraiment faire ?",
        "Bien joué de résister ! Chaque refus te rend plus fort.",
        "Ton futur toi te remercie.",
        "C'est le moment de faire un truc qui compte vraiment.",
        "Pose le téléphone 2 minutes. Tu vas voir, ça fait du bien.",
        "Tu as choisi ce blocage pour une bonne raison. Fais-lui confiance.",
        "L'envie va passer. Ta fierté, elle, va rester.",
        "Lève les yeux. Le monde est là.",
        "Encore une victoire pour toi aujourd'hui !"
    )

    /** Affichées quand on essaie de désinstaller stop#app. */
    val quit = listOf(
        "Tu as installé stop#app pour une bonne raison. Elle est toujours vraie ?",
        "Les moments où on veut abandonner sont souvent juste avant les vrais progrès.",
        "Et si tu attendais demain pour décider ? Tu seras peut-être content d'avoir tenu.",
        "Tu as déjà fait le plus dur : commencer. Ne lâche pas maintenant."
    )

    /** Idées concrètes pour remplacer le scroll (écran de blocage). */
    val ideas = listOf(
        "💧 Bois un grand verre d'eau",
        "💪 Fais 10 pompes ou 20 squats",
        "📞 Appelle ou écris à un pote (pour de vrai)",
        "🚶 Va marcher 5 minutes dehors",
        "📖 Lis 5 pages d'un livre",
        "🧘 Ferme les yeux et respire lentement 10 fois",
        "🧹 Range un truc qui traîne depuis longtemps",
        "📝 Écris 3 choses que tu veux faire aujourd'hui",
        "🎧 Écoute une chanson en entier sans rien faire d'autre",
        "🍎 Prends un fruit et mange-le tranquillement",
        "🤸 Étire-toi 2 minutes, ton dos te remerciera",
        "📚 Avance 10 minutes sur tes devoirs ou ton travail",
        "🎨 Dessine quelque chose, même moche",
        "🙏 Pense à 3 choses pour lesquelles tu es reconnaissant",
        "🛏️ Fais ton lit si ce n'est pas déjà fait",
        "🎸 Pratique un truc que tu veux apprendre"
    )

    /** Messages d'encouragement pendant le mode Focus. */
    val focus = listOf(
        "Tu es en mode Focus. Termine ce que tu as commencé.",
        "Concentration maximale, tu gères.",
        "Chaque minute de Focus te rapproche de ton objectif."
    )

    fun random(list: List<String>) = list.random()

    /** Une autre phrase que [current] si possible. */
    fun other(list: List<String>, current: CharSequence?): String =
        list.filter { it != current?.toString() }.ifEmpty { list }.random()
}
