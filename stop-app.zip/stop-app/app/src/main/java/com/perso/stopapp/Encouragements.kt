package com.perso.stopapp

/** Petites phrases pour garder la motivation. */
object Encouragements {

    /** Affichées sur l'écran d'accueil de stop#app. */
    val home = listOf(
        "Chaque minute reprise t'appartient. 💪",
        "Tu construis une meilleure version de toi, un jour à la fois.",
        "Le scroll peut attendre. Ta vie, non.",
        "Petit à petit, tu reprends le contrôle. 🔥",
        "Ce que tu fais de ton temps, c'est ce que tu deviens.",
        "Fier de toi d'avoir mis stop#app en place. 🙌",
        "La discipline, c'est choisir ce que tu veux le plus plutôt que ce que tu veux maintenant.",
        "Un téléphone plus calme, une tête plus libre. 🧠",
        "Tu n'as pas besoin de motivation tous les jours, juste de régularité.",
        "Aujourd'hui compte. Fais-en un bon jour. ☀️"
    )

    /** Affichées sur l'écran rouge quand une appli ou un site est bloqué. */
    val blocked = listOf(
        "Pas maintenant. Tu vaux mieux que le scroll. 💪",
        "Respire un coup. Qu'est-ce que tu voulais vraiment faire ?",
        "Bien joué de résister ! Chaque refus te rend plus fort.",
        "Ton futur toi te remercie. 🙏",
        "C'est le moment de faire un truc qui compte vraiment.",
        "Pose le téléphone 2 minutes. Tu vas voir, ça fait du bien.",
        "Tu as choisi ce blocage pour une bonne raison. Fais-lui confiance.",
        "L'envie va passer. Ta fierté, elle, va rester. 🔥",
        "Lève les yeux. Le monde est là. 🌍",
        "Encore une victoire pour toi aujourd'hui !"
    )

    /** Affichées quand on essaie de désinstaller stop#app. */
    val quit = listOf(
        "Tu as installé stop#app pour une bonne raison. Elle est toujours vraie ?",
        "Les moments où on veut abandonner sont souvent juste avant les vrais progrès.",
        "Et si tu attendais demain pour décider ? Tu seras peut-être content d'avoir tenu.",
        "Tu as déjà fait le plus dur : commencer. Ne lâche pas maintenant. 💪"
    )

    fun random(list: List<String>) = list.random()
}
