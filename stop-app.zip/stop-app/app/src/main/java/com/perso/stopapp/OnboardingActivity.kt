package com.perso.stopapp

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

/**
 * Configuration guidée au premier lancement :
 * 1. activer la protection (service d'accessibilité)
 * 2. choisir les applications autorisées
 * 3. vérifier les horaires libres
 */
class OnboardingActivity : AppCompatActivity() {

    companion object {
        private const val PREFS = "stopapp"
        private const val KEY_DONE = "onboarding_done"

        /** Déjà configuré ? (les anciennes installations déjà démarrées sont considérées comme configurées) */
        fun isDone(c: Context): Boolean =
            c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_DONE, false) || Prefs.isStarted(c)

        private fun setDone(c: Context) =
            c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_DONE, true).apply()

        fun isServiceEnabled(c: Context): Boolean {
            val expected = ComponentName(c, BlockService::class.java).flattenToString()
            val enabled = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
                ?: return false
            val splitter = TextUtils.SimpleStringSplitter(':')
            splitter.setString(enabled)
            while (splitter.hasNext()) if (splitter.next().equals(expected, ignoreCase = true)) return true
            return false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_onboarding)

        findViewById<MaterialButton>(R.id.ob_btn_service).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<MaterialButton>(R.id.ob_btn_apps).setOnClickListener {
            startActivity(Intent(this, AppPickerActivity::class.java))
        }
        findViewById<MaterialButton>(R.id.ob_btn_finish).setOnClickListener {
            setDone(this)
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }

        val fmt = { we: Boolean ->
            Prefs.freeWindows(this, we).sortedBy { Prefs.parseWindow(it)?.first ?: 0 }
                .joinToString(", ") { it.replace("-", " – ").replace(":", "h") }
        }
        findViewById<TextView>(R.id.ob_txt_hours).text =
            "Lun – Ven : ${fmt(false)}\nSam – Dim : ${fmt(true)}\nTu pourras les modifier ensuite."
    }

    override fun onResume() {
        super.onResume()
        val serviceOn = isServiceEnabled(this)
        val appsCount = Prefs.allowedApps(this).size

        setStep(R.id.ob_check_1, serviceOn)
        findViewById<TextView>(R.id.ob_txt_service).text =
            if (serviceOn) "Protection activée."
            else "Ouvre Accessibilité → Applications installées → stop#app et active-le. " +
                "Si l'option est grisée : Paramètres → Applications → stop#app → ⋮ → Autoriser les paramètres restreints."
        findViewById<MaterialButton>(R.id.ob_btn_service).isEnabled = !serviceOn

        setStep(R.id.ob_check_2, appsCount > 0)
        findViewById<TextView>(R.id.ob_txt_apps).text =
            if (appsCount > 0) "$appsCount application(s) autorisée(s)."
            else "Choisis les applications qui restent ouvertes pendant le blocage (messagerie, cours, banque…)."

        setStep(R.id.ob_check_3, true)

        findViewById<MaterialButton>(R.id.ob_btn_finish).isEnabled = serviceOn
    }

    private fun setStep(id: Int, done: Boolean) {
        val v = findViewById<ImageView>(id)
        v.setImageResource(if (done) R.drawable.ic_check_circle else R.drawable.ic_schedule)
        v.imageTintList = android.content.res.ColorStateList.valueOf(
            getColor(if (done) R.color.green else R.color.ink_soft)
        )
    }
}
