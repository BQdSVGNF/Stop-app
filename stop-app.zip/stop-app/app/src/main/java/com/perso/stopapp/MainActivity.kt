package com.perso.stopapp

import android.app.TimePickerDialog
import android.appwidget.AppWidgetManager
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import com.google.android.material.progressindicator.CircularProgressIndicator
import com.google.android.material.progressindicator.LinearProgressIndicator
import java.util.Calendar
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    companion object {
        /** Mis par l'écran « Tu es sûr ? » quand tu as choisi de garder stop#app. */
        const val EXTRA_KEPT = "kept"
    }

    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1000)
        }
    }

    private lateinit var txtStatus: TextView
    private lateinit var txtStatusEmoji: TextView
    private lateinit var txtStatusSub: TextView
    private lateinit var txtService: TextView
    private lateinit var btnService: Button
    private lateinit var btnMain: Button
    private lateinit var txtLocked: TextView
    private lateinit var boxWindows: LinearLayout
    private lateinit var btnAddWindow: Button
    private lateinit var toggleDays: com.google.android.material.button.MaterialButtonToggleGroup
    private lateinit var txtScheduleToday: TextView
    /** Horaires affichés dans la carte : false = semaine, true = week-end. */
    private var showWeekend = false
    private lateinit var btnApps: Button
    private lateinit var txtApps: TextView
    private lateinit var editSite: EditText
    private lateinit var btnAddSite: Button
    private lateinit var boxSites: LinearLayout
    private lateinit var txtQuote: TextView
    private lateinit var statToday: TextView
    private lateinit var statStreak: TextView
    private lateinit var statSaved: TextView
    private lateinit var txtPass: TextView
    private lateinit var btnPass: Button

    private lateinit var txtGreeting: TextView
    private lateinit var txtLevelChip: TextView
    private lateinit var statusRing: CircularProgressIndicator
    private lateinit var txtFocus: TextView
    private lateinit var boxFocusButtons: LinearLayout
    private lateinit var txtLevelNum: TextView
    private lateinit var txtLevelTitle: TextView
    private lateinit var txtLevelSub: TextView
    private lateinit var levelProgress: LinearProgressIndicator
    private lateinit var txtBadgesCount: TextView
    private lateinit var boxBadges: LinearLayout

    private var lastListsKey = ""
    private var lastBadgesKey = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtStatus = findViewById(R.id.txt_status)
        txtStatusEmoji = findViewById(R.id.txt_status_emoji)
        txtStatusSub = findViewById(R.id.txt_status_sub)
        txtService = findViewById(R.id.txt_service)
        btnService = findViewById(R.id.btn_service)
        btnMain = findViewById(R.id.btn_main)
        txtLocked = findViewById(R.id.txt_locked)
        boxWindows = findViewById(R.id.box_windows)
        btnAddWindow = findViewById(R.id.btn_add_window)
        toggleDays = findViewById(R.id.toggle_days)
        txtScheduleToday = findViewById(R.id.txt_schedule_today)
        // On ouvre sur les horaires du jour en cours
        showWeekend = Prefs.isWeekendToday()
        toggleDays.check(if (showWeekend) R.id.btn_weekend else R.id.btn_weekdays)
        toggleDays.addOnButtonCheckedListener { _, id, checked ->
            if (!checked) return@addOnButtonCheckedListener
            showWeekend = id == R.id.btn_weekend
            lastListsKey = ""
            refresh()
        }
        btnApps = findViewById(R.id.btn_apps)
        txtApps = findViewById(R.id.txt_apps)
        editSite = findViewById(R.id.edit_site)
        btnAddSite = findViewById(R.id.btn_add_site)
        boxSites = findViewById(R.id.box_sites)
        txtQuote = findViewById(R.id.txt_quote)
        statToday = findViewById(R.id.stat_today)
        statStreak = findViewById(R.id.stat_streak)
        statSaved = findViewById(R.id.stat_saved)
        txtPass = findViewById(R.id.txt_pass)
        btnPass = findViewById(R.id.btn_pass)

        txtQuote.text = Encouragements.random(Encouragements.home)
        txtQuote.setOnClickListener { txtQuote.text = Encouragements.random(Encouragements.home) }
        btnPass.setOnClickListener { onPassButton() }
        if (intent.getBooleanExtra(EXTRA_KEPT, false)) showKeptMessage()

        btnService.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Active « stop#app » dans Accessibilité", Toast.LENGTH_LONG).show()
        }
        btnMain.setOnClickListener { onMainButton() }
        btnApps.setOnClickListener {
            if (Prefs.canEdit(this)) startActivity(Intent(this, AppPickerActivity::class.java))
        }
        btnAddSite.setOnClickListener {
            if (!Prefs.canEdit(this)) return@setOnClickListener
            val site = Prefs.normalizeSite(editSite.text.toString())
            if (site.isEmpty()) return@setOnClickListener
            Prefs.setBlockedSites(this, Prefs.blockedSites(this) + site)
            editSite.setText("")
            lastListsKey = ""
            refresh()
        }
        btnAddWindow.setOnClickListener { pickWindow() }

        txtGreeting = findViewById(R.id.txt_greeting)
        txtLevelChip = findViewById(R.id.txt_level_chip)
        statusRing = findViewById(R.id.status_ring)
        txtFocus = findViewById(R.id.txt_focus)
        boxFocusButtons = findViewById(R.id.box_focus_buttons)
        txtLevelNum = findViewById(R.id.txt_level_num)
        txtLevelTitle = findViewById(R.id.txt_level_title)
        txtLevelSub = findViewById(R.id.txt_level_sub)
        levelProgress = findViewById(R.id.level_progress)
        txtBadgesCount = findViewById(R.id.txt_badges_count)
        boxBadges = findViewById(R.id.box_badges)

        findViewById<Button>(R.id.btn_focus_25).setOnClickListener { askFocus(25) }
        findViewById<Button>(R.id.btn_focus_60).setOnClickListener { askFocus(60) }
        findViewById<Button>(R.id.btn_focus_120).setOnClickListener { askFocus(120) }
        findViewById<Button>(R.id.btn_widget).setOnClickListener { addWidget() }
        // Appui sur « Niv. X » dans l'en-tête : on descend jusqu'à la carte des badges
        txtLevelChip.setOnClickListener {
            val card = findViewById<View>(R.id.card_level)
            val content = findViewById<View>(R.id.content)
            var p = content.parent
            while (p != null && p !is android.widget.ScrollView) p = p.parent
            (p as? android.widget.ScrollView)?.smoothScrollTo(0, content.top + card.top - 24)
        }

        animateEntrance()
    }

    /** Les cartes arrivent les unes après les autres. */
    private fun animateEntrance() {
        val content = findViewById<ViewGroup>(R.id.content)
        for (i in 0 until content.childCount) {
            val v = content.getChildAt(i)
            v.alpha = 0f
            v.translationY = 40f
            v.animate().alpha(1f).translationY(0f)
                .setStartDelay(60L * i).setDuration(380)
                .setInterpolator(DecelerateInterpolator()).start()
        }
    }

    // ---------- Mode Focus ----------

    private fun askFocus(minutes: Int) {
        if (Prefs.inFocus(this)) return
        if (!isServiceEnabled()) {
            Toast.makeText(this, "Active d'abord le service d'accessibilité", Toast.LENGTH_LONG).show()
            return
        }
        val label = QuitActivity.formatMinutes(minutes)
        AlertDialog.Builder(this)
            .setTitle("🎯 Lancer $label de Focus ?")
            .setMessage(
                "Toutes les applis seront bloquées, même celles autorisées et même pendant un créneau libre.\n\n" +
                "⚠️ Une fois lancé, le Focus ne peut PAS être arrêté avant la fin.\n\n" +
                "Le téléphone et les appels d'urgence restent disponibles."
            )
            .setPositiveButton("C'est parti 🚀") { _, _ ->
                Prefs.startFocus(this, minutes)
                StopWidget.updateAll(this, force = true)
                Toast.makeText(this, "Focus lancé ! Tu vas tout déchirer 💪", Toast.LENGTH_LONG).show()
                refresh()
            }
            .setNegativeButton("Pas maintenant", null)
            .show()
    }

    // ---------- Widget ----------

    private fun addWidget() {
        val manager = AppWidgetManager.getInstance(this)
        val provider = ComponentName(this, StopWidget::class.java)
        if (manager.isRequestPinAppWidgetSupported) {
            manager.requestPinAppWidget(provider, null, null)
        } else {
            AlertDialog.Builder(this)
                .setTitle("📲 Ajouter le widget")
                .setMessage("Fais un appui long sur ton écran d'accueil → Widgets → cherche « stop#app » → fais-le glisser où tu veux.")
                .setPositiveButton("OK", null)
                .show()
        }
    }

    // ---------- Niveau et badges ----------

    private fun refreshLevel() {
        val stats = Badges.stats(this)
        val level = Badges.level(stats.xp)
        txtLevelChip.text = "⭐ Niv. ${level.number}"
        txtLevelNum.text = level.number.toString()
        txtLevelTitle.text = "Niveau ${level.number} · ${level.name}"
        txtLevelSub.text =
            if (level.to == null) "${stats.xp} XP · niveau maximum atteint 👑"
            else "${stats.xp} XP · encore ${level.remaining} XP pour le niveau ${level.number + 1}"
        levelProgress.setProgressCompat(level.percent, true)

        val unlocked = Badges.unlocked(stats).map { it.id }.toSet()
        txtBadgesCount.text = "${unlocked.size} / ${Badges.all.size}"
        val key = unlocked.sorted().joinToString()
        if (key != lastBadgesKey) {
            lastBadgesKey = key
            fillBadges(unlocked)
        }

        // Annonce des nouveaux badges
        val fresh = Badges.takeNew(this)
        if (fresh.isNotEmpty()) celebrate(fresh)
    }

    private fun fillBadges(unlocked: Set<String>) {
        boxBadges.removeAllViews()
        Badges.all.chunked(4).forEach { rowBadges ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowBadges.forEach { b ->
                val tile = layoutInflater.inflate(R.layout.item_badge, row, false)
                val on = b.id in unlocked
                val emoji = tile.findViewById<TextView>(R.id.badge_emoji)
                emoji.text = if (on) b.emoji else "🔒"
                emoji.setBackgroundResource(if (on) R.drawable.bg_badge_on else R.drawable.bg_badge_off)
                tile.findViewById<TextView>(R.id.badge_name).text = b.name
                tile.alpha = if (on) 1f else 0.55f
                tile.setOnClickListener {
                    Toast.makeText(
                        this,
                        (if (on) "${b.emoji} ${b.name} — débloqué !" else "🔒 ${b.name} : ${b.desc}"),
                        Toast.LENGTH_SHORT
                    ).show()
                }
                row.addView(tile)
            }
            // Complète la dernière ligne pour garder l'alignement
            repeat(4 - rowBadges.size) {
                row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            }
            boxBadges.addView(row)
        }
    }

    private fun celebrate(fresh: List<Badges.Badge>) {
        val lines = fresh.joinToString("\n") { "${it.emoji}  ${it.name} — ${it.desc}" }
        AlertDialog.Builder(this)
            .setTitle(if (fresh.size == 1) "🎉 Nouveau badge !" else "🎉 ${fresh.size} nouveaux badges !")
            .setMessage("$lines\n\nContinue comme ça, tu es sur la bonne voie 💪")
            .setPositiveButton("Trop bien !", null)
            .show()
        val card = findViewById<View>(R.id.card_level)
        card.animate().scaleX(1.04f).scaleY(1.04f).setDuration(180).withEndAction {
            card.animate().scaleX(1f).scaleY(1f).setDuration(380).setInterpolator(OvershootInterpolator()).start()
        }.start()
    }

    // ---------- Bouton principal ----------

    private fun onMainButton() {
        val now = System.currentTimeMillis()
        when {
            Prefs.inFocus(this) -> return
            !Prefs.isStarted(this) -> {
                if (!isServiceEnabled()) {
                    Toast.makeText(this, "Active d'abord le service d'accessibilité", Toast.LENGTH_LONG).show()
                    return
                }
                AlertDialog.Builder(this)
                    .setTitle("Démarrer stop#app ?")
                    .setMessage(
                        "stop#app sera actif tout le temps, sauf pendant tes créneaux libres.\n\n" +
                        "📅 Lundi → vendredi :\n" +
                        Prefs.freeWindows(this, false).sorted().joinToString("\n") { "• " + it.replace("-", " → ") } +
                        "\n\n🌴 Samedi et dimanche :\n" +
                        Prefs.freeWindows(this, true).sorted().joinToString("\n") { "• " + it.replace("-", " → ") } +
                        "\n\nPour modifier les réglages en dehors de ces créneaux, tu devras attendre 5 minutes."
                    )
                    .setPositiveButton("Démarrer") { _, _ -> Prefs.setStarted(this, true); refresh() }
                    .setNegativeButton("Annuler", null)
                    .show()
            }
            Prefs.inPass(this) -> {
                // Reprendre le blocage avant la fin de la pause bonus
                Prefs.endPass(this)
            }
            Prefs.inEditMode(this) -> {
                // Terminer les modifications : le blocage reprend tout de suite
                Prefs.setEditUntil(this, 0)
            }
            Prefs.isBlockingNow(this) -> {
                val req = Prefs.unlockRequestedAt(this)
                when {
                    req == 0L -> Prefs.setUnlockRequestedAt(this, now)
                    now - req >= Prefs.WAIT_MS -> {
                        Prefs.setUnlockRequestedAt(this, 0)
                        Prefs.setEditUntil(this, now + Prefs.EDIT_MS)
                    }
                    else -> Prefs.setUnlockRequestedAt(this, 0)
                }
            }
        }
        refresh()
    }

    // ---------- Pause bonus ----------

    private fun onPassButton() {
        if (Prefs.inFocus(this) || Prefs.passUsedToday(this) || !Prefs.isBlockingNow(this)) return
        AlertDialog.Builder(this)
            .setTitle("☕ Prendre ta pause de 20 min ?")
            .setMessage("Tout sera débloqué pendant 20 minutes. Tu ne peux la prendre qu'une seule fois par jour, alors choisis bien ton moment !")
            .setPositiveButton("C'est parti") { _, _ ->
                if (Prefs.startPass(this)) {
                    Toast.makeText(this, "Bonne pause ! Le blocage revient dans 20 min ⏳", Toast.LENGTH_LONG).show()
                }
                refresh()
            }
            .setNegativeButton("Je la garde pour plus tard", null)
            .show()
    }

    private fun showKeptMessage() {
        AlertDialog.Builder(this)
            .setTitle("Bravo 💪")
            .setMessage("Tu as fait le bon choix. Continue comme ça, tu vas être fier de toi !")
            .setPositiveButton("Merci !", null)
            .show()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra(EXTRA_KEPT, false)) showKeptMessage()
    }

    // ---------- Créneaux libres ----------

    private fun pickWindow() {
        if (!Prefs.canEdit(this)) return
        val dayLabel = if (showWeekend) "week-end" else "lun → ven"
        TimePickerDialog(this, { _, h1, m1 ->
            TimePickerDialog(this, { _, h2, m2 ->
                if (h1 == h2 && m1 == m2) {
                    Toast.makeText(this, "Le début et la fin sont identiques", Toast.LENGTH_SHORT).show()
                    return@TimePickerDialog
                }
                val w = "%02d:%02d-%02d:%02d".format(h1, m1, h2, m2)
                val we = showWeekend
                Prefs.setFreeWindows(this, Prefs.freeWindows(this, we) + w, we)
                lastListsKey = ""
                refresh()
            }, (h1 + 2) % 24, m1, true).apply { setTitle("Fin du créneau libre ($dayLabel)") }.show()
        }, 12, 0, true).apply { setTitle("Début du créneau libre ($dayLabel)") }.show()
    }

    // ---------- Affichage ----------

    private fun refresh() {
        val started = Prefs.isStarted(this)
        val canEdit = Prefs.canEdit(this)
        val serviceOn = isServiceEnabled()

        txtService.text = if (serviceOn) "●  Protection en marche" else "●  Service d'accessibilité désactivé"
        btnService.visibility = if (serviceOn) View.GONE else View.VISIBLE

        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        txtGreeting.text = when (hour) {
            in 5..11 -> "Bonjour ☀️"
            in 12..17 -> "Bon après-midi 👋"
            else -> "Bonsoir 🌙"
        }

        val free = Prefs.currentFreeWindow(this)
        btnMain.visibility = View.VISIBLE
        ringPercent = 100
        when {
            Prefs.inFocus(this) -> {
                val total = (Prefs.focusUntil(this) - System.currentTimeMillis()).coerceAtLeast(0)
                val s = (total / 1000).toInt()
                val h = s / 3600
                val time = if (h > 0) "%d:%02d:%02d".format(h, (s % 3600) / 60, s % 60) else "%d:%02d".format(s / 60, s % 60)
                ringPercent = focusPercent()
                setStatus("🎯", time, "Mode Focus · tout est bloqué jusqu'à la fin", R.color.purple, R.color.blue_soft)
                btnMain.visibility = View.GONE
            }
            !started -> {
                setStatus("🚀", "Prêt à démarrer", "Choisis tes applis et tes sites, puis lance stop#app", R.color.purple, R.color.blue_soft)
                btnMain.text = "Démarrer stop#app"
            }
            Prefs.inEditMode(this) -> {
                val s = ((Prefs.editUntil(this) - System.currentTimeMillis()) / 1000).toInt().coerceAtLeast(0)
                ringPercent = (s * 100 / (Prefs.EDIT_MS / 1000)).toInt()
                setStatus("✏️", "Mode modification", "Reblocage automatique dans %d:%02d".format(s / 60, s % 60), R.color.amber, R.color.amber_soft)
                btnMain.text = "Terminer et rebloquer"
            }
            Prefs.inPass(this) -> {
                val s = ((Prefs.passUntil(this) - System.currentTimeMillis()) / 1000).toInt().coerceAtLeast(0)
                ringPercent = (s * 100 / (Prefs.PASS_MS / 1000)).toInt()
                setStatus("☕", "Pause bonus", "Encore %d:%02d, profites-en bien".format(s / 60, s % 60), R.color.green, R.color.green_soft)
                btnMain.text = "Reprendre le blocage maintenant"
            }
            free != null -> {
                setStatus("😌", "Pause", "Créneau libre jusqu'à ${free.substringAfter("-")}", R.color.green, R.color.green_soft)
                btnMain.visibility = View.GONE
            }
            else -> {
                val next = Prefs.nextFreeStart(this)
                val req = Prefs.unlockRequestedAt(this)
                val left = Prefs.WAIT_MS - (System.currentTimeMillis() - req)
                when {
                    req == 0L -> {
                        val inMin = Prefs.minutesToNextFree(this)
                        val sub = if (next != null && inMin != null)
                            "Prochaine pause : $next · dans ${QuitActivity.formatMinutes(inMin)}"
                        else "Concentre-toi 💪"
                        setStatus("🔒", "Blocage actif", sub, R.color.red, R.color.red_soft)
                        btnMain.text = "Demander à modifier · 5 min"
                    }
                    left > 0 -> {
                        val s = (left / 1000).toInt()
                        ringPercent = 100 - (s * 100 / (Prefs.WAIT_MS / 1000)).toInt()
                        setStatus("⏳", "%d:%02d".format(s / 60, s % 60), "Encore un peu de patience…", R.color.amber, R.color.amber_soft)
                        btnMain.text = "Annuler la demande"
                    }
                    else -> {
                        setStatus("✅", "C'est bon", "Tu peux modifier pendant 10 minutes", R.color.green, R.color.green_soft)
                        btnMain.text = "Modifier maintenant"
                    }
                }
            }
        }

        // Statistiques
        statToday.text = Prefs.blocksToday(this).toString()
        statStreak.text = Prefs.streak(this).toString()
        statSaved.text = QuitActivity.formatMinutes(Prefs.blocksTotal(this) * Prefs.MINUTES_PER_BLOCK)

        // Pause bonus
        when {
            Prefs.inPass(this) -> {
                txtPass.text = "En cours ☕ — le blocage revient tout seul à la fin"
                btnPass.text = "Pause en cours"
                btnPass.isEnabled = false
            }
            Prefs.passUsedToday(this) -> {
                txtPass.text = "Déjà utilisée aujourd'hui. Elle revient demain 🌙"
                btnPass.text = "Utilisée ✓"
                btnPass.isEnabled = false
            }
            !Prefs.isBlockingNow(this) -> {
                txtPass.text = "20 minutes libres, une fois par jour"
                btnPass.text = "Disponible pendant le blocage"
                btnPass.isEnabled = false
            }
            else -> {
                txtPass.text = "20 minutes libres, une fois par jour"
                btnPass.text = "☕  Utiliser ma pause de 20 min"
                btnPass.isEnabled = true
            }
        }

        // Carte Focus
        if (Prefs.inFocus(this)) {
            txtFocus.text = "En cours 🎯 Termine ce que tu as commencé !"
            boxFocusButtons.visibility = View.GONE
        } else {
            val n = Prefs.focusSessions(this)
            txtFocus.text = if (n == 0) "Bloque tout, même pendant tes pauses"
                else "Bloque tout · $n session(s) lancée(s) 💪"
            boxFocusButtons.visibility = View.VISIBLE
        }
        if (Prefs.inFocus(this)) {
            btnPass.isEnabled = false
            txtPass.text = "Indisponible pendant le Focus 🎯"
        }

        refreshLevel()
        StopWidget.updateAll(this)

        txtLocked.visibility = if (canEdit) View.GONE else View.VISIBLE
        btnApps.isEnabled = canEdit
        btnAddWindow.isEnabled = canEdit
        editSite.isEnabled = canEdit
        btnAddSite.isEnabled = canEdit
        val n = Prefs.allowedApps(this).size
        txtApps.text = if (n == 0) "Aucune application autorisée" else "$n application(s) autorisée(s)"

        // Reconstruit les listes seulement si quelque chose a changé
        txtScheduleToday.text =
            if (Prefs.isWeekendToday()) "Aujourd'hui : horaires du week-end 🌴"
            else "Aujourd'hui : horaires de la semaine 📅"
        val windows = Prefs.freeWindows(this, showWeekend).sortedBy { Prefs.parseWindow(it)?.first ?: 0 }
        val sites = Prefs.blockedSites(this).sorted()
        val key = "$canEdit|$showWeekend|$windows|$sites"
        if (key != lastListsKey) {
            lastListsKey = key
            fillList(boxWindows, if (showWeekend) "🌴" else "☀️", windows.map { it.replace("-", "  →  ").replace(":", "h") }, windows, canEdit, "Aucun créneau libre") { w ->
                Prefs.setFreeWindows(this, Prefs.freeWindows(this, showWeekend) - w, showWeekend)
            }
            fillList(boxSites, "🚫", sites, sites, canEdit, "Aucun site bloqué pour l'instant") { s ->
                Prefs.setBlockedSites(this, Prefs.blockedSites(this) - s)
            }
        }
    }

    /** Met à jour la grande carte de statut (emoji, titre, sous-titre, couleurs). */
    private var ringPercent = 100

    private fun focusPercent(): Int {
        val left = (Prefs.focusUntil(this) - System.currentTimeMillis()).coerceAtLeast(0)
        return (left * 100 / Prefs.focusTotalMs(this)).toInt().coerceIn(0, 100)
    }

    private fun setStatus(emoji: String, title: String, sub: String, color: Int, soft: Int) {
        statusRing.setIndicatorColor(getColor(color))
        statusRing.trackColor = getColor(soft)
        statusRing.setProgressCompat(ringPercent, true)
        if (txtStatusEmoji.text.toString() != emoji) {
            txtStatusEmoji.scaleX = 0.6f; txtStatusEmoji.scaleY = 0.6f
            txtStatusEmoji.animate().scaleX(1f).scaleY(1f).setDuration(350)
                .setInterpolator(OvershootInterpolator()).start()
        }
        txtStatusEmoji.text = emoji
        txtStatusEmoji.background.mutate().setTint(getColor(soft))
        txtStatus.text = title
        txtStatus.setTextColor(getColor(color))
        txtStatusSub.text = sub
        btnMain.backgroundTintList = android.content.res.ColorStateList.valueOf(getColor(color))
    }

    /** Remplit une liste de lignes arrondies avec un bouton ✕ (actif seulement si modifiable). */
    private fun fillList(box: LinearLayout, icon: String, labels: List<String>, values: List<String>, canEdit: Boolean, empty: String, onRemove: (String) -> Unit) {
        box.removeAllViews()
        if (labels.isEmpty()) {
            box.addView(TextView(this).apply {
                text = empty
                setTextColor(getColor(R.color.ink_soft))
                setPadding(4, 4, 4, 12)
            })
            return
        }
        val inflater = layoutInflater
        labels.forEachIndexed { i, label ->
            val row = inflater.inflate(R.layout.item_row, box, false)
            row.findViewById<TextView>(R.id.row_icon).text = icon
            row.findViewById<TextView>(R.id.row_label).text = label
            val remove = row.findViewById<TextView>(R.id.row_remove)
            remove.visibility = if (canEdit) View.VISIBLE else View.INVISIBLE
            remove.setOnClickListener {
                if (Prefs.canEdit(this@MainActivity)) {
                    onRemove(values[i]); lastListsKey = ""; refresh()
                }
            }
            box.addView(row)
        }
    }

    private fun isServiceEnabled(): Boolean {
        val expected = ComponentName(this, BlockService::class.java).flattenToString()
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabled)
        while (splitter.hasNext()) {
            if (splitter.next().equals(expected, ignoreCase = true)) return true
        }
        return false
    }

    override fun onResume() {
        super.onResume()
        lastListsKey = ""
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
    }
}
