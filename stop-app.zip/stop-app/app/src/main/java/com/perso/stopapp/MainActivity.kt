package com.perso.stopapp

import android.app.TimePickerDialog
import android.appwidget.AppWidgetManager
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import com.google.android.material.progressindicator.CircularProgressIndicator
import com.google.android.material.progressindicator.LinearProgressIndicator
import java.util.Calendar
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    companion object {
        /** Mis par l'écran « Tu es sûr ? » quand tu as choisi de garder stop#app. */
        const val EXTRA_KEPT = "kept"
    }

    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1000)
        }
    }

    private lateinit var txtStatus: TextView
    private lateinit var statusIcon: android.widget.ImageView
    private var currentIcon = 0
    private lateinit var txtStatusSub: TextView
    private lateinit var txtService: TextView
    private lateinit var btnService: Button
    private lateinit var btnMain: Button
    private lateinit var txtLocked: TextView
    private lateinit var boxWindows: LinearLayout
    private lateinit var btnAddWindow: Button
    private lateinit var toggleDays: com.google.android.material.button.MaterialButtonToggleGroup
    private lateinit var txtScheduleToday: TextView
    /** Horaires affichés dans la carte : false = semaine, true = week-end. */
    private var showWeekend = false
    /** Horaires affichés : 0 = semaine, 1 = week-end, 2 = vacances. */
    private var dayMode = 0
    private lateinit var boxVacation: LinearLayout
    private lateinit var txtVacationDates: TextView
    private lateinit var btnVacationDates: Button
    private lateinit var btnVacationClear: Button
    private lateinit var btnApps: Button
    private lateinit var txtApps: TextView
    private lateinit var editSite: EditText
    private lateinit var btnAddSite: Button
    private lateinit var boxSites: LinearLayout
    private lateinit var txtQuote: TextView
    private lateinit var statToday: TextView
    private lateinit var statStreak: TextView
    private lateinit var statSaved: TextView
    private lateinit var txtPass: TextView
    private lateinit var btnPass: Button

    private lateinit var txtGreeting: TextView
    private lateinit var txtLevelChip: TextView
    private lateinit var statusRing: CircularProgressIndicator
    private lateinit var txtFocus: TextView
    private lateinit var boxFocusButtons: LinearLayout
    private lateinit var txtLevelNum: TextView
    private lateinit var txtLevelTitle: TextView
    private lateinit var txtLevelSub: TextView
    private lateinit var levelProgress: LinearProgressIndicator
    private lateinit var txtBadgesCount: TextView
    private lateinit var boxBadges: LinearLayout
    private lateinit var switchStrict: android.widget.CompoundButton

    private var lastListsKey = ""
    private var lastBadgesKey = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.migrate(this)
        // Premier lancement : configuration guidée
        if (!OnboardingActivity.isDone(this)) {
            startActivity(Intent(this, OnboardingActivity::class.java))
            finish()
            return
        }
        setContentView(R.layout.activity_main)

        txtStatus = findViewById(R.id.txt_status)
        statusIcon = findViewById(R.id.status_icon)
        txtStatusSub = findViewById(R.id.txt_status_sub)
        txtService = findViewById(R.id.txt_service)
        btnService = findViewById(R.id.btn_service)
        btnMain = findViewById(R.id.btn_main)
        txtLocked = findViewById(R.id.txt_locked)
        boxWindows = findViewById(R.id.box_windows)
        btnAddWindow = findViewById(R.id.btn_add_window)
        toggleDays = findViewById(R.id.toggle_days)
        txtScheduleToday = findViewById(R.id.txt_schedule_today)
        // On ouvre sur les horaires du jour en cours
        boxVacation = findViewById(R.id.box_vacation)
        txtVacationDates = findViewById(R.id.txt_vacation_dates)
        btnVacationDates = findViewById(R.id.btn_vacation_dates)
        btnVacationClear = findViewById(R.id.btn_vacation_clear)
        btnVacationDates.setOnClickListener { pickVacationDates() }
        btnVacationClear.setOnClickListener {
            if (!Prefs.canEdit(this)) return@setOnClickListener
            Prefs.clearVacation(this); lastListsKey = ""; refresh()
        }
        // On ouvre sur les horaires du jour en cours
        dayMode = when {
            Prefs.isVacationToday(this) -> 2
            Prefs.isWeekendToday() -> 1
            else -> 0
        }
        showWeekend = dayMode == 1
        toggleDays.check(when (dayMode) { 2 -> R.id.btn_vacation; 1 -> R.id.btn_weekend; else -> R.id.btn_weekdays })
        toggleDays.addOnButtonCheckedListener { _, id, checked ->
            if (!checked) return@addOnButtonCheckedListener
            dayMode = when (id) { R.id.btn_vacation -> 2; R.id.btn_weekend -> 1; else -> 0 }
            showWeekend = dayMode == 1
            lastListsKey = ""
            refresh()
        }
        btnApps = findViewById(R.id.btn_apps)
        txtApps = findViewById(R.id.txt_apps)
        editSite = findViewById(R.id.edit_site)
        btnAddSite = findViewById(R.id.btn_add_site)
        boxSites = findViewById(R.id.box_sites)
        txtQuote = findViewById(R.id.txt_quote)
        statToday = findViewById(R.id.stat_today)
        statStreak = findViewById(R.id.stat_streak)
        statSaved = findViewById(R.id.stat_saved)
        txtPass = findViewById(R.id.txt_pass)
        btnPass = findViewById(R.id.btn_pass)

        txtQuote.text = Encouragements.random(Encouragements.home)
        txtQuote.setOnClickListener { txtQuote.text = Encouragements.random(Encouragements.home) }
        btnPass.setOnClickListener { onPassButton() }
        if (intent.getBooleanExtra(EXTRA_KEPT, false)) showKeptMessage()

        btnService.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Active « stop#app » dans Accessibilité", Toast.LENGTH_LONG).show()
        }
        btnMain.setOnClickListener { onMainButton() }
        btnApps.setOnClickListener {
            if (Prefs.canEdit(this)) startActivity(Intent(this, AppPickerActivity::class.java))
        }
        btnAddSite.setOnClickListener {
            if (!Prefs.canEdit(this)) return@setOnClickListener
            val site = Prefs.normalizeSite(editSite.text.toString())
            if (site.isEmpty()) return@setOnClickListener
            Prefs.setBlockedSites(this, Prefs.blockedSites(this) + site)
            editSite.setText("")
            lastListsKey = ""
            refresh()
        }
        btnAddWindow.setOnClickListener { pickWindow() }

        txtGreeting = findViewById(R.id.txt_greeting)
        txtLevelChip = findViewById(R.id.txt_level_chip)
        statusRing = findViewById(R.id.status_ring)
        txtFocus = findViewById(R.id.txt_focus)
        boxFocusButtons = findViewById(R.id.box_focus_buttons)
        txtLevelNum = findViewById(R.id.txt_level_num)
        txtLevelTitle = findViewById(R.id.txt_level_title)
        txtLevelSub = findViewById(R.id.txt_level_sub)
        levelProgress = findViewById(R.id.level_progress)
        txtBadgesCount = findViewById(R.id.txt_badges_count)
        boxBadges = findViewById(R.id.box_badges)

        findViewById<Button>(R.id.btn_focus_5).setOnClickListener { askFocus(5) }
        findViewById<Button>(R.id.btn_focus_25).setOnClickListener { askFocus(25) }
        findViewById<Button>(R.id.btn_focus_60).setOnClickListener { askFocus(60) }
        findViewById<Button>(R.id.btn_focus_120).setOnClickListener { askFocus(120) }
        findViewById<Button>(R.id.btn_widget).setOnClickListener { addWidget() }
        // Appui long sur « version » : diagnostic Snapchat / YouTube
        findViewById<TextView>(R.id.txt_footer).setOnLongClickListener { showDiagnostic(); true }
        findViewById<Button>(R.id.btn_diagnostic).setOnClickListener { showDiagnostic() }
        switchStrict = findViewById(R.id.switch_focus_strict)
        switchStrict.isChecked = Prefs.focusStrict(this)
        switchStrict.setOnCheckedChangeListener { _, on -> Prefs.setFocusStrict(this, on) }
        // Appui sur « Niv. X » dans l'en-tête : on descend jusqu'à la carte des badges
        txtLevelChip.setOnClickListener {
            val card = findViewById<View>(R.id.card_level)
            val content = findViewById<View>(R.id.content)
            var p = content.parent
            while (p != null && p !is android.widget.ScrollView) p = p.parent
            (p as? android.widget.ScrollView)?.smoothScrollTo(0, content.top + card.top - 24)
        }

        animateEntrance()

        // Autorisation d'afficher les notifications de prévention (Android 13+)
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 42)
        }
    }

    /** Les cartes arrivent les unes après les autres. */
    private fun animateEntrance() {
        val content = findViewById<ViewGroup>(R.id.content)
        for (i in 0 until content.childCount) {
            val v = content.getChildAt(i)
            v.alpha = 0f
            v.translationY = 40f
            v.animate().alpha(1f).translationY(0f)
                .setStartDelay(60L * i).setDuration(380)
                .setInterpolator(DecelerateInterpolator()).start()
        }
    }

    // ---------- Mode Focus ----------

    private fun askFocus(minutes: Int) {
        if (Prefs.inFocus(this)) return
        if (!isServiceEnabled()) {
            Toast.makeText(this, "Active d'abord le service d'accessibilité", Toast.LENGTH_LONG).show()
            return
        }
        val label = QuitActivity.formatMinutes(minutes)
        AlertDialog.Builder(this)
            .setTitle("Lancer $label de Focus ?")
            .setMessage(
                (if (Prefs.focusStrict(this))
                    "Toutes les applications seront bloquées, y compris celles autorisées, même pendant un créneau libre.\n\n"
                else
                    "Seules tes applications autorisées resteront accessibles, même pendant un créneau libre.\n\n") +
                "Une fois lancé, le Focus ne peut pas être arrêté avant la fin.\n\n" +
                "Le téléphone et les appels d'urgence restent disponibles."
            )
            .setPositiveButton("Lancer") { _, _ ->
                Prefs.startFocus(this, minutes)
                StopWidget.updateAll(this, force = true)
                Toast.makeText(this, "Focus lancé. Bon courage !", Toast.LENGTH_LONG).show()
                refresh()
            }
            .setNegativeButton("Pas maintenant", null)
            .show()
    }

    // ---------- Diagnostic ----------

    private fun showDiagnostic() {
        val text = Diagnostic.read(this)
        val tv = TextView(this).apply {
            this.text = text
            setTextIsSelectable(true)
            textSize = 11f
            typeface = android.graphics.Typeface.MONOSPACE
            setPadding(40, 20, 40, 20)
        }
        val scroll = android.widget.ScrollView(this).apply { addView(tv) }
        AlertDialog.Builder(this)
            .setTitle("Diagnostic Snapchat / YouTube")
            .setView(scroll)
            .setPositiveButton("Copier") { _, _ ->
                val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("diagnostic stop#app", text))
                Toast.makeText(this, "Copié. Colle-le dans ta conversation avec Claude.", Toast.LENGTH_LONG).show()
            }
            .setNeutralButton("Effacer") { _, _ -> Diagnostic.clear(this) }
            .setNegativeButton("Fermer", null)
            .show()
    }

    // ---------- Widget ----------

    private fun addWidget() {
        val manager = AppWidgetManager.getInstance(this)
        val provider = ComponentName(this, StopWidget::class.java)
        if (manager.isRequestPinAppWidgetSupported) {
            manager.requestPinAppWidget(provider, null, null)
        } else {
            AlertDialog.Builder(this)
                .setTitle("Ajouter le widget")
                .setMessage("Fais un appui long sur ton écran d'accueil → Widgets → cherche « stop#app » → fais-le glisser où tu veux.")
                .setPositiveButton("OK", null)
                .show()
        }
    }

    // ---------- Niveau et badges ----------

    private fun refreshLevel() {
        val stats = Badges.stats(this)
        val level = Badges.level(stats.xp)
        txtLevelChip.text = "Niveau ${level.number}"
        txtLevelNum.text = level.number.toString()
        txtLevelTitle.text = "Niveau ${level.number} · ${level.name}"
        txtLevelSub.text =
            if (level.to == null) "${stats.xp} XP · niveau maximum atteint"
            else "${stats.xp} XP · encore ${level.remaining} XP pour le niveau ${level.number + 1}"
        levelProgress.setProgressCompat(level.percent, true)

        val unlocked = Badges.unlocked(stats).map { it.id }.toSet()
        txtBadgesCount.text = "${unlocked.size} / ${Badges.all.size}"
        val key = unlocked.sorted().joinToString()
        if (key != lastBadgesKey) {
            lastBadgesKey = key
            fillBadges(unlocked)
        }

        // Annonce des nouveaux badges
        val fresh = Badges.takeNew(this)
        if (fresh.isNotEmpty()) celebrate(fresh)
    }

    private fun fillBadges(unlocked: Set<String>) {
        boxBadges.removeAllViews()
        Badges.all.chunked(4).forEach { rowBadges ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowBadges.forEach { b ->
                val tile = layoutInflater.inflate(R.layout.item_badge, row, false)
                val on = b.id in unlocked
                val emoji = tile.findViewById<TextView>(R.id.badge_emoji)
                emoji.text = if (on) b.emoji else "🔒"
                emoji.setBackgroundResource(if (on) R.drawable.bg_badge_on else R.drawable.bg_badge_off)
                tile.findViewById<TextView>(R.id.badge_name).text = b.name
                tile.alpha = if (on) 1f else 0.55f
                tile.setOnClickListener {
                    Toast.makeText(
                        this,
                        (if (on) "${b.emoji} ${b.name} — débloqué !" else "🔒 ${b.name} : ${b.desc}"),
                        Toast.LENGTH_SHORT
                    ).show()
                }
                row.addView(tile)
            }
            // Complète la dernière ligne pour garder l'alignement
            repeat(4 - rowBadges.size) {
                row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            }
            boxBadges.addView(row)
        }
    }

    private fun celebrate(fresh: List<Badges.Badge>) {
        val lines = fresh.joinToString("\n") { "${it.emoji}  ${it.name} — ${it.desc}" }
        AlertDialog.Builder(this)
            .setTitle(if (fresh.size == 1) "Nouveau badge débloqué" else "${fresh.size} nouveaux badges débloqués")
            .setMessage("$lines\n\nContinue comme ça, tu es sur la bonne voie.")
            .setPositiveButton("Trop bien !", null)
            .show()
        val card = findViewById<View>(R.id.card_level)
        card.animate().scaleX(1.04f).scaleY(1.04f).setDuration(180).withEndAction {
            card.animate().scaleX(1f).scaleY(1f).setDuration(380).setInterpolator(OvershootInterpolator()).start()
        }.start()
    }

    // ---------- Bouton principal ----------

    private fun onMainButton() {
        val now = System.currentTimeMillis()
        when {
            Prefs.inFocus(this) -> return
            !Prefs.isStarted(this) -> {
                if (!isServiceEnabled()) {
                    Toast.makeText(this, "Active d'abord le service d'accessibilité", Toast.LENGTH_LONG).show()
                    return
                }
                AlertDialog.Builder(this)
                    .setTitle("Démarrer stop#app ?")
                    .setMessage(
                        "stop#app sera actif tout le temps, sauf pendant tes créneaux libres.\n\n" +
                        "Lundi → vendredi :\n" +
                        Prefs.freeWindows(this, false).sorted().joinToString("\n") { "• " + it.replace("-", " → ") } +
                        "\n\nSamedi et dimanche :\n" +
                        Prefs.freeWindows(this, true).sorted().joinToString("\n") { "• " + it.replace("-", " → ") } +
                        "\n\nPour modifier les réglages en dehors de ces créneaux, tu devras attendre 5 minutes."
                    )
                    .setPositiveButton("Démarrer") { _, _ -> Prefs.setStarted(this, true); refresh() }
                    .setNegativeButton("Annuler", null)
                    .show()
            }
            Prefs.inPass(this) -> {
                // Reprendre le blocage avant la fin de la pause bonus
                Prefs.endPass(this)
            }
            Prefs.inEditMode(this) -> {
                // Terminer les modifications : le blocage reprend tout de suite
                Prefs.setEditUntil(this, 0)
            }
            Prefs.isBlockingNow(this) -> {
                val req = Prefs.unlockRequestedAt(this)
                when {
                    req == 0L -> Prefs.setUnlockRequestedAt(this, now)
                    now - req >= Prefs.WAIT_MS -> {
                        Prefs.setUnlockRequestedAt(this, 0)
                        Prefs.setEditUntil(this, now + Prefs.EDIT_MS)
                    }
                    else -> Prefs.setUnlockRequestedAt(this, 0)
                }
            }
        }
        refresh()
    }

    // ---------- Pause bonus ----------

    private fun onPassButton() {
        if (Prefs.inFocus(this) || Prefs.passUsedToday(this) || !Prefs.isBlockingNow(this)) return
        AlertDialog.Builder(this)
            .setTitle("Prendre ta pause de 10 min ?")
            .setMessage("Tout sera débloqué pendant 10 minutes. Tu ne peux la prendre qu'une seule fois par jour, alors choisis bien ton moment !")
            .setPositiveButton("C'est parti") { _, _ ->
                if (Prefs.startPass(this)) {
                    Toast.makeText(this, "Bonne pause. Le blocage reprend dans 10 minutes.", Toast.LENGTH_LONG).show()
                }
                refresh()
            }
            .setNegativeButton("Je la garde pour plus tard", null)
            .show()
    }

    private fun showKeptMessage() {
        AlertDialog.Builder(this)
            .setTitle("Bon choix")
            .setMessage("Tu as fait le bon choix. Continue comme ça, tu vas être fier de toi !")
            .setPositiveButton("Merci !", null)
            .show()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra(EXTRA_KEPT, false)) showKeptMessage()
    }

    // ---------- Créneaux libres ----------

    /** Créneaux du mode affiché (semaine, week-end ou vacances). */
    private fun modeWindows(): Set<String> =
        if (dayMode == 2) Prefs.vacationWindows(this) else Prefs.freeWindows(this, dayMode == 1)

    private fun setModeWindows(v: Set<String>) {
        if (dayMode == 2) Prefs.setVacationWindows(this, v) else Prefs.setFreeWindows(this, v, dayMode == 1)
    }

    /** Choix de la période de vacances : date de début, puis date de fin. */
    private fun pickVacationDates() {
        if (!Prefs.canEdit(this)) return
        val now = Calendar.getInstance()
        val key = { y: Int, m: Int, d: Int -> "%04d%02d%02d".format(y, m + 1, d) }
        android.app.DatePickerDialog(this, { _, y1, m1, d1 ->
            android.app.DatePickerDialog(this, { _, y2, m2, d2 ->
                Prefs.setVacation(this, key(y1, m1, d1), key(y2, m2, d2))
                lastListsKey = ""
                refresh()
                Toast.makeText(this, "Vacances enregistrées. Pense à régler leurs horaires.", Toast.LENGTH_LONG).show()
            }, y1, m1, d1).apply { setTitle("Dernier jour des vacances") }.show()
        }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH))
            .apply { setTitle("Premier jour des vacances") }.show()
    }

    private fun pickWindow() {
        if (!Prefs.canEdit(this)) return
        val dayLabel = when (dayMode) { 2 -> "vacances"; 1 -> "week-end"; else -> "lun → ven" }
        TimePickerDialog(this, { _, h1, m1 ->
            TimePickerDialog(this, { _, h2, m2 ->
                if (h1 == h2 && m1 == m2) {
                    Toast.makeText(this, "Le début et la fin sont identiques", Toast.LENGTH_SHORT).show()
                    return@TimePickerDialog
                }
                val w = "%02d:%02d-%02d:%02d".format(h1, m1, h2, m2)
                setModeWindows(modeWindows() + w)
                lastListsKey = ""
                refresh()
            }, (h1 + 2) % 24, m1, true).apply { setTitle("Fin du créneau libre ($dayLabel)") }.show()
        }, 12, 0, true).apply { setTitle("Début du créneau libre ($dayLabel)") }.show()
    }

    // ---------- Affichage ----------

    private fun refresh() {
        val started = Prefs.isStarted(this)
        val canEdit = Prefs.canEdit(this)
        val serviceOn = isServiceEnabled()

        txtService.text = if (serviceOn) "●  Protection en marche" else "●  Service d'accessibilité désactivé"
        btnService.visibility = if (serviceOn) View.GONE else View.VISIBLE

        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        txtGreeting.text = when (hour) {
            in 5..11 -> "Bonjour"
            in 12..17 -> "Bon après-midi"
            else -> "Bonsoir"
        }

        val free = Prefs.currentFreeWindow(this)
        btnMain.visibility = View.VISIBLE
        ringPercent = 100
        when {
            Prefs.inFocus(this) -> {
                val total = (Prefs.focusUntil(this) - System.currentTimeMillis()).coerceAtLeast(0)
                val s = (total / 1000).toInt()
                val h = s / 3600
                val time = if (h > 0) "%d:%02d:%02d".format(h, (s % 3600) / 60, s % 60) else "%d:%02d".format(s / 60, s % 60)
                ringPercent = focusPercent()
                setStatus(R.drawable.ic_focus, time, if (Prefs.focusStrict(this)) "Focus strict · tout est bloqué" else "Focus · seules tes applis autorisées restent ouvertes", R.color.purple, R.color.blue_soft)
                btnMain.visibility = View.GONE
            }
            !started -> {
                setStatus(R.drawable.ic_play, "Prêt à démarrer", "Choisis tes applis et tes sites, puis lance stop#app", R.color.purple, R.color.blue_soft)
                btnMain.text = "Démarrer stop#app"
            }
            Prefs.inEditMode(this) -> {
                val s = ((Prefs.editUntil(this) - System.currentTimeMillis()) / 1000).toInt().coerceAtLeast(0)
                ringPercent = (s * 100 / (Prefs.EDIT_MS / 1000)).toInt()
                setStatus(R.drawable.ic_edit, "Mode modification", "Reblocage automatique dans %d:%02d".format(s / 60, s % 60), R.color.amber, R.color.amber_soft)
                btnMain.text = "Terminer et rebloquer"
            }
            Prefs.inPass(this) -> {
                val s = ((Prefs.passUntil(this) - System.currentTimeMillis()) / 1000).toInt().coerceAtLeast(0)
                ringPercent = (s * 100 / (Prefs.PASS_MS / 1000)).toInt()
                setStatus(R.drawable.ic_coffee, "Pause bonus", "Encore %d:%02d".format(s / 60, s % 60), R.color.green, R.color.green_soft)
                btnMain.text = "Reprendre le blocage maintenant"
            }
            free != null -> {
                setStatus(R.drawable.ic_lock_open, "Créneau libre", "Créneau libre jusqu'à ${free.substringAfter("-")}", R.color.green, R.color.green_soft)
                btnMain.visibility = View.GONE
            }
            else -> {
                val next = Prefs.nextFreeStart(this)
                val req = Prefs.unlockRequestedAt(this)
                val left = Prefs.WAIT_MS - (System.currentTimeMillis() - req)
                when {
                    req == 0L -> {
                        val inMin = Prefs.minutesToNextFree(this)
                        val sub = if (next != null && inMin != null)
                            "Prochaine pause : $next · dans ${QuitActivity.formatMinutes(inMin)}"
                        else "Blocage en cours"
                        setStatus(R.drawable.ic_lock, "Blocage actif", sub, R.color.red, R.color.red_soft)
                        btnMain.text = "Demander à modifier · 5 min"
                    }
                    left > 0 -> {
                        val s = (left / 1000).toInt()
                        ringPercent = 100 - (s * 100 / (Prefs.WAIT_MS / 1000)).toInt()
                        setStatus(R.drawable.ic_hourglass, "%d:%02d".format(s / 60, s % 60), "Encore un peu de patience…", R.color.amber, R.color.amber_soft)
                        btnMain.text = "Annuler la demande"
                    }
                    else -> {
                        setStatus(R.drawable.ic_check_circle, "Accès autorisé", "Tu peux modifier pendant 10 minutes", R.color.green, R.color.green_soft)
                        btnMain.text = "Modifier maintenant"
                    }
                }
            }
        }

        // Statistiques
        statToday.text = Prefs.blocksToday(this).toString()
        statStreak.text = Prefs.streak(this).toString()
        statSaved.text = QuitActivity.formatMinutes(Prefs.blocksTotal(this) * Prefs.MINUTES_PER_BLOCK)

        // Pause bonus
        when {
            Prefs.inPass(this) -> {
                txtPass.text = "En cours · le blocage reprend automatiquement à la fin"
                btnPass.text = "Pause en cours"
                btnPass.isEnabled = false
            }
            Prefs.passUsedToday(this) -> {
                txtPass.text = "Déjà utilisée aujourd'hui · disponible demain"
                btnPass.text = "Utilisée"
                btnPass.isEnabled = false
            }
            !Prefs.isBlockingNow(this) -> {
                txtPass.text = "10 minutes libres, une fois par jour"
                btnPass.text = "Disponible pendant le blocage"
                btnPass.isEnabled = false
            }
            else -> {
                txtPass.text = "10 minutes libres, une fois par jour"
                btnPass.text = "Utiliser ma pause de 10 min"
                btnPass.isEnabled = true
            }
        }

        // Carte Focus
        if (Prefs.inFocus(this)) {
            txtFocus.text = "Session en cours"
            boxFocusButtons.visibility = View.GONE
            switchStrict.isEnabled = false
        } else {
            switchStrict.isEnabled = true
            val n = Prefs.focusSessions(this)
            txtFocus.text = if (n == 0) "Seules tes applis autorisées restent ouvertes"
                else "$n session(s) effectuée(s)"
            boxFocusButtons.visibility = View.VISIBLE
        }
        if (Prefs.inFocus(this)) {
            btnPass.isEnabled = false
            txtPass.text = "Indisponible pendant le Focus"
        }

        refreshLevel()
        StopWidget.updateAll(this)

        txtLocked.visibility = if (canEdit) View.GONE else View.VISIBLE
        btnApps.isEnabled = canEdit
        btnAddWindow.isEnabled = canEdit
        editSite.isEnabled = canEdit
        btnAddSite.isEnabled = canEdit
        val n = Prefs.allowedApps(this).size
        txtApps.text = if (n == 0) "Aucune application autorisée" else "$n application(s) autorisée(s)"

        // Reconstruit les listes seulement si quelque chose a changé
        txtScheduleToday.text = when {
            Prefs.isVacationToday(this) -> "Aujourd'hui : vacances (jusqu'au ${Prefs.prettyDay(Prefs.vacationEnd(this))})"
            Prefs.isWeekendToday() -> "Aujourd'hui : horaires du week-end"
            else -> "Aujourd'hui : horaires de la semaine"
        }
        // Bloc des dates de vacances (visible seulement sur l'onglet Vacances)
        boxVacation.visibility = if (dayMode == 2) View.VISIBLE else View.GONE
        txtVacationDates.text = if (Prefs.hasVacation(this))
            "Du ${Prefs.prettyDay(Prefs.vacationStart(this))} au ${Prefs.prettyDay(Prefs.vacationEnd(this))}"
        else "Aucune période de vacances définie"
        btnVacationDates.text = if (Prefs.hasVacation(this)) "Modifier les dates" else "Choisir les dates"
        btnVacationDates.isEnabled = canEdit
        btnVacationClear.visibility = if (Prefs.hasVacation(this)) View.VISIBLE else View.GONE
        btnVacationClear.isEnabled = canEdit
        val windows = modeWindows().sortedBy { Prefs.parseWindow(it)?.first ?: 0 }
        val sites = Prefs.blockedSites(this).sorted()
        val key = "$canEdit|$dayMode|$windows|$sites"
        if (key != lastListsKey) {
            lastListsKey = key
            fillList(boxWindows, "", windows.map { it.replace("-", "  →  ").replace(":", "h") }, windows, canEdit, "Aucun créneau libre") { w ->
                setModeWindows(modeWindows() - w)
            }
            fillList(boxSites, "", sites, sites, canEdit, "Aucun site bloqué pour l'instant") { s ->
                Prefs.setBlockedSites(this, Prefs.blockedSites(this) - s)
            }
        }
    }

    /** Met à jour la grande carte de statut (emoji, titre, sous-titre, couleurs). */
    private var ringPercent = 100

    private fun focusPercent(): Int {
        val left = (Prefs.focusUntil(this) - System.currentTimeMillis()).coerceAtLeast(0)
        return (left * 100 / Prefs.focusTotalMs(this)).toInt().coerceIn(0, 100)
    }

    private fun setStatus(icon: Int, title: String, sub: String, color: Int, soft: Int) {
        statusRing.setIndicatorColor(getColor(color))
        statusRing.trackColor = getColor(soft)
        statusRing.setProgressCompat(ringPercent, true)
        if (currentIcon != icon) {
            currentIcon = icon
            statusIcon.setImageResource(icon)
            statusIcon.scaleX = 0.6f; statusIcon.scaleY = 0.6f
            statusIcon.animate().scaleX(1f).scaleY(1f).setDuration(350)
                .setInterpolator(OvershootInterpolator()).start()
        }
        statusIcon.imageTintList = android.content.res.ColorStateList.valueOf(getColor(color))
        statusIcon.background.mutate().setTint(getColor(soft))
        txtStatus.text = title
        txtStatus.setTextColor(getColor(color))
        txtStatusSub.text = sub
        btnMain.backgroundTintList = android.content.res.ColorStateList.valueOf(getColor(color))
    }

    /** Remplit une liste de lignes arrondies avec un bouton ✕ (actif seulement si modifiable). */
    private fun fillList(box: LinearLayout, icon: String, labels: List<String>, values: List<String>, canEdit: Boolean, empty: String, onRemove: (String) -> Unit) {
        box.removeAllViews()
        if (labels.isEmpty()) {
            box.addView(TextView(this).apply {
                text = empty
                setTextColor(getColor(R.color.ink_soft))
                setPadding(4, 4, 4, 12)
            })
            return
        }
        val inflater = layoutInflater
        labels.forEachIndexed { i, label ->
            val row = inflater.inflate(R.layout.item_row, box, false)
            row.findViewById<TextView>(R.id.row_icon).apply { text = icon; visibility = if (icon.isEmpty()) View.GONE else View.VISIBLE }
            row.findViewById<TextView>(R.id.row_label).text = label
            val remove = row.findViewById<TextView>(R.id.row_remove)
            remove.visibility = if (canEdit) View.VISIBLE else View.INVISIBLE
            remove.setOnClickListener {
                if (Prefs.canEdit(this@MainActivity)) {
                    onRemove(values[i]); lastListsKey = ""; refresh()
                }
            }
            box.addView(row)
        }
    }

    private fun isServiceEnabled(): Boolean {
        val expected = ComponentName(this, BlockService::class.java).flattenToString()
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabled)
        while (splitter.hasNext()) {
            if (splitter.next().equals(expected, ignoreCase = true)) return true
        }
        return false
    }

    override fun onResume() {
        super.onResume()
        lastListsKey = ""
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
    }
}
