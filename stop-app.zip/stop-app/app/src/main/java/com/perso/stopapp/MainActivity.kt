package com.perso.stopapp

import android.app.TimePickerDialog
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    companion object {
        /** Mis par l'écran « Tu es sûr ? » quand tu as choisi de garder stop#app. */
        const val EXTRA_KEPT = "kept"
    }

    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1000)
        }
    }

    private lateinit var txtStatus: TextView
    private lateinit var txtStatusEmoji: TextView
    private lateinit var txtStatusSub: TextView
    private lateinit var txtService: TextView
    private lateinit var btnService: Button
    private lateinit var btnMain: Button
    private lateinit var txtLocked: TextView
    private lateinit var boxWindows: LinearLayout
    private lateinit var btnAddWindow: Button
    private lateinit var btnApps: Button
    private lateinit var txtApps: TextView
    private lateinit var editSite: EditText
    private lateinit var btnAddSite: Button
    private lateinit var boxSites: LinearLayout
    private lateinit var txtQuote: TextView
    private lateinit var statToday: TextView
    private lateinit var statStreak: TextView
    private lateinit var statSaved: TextView
    private lateinit var txtPass: TextView
    private lateinit var btnPass: Button

    private var lastListsKey = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtStatus = findViewById(R.id.txt_status)
        txtStatusEmoji = findViewById(R.id.txt_status_emoji)
        txtStatusSub = findViewById(R.id.txt_status_sub)
        txtService = findViewById(R.id.txt_service)
        btnService = findViewById(R.id.btn_service)
        btnMain = findViewById(R.id.btn_main)
        txtLocked = findViewById(R.id.txt_locked)
        boxWindows = findViewById(R.id.box_windows)
        btnAddWindow = findViewById(R.id.btn_add_window)
        btnApps = findViewById(R.id.btn_apps)
        txtApps = findViewById(R.id.txt_apps)
        editSite = findViewById(R.id.edit_site)
        btnAddSite = findViewById(R.id.btn_add_site)
        boxSites = findViewById(R.id.box_sites)
        txtQuote = findViewById(R.id.txt_quote)
        statToday = findViewById(R.id.stat_today)
        statStreak = findViewById(R.id.stat_streak)
        statSaved = findViewById(R.id.stat_saved)
        txtPass = findViewById(R.id.txt_pass)
        btnPass = findViewById(R.id.btn_pass)

        txtQuote.text = Encouragements.random(Encouragements.home)
        txtQuote.setOnClickListener { txtQuote.text = Encouragements.random(Encouragements.home) }
        btnPass.setOnClickListener { onPassButton() }
        if (intent.getBooleanExtra(EXTRA_KEPT, false)) showKeptMessage()

        btnService.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Active « stop#app » dans Accessibilité", Toast.LENGTH_LONG).show()
        }
        btnMain.setOnClickListener { onMainButton() }
        btnApps.setOnClickListener {
            if (Prefs.canEdit(this)) startActivity(Intent(this, AppPickerActivity::class.java))
        }
        btnAddSite.setOnClickListener {
            if (!Prefs.canEdit(this)) return@setOnClickListener
            val site = Prefs.normalizeSite(editSite.text.toString())
            if (site.isEmpty()) return@setOnClickListener
            Prefs.setBlockedSites(this, Prefs.blockedSites(this) + site)
            editSite.setText("")
            lastListsKey = ""
            refresh()
        }
        btnAddWindow.setOnClickListener { pickWindow() }
    }

    // ---------- Bouton principal ----------

    private fun onMainButton() {
        val now = System.currentTimeMillis()
        when {
            !Prefs.isStarted(this) -> {
                if (!isServiceEnabled()) {
                    Toast.makeText(this, "Active d'abord le service d'accessibilité", Toast.LENGTH_LONG).show()
                    return
                }
                AlertDialog.Builder(this)
                    .setTitle("Démarrer stop#app ?")
                    .setMessage(
                        "stop#app sera actif tout le temps, sauf pendant tes créneaux libres :\n" +
                        Prefs.freeWindows(this).sorted().joinToString("\n") { "• " + it.replace("-", " → ") } +
                        "\n\nPour modifier les réglages en dehors de ces créneaux, tu devras attendre 5 minutes."
                    )
                    .setPositiveButton("Démarrer") { _, _ -> Prefs.setStarted(this, true); refresh() }
                    .setNegativeButton("Annuler", null)
                    .show()
            }
            Prefs.inPass(this) -> {
                // Reprendre le blocage avant la fin de la pause bonus
                Prefs.endPass(this)
            }
            Prefs.inEditMode(this) -> {
                // Terminer les modifications : le blocage reprend tout de suite
                Prefs.setEditUntil(this, 0)
            }
            Prefs.isBlockingNow(this) -> {
                val req = Prefs.unlockRequestedAt(this)
                when {
                    req == 0L -> Prefs.setUnlockRequestedAt(this, now)
                    now - req >= Prefs.WAIT_MS -> {
                        Prefs.setUnlockRequestedAt(this, 0)
                        Prefs.setEditUntil(this, now + Prefs.EDIT_MS)
                    }
                    else -> Prefs.setUnlockRequestedAt(this, 0)
                }
            }
        }
        refresh()
    }

    // ---------- Pause bonus ----------

    private fun onPassButton() {
        if (Prefs.passUsedToday(this) || !Prefs.isBlockingNow(this)) return
        AlertDialog.Builder(this)
            .setTitle("☕ Prendre ta pause de 20 min ?")
            .setMessage("Tout sera débloqué pendant 20 minutes. Tu ne peux la prendre qu'une seule fois par jour, alors choisis bien ton moment !")
            .setPositiveButton("C'est parti") { _, _ ->
                if (Prefs.startPass(this)) {
                    Toast.makeText(this, "Bonne pause ! Le blocage revient dans 20 min ⏳", Toast.LENGTH_LONG).show()
                }
                refresh()
            }
            .setNegativeButton("Je la garde pour plus tard", null)
            .show()
    }

    private fun showKeptMessage() {
        AlertDialog.Builder(this)
            .setTitle("Bravo 💪")
            .setMessage("Tu as fait le bon choix. Continue comme ça, tu vas être fier de toi !")
            .setPositiveButton("Merci !", null)
            .show()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra(EXTRA_KEPT, false)) showKeptMessage()
    }

    // ---------- Créneaux libres ----------

    private fun pickWindow() {
        if (!Prefs.canEdit(this)) return
        TimePickerDialog(this, { _, h1, m1 ->
            TimePickerDialog(this, { _, h2, m2 ->
                if (h1 == h2 && m1 == m2) {
                    Toast.makeText(this, "Le début et la fin sont identiques", Toast.LENGTH_SHORT).show()
                    return@TimePickerDialog
                }
                val w = "%02d:%02d-%02d:%02d".format(h1, m1, h2, m2)
                Prefs.setFreeWindows(this, Prefs.freeWindows(this) + w)
                lastListsKey = ""
                refresh()
            }, (h1 + 2) % 24, m1, true).apply { setTitle("Fin du créneau libre") }.show()
        }, 12, 0, true).apply { setTitle("Début du créneau libre") }.show()
    }

    // ---------- Affichage ----------

    private fun refresh() {
        val started = Prefs.isStarted(this)
        val canEdit = Prefs.canEdit(this)
        val serviceOn = isServiceEnabled()

        txtService.text = if (serviceOn) "●  Protection en marche" else "●  Service d'accessibilité désactivé"
        btnService.visibility = if (serviceOn) View.GONE else View.VISIBLE

        val free = Prefs.currentFreeWindow(this)
        btnMain.visibility = View.VISIBLE
        when {
            !started -> {
                setStatus("🚀", "Prêt à démarrer", "Choisis tes applis et tes sites, puis lance stop#app", R.color.purple, R.color.blue_soft)
                btnMain.text = "Démarrer stop#app"
            }
            Prefs.inEditMode(this) -> {
                val s = ((Prefs.editUntil(this) - System.currentTimeMillis()) / 1000).toInt().coerceAtLeast(0)
                setStatus("✏️", "Mode modification", "Reblocage automatique dans %d:%02d".format(s / 60, s % 60), R.color.amber, R.color.amber_soft)
                btnMain.text = "Terminer et rebloquer"
            }
            Prefs.inPass(this) -> {
                val s = ((Prefs.passUntil(this) - System.currentTimeMillis()) / 1000).toInt().coerceAtLeast(0)
                setStatus("☕", "Pause bonus", "Encore %d:%02d, profites-en bien".format(s / 60, s % 60), R.color.green, R.color.green_soft)
                btnMain.text = "Reprendre le blocage maintenant"
            }
            free != null -> {
                setStatus("😌", "Pause", "Créneau libre jusqu'à ${free.substringAfter("-")}", R.color.green, R.color.green_soft)
                btnMain.visibility = View.GONE
            }
            else -> {
                val next = Prefs.nextFreeStart(this)
                val req = Prefs.unlockRequestedAt(this)
                val left = Prefs.WAIT_MS - (System.currentTimeMillis() - req)
                when {
                    req == 0L -> {
                        val inMin = Prefs.minutesToNextFree(this)
                        val sub = if (next != null && inMin != null)
                            "Prochaine pause à $next · dans ${QuitActivity.formatMinutes(inMin)}"
                        else "Concentre-toi 💪"
                        setStatus("🔒", "Blocage actif", sub, R.color.red, R.color.red_soft)
                        btnMain.text = "Demander à modifier · 5 min"
                    }
                    left > 0 -> {
                        val s = (left / 1000).toInt()
                        setStatus("⏳", "%d:%02d".format(s / 60, s % 60), "Encore un peu de patience…", R.color.amber, R.color.amber_soft)
                        btnMain.text = "Annuler la demande"
                    }
                    else -> {
                        setStatus("✅", "C'est bon", "Tu peux modifier pendant 10 minutes", R.color.green, R.color.green_soft)
                        btnMain.text = "Modifier maintenant"
                    }
                }
            }
        }

        // Statistiques
        statToday.text = Prefs.blocksToday(this).toString()
        statStreak.text = Prefs.streak(this).toString()
        statSaved.text = QuitActivity.formatMinutes(Prefs.blocksTotal(this) * Prefs.MINUTES_PER_BLOCK)

        // Pause bonus
        when {
            Prefs.inPass(this) -> {
                txtPass.text = "En cours ☕ — le blocage revient tout seul à la fin"
                btnPass.text = "Pause en cours"
                btnPass.isEnabled = false
            }
            Prefs.passUsedToday(this) -> {
                txtPass.text = "Déjà utilisée aujourd'hui. Elle revient demain 🌙"
                btnPass.text = "Utilisée ✓"
                btnPass.isEnabled = false
            }
            !Prefs.isBlockingNow(this) -> {
                txtPass.text = "20 minutes libres, une fois par jour"
                btnPass.text = "Disponible pendant le blocage"
                btnPass.isEnabled = false
            }
            else -> {
                txtPass.text = "20 minutes libres, une fois par jour"
                btnPass.text = "☕  Utiliser ma pause de 20 min"
                btnPass.isEnabled = true
            }
        }

        txtLocked.visibility = if (canEdit) View.GONE else View.VISIBLE
        btnApps.isEnabled = canEdit
        btnAddWindow.isEnabled = canEdit
        editSite.isEnabled = canEdit
        btnAddSite.isEnabled = canEdit
        val n = Prefs.allowedApps(this).size
        txtApps.text = if (n == 0) "Aucune application autorisée" else "$n application(s) autorisée(s)"

        // Reconstruit les listes seulement si quelque chose a changé
        val windows = Prefs.freeWindows(this).sortedBy { Prefs.parseWindow(it)?.first ?: 0 }
        val sites = Prefs.blockedSites(this).sorted()
        val key = "$canEdit|$windows|$sites"
        if (key != lastListsKey) {
            lastListsKey = key
            fillList(boxWindows, "☀️", windows.map { it.replace("-", "  →  ").replace(":", "h") }, windows, canEdit, "Aucun créneau libre") { w ->
                Prefs.setFreeWindows(this, Prefs.freeWindows(this) - w)
            }
            fillList(boxSites, "🚫", sites, sites, canEdit, "Aucun site bloqué pour l'instant") { s ->
                Prefs.setBlockedSites(this, Prefs.blockedSites(this) - s)
            }
        }
    }

    /** Met à jour la grande carte de statut (emoji, titre, sous-titre, couleurs). */
    private fun setStatus(emoji: String, title: String, sub: String, color: Int, soft: Int) {
        txtStatusEmoji.text = emoji
        txtStatusEmoji.background.mutate().setTint(getColor(soft))
        txtStatus.text = title
        txtStatus.setTextColor(getColor(color))
        txtStatusSub.text = sub
        btnMain.backgroundTintList = android.content.res.ColorStateList.valueOf(getColor(color))
    }

    /** Remplit une liste de lignes arrondies avec un bouton ✕ (actif seulement si modifiable). */
    private fun fillList(box: LinearLayout, icon: String, labels: List<String>, values: List<String>, canEdit: Boolean, empty: String, onRemove: (String) -> Unit) {
        box.removeAllViews()
        if (labels.isEmpty()) {
            box.addView(TextView(this).apply {
                text = empty
                setTextColor(getColor(R.color.ink_soft))
                setPadding(4, 4, 4, 12)
            })
            return
        }
        val inflater = layoutInflater
        labels.forEachIndexed { i, label ->
            val row = inflater.inflate(R.layout.item_row, box, false)
            row.findViewById<TextView>(R.id.row_icon).text = icon
            row.findViewById<TextView>(R.id.row_label).text = label
            val remove = row.findViewById<TextView>(R.id.row_remove)
            remove.visibility = if (canEdit) View.VISIBLE else View.INVISIBLE
            remove.setOnClickListener {
                if (Prefs.canEdit(this@MainActivity)) {
                    onRemove(values[i]); lastListsKey = ""; refresh()
                }
            }
            box.addView(row)
        }
    }

    private fun isServiceEnabled(): Boolean {
        val expected = ComponentName(this, BlockService::class.java).flattenToString()
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabled)
        while (splitter.hasNext()) {
            if (splitter.next().equals(expected, ignoreCase = true)) return true
        }
        return false
    }

    override fun onResume() {
        super.onResume()
        lastListsKey = ""
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
    }
}
