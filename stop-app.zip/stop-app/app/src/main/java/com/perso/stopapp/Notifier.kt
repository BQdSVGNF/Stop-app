package com.perso.stopapp

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

/**
 * Notifications de prévention : préviennent AVANT que le blocage reprenne,
 * et quand un créneau libre commence.
 * Vérifié toutes les 30 secondes par le service de blocage.
 */
object Notifier {

    private const val CHANNEL = "prevention"
    private const val PREFS = "stopapp_notif"

    /** Minutes d'avance pour prévenir de la fin d'un créneau libre. */
    private const val WARN_FREE_MIN = 5

    fun ensureChannel(c: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = c.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CHANNEL) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL, "Prévention", NotificationManager.IMPORTANCE_DEFAULT).apply {
                        description = "Prévient avant que le blocage reprenne"
                    }
                )
            }
        }
    }

    private fun canPost(c: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun post(c: Context, id: Int, title: String, text: String) {
        if (!canPost(c)) return
        ensureChannel(c)
        val open = PendingIntent.getActivity(
            c, 1, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(c, CHANNEL)
            .setSmallIcon(R.drawable.ic_w_lock)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .setColor(0xFFFF416C.toInt())
            .build()
        runCatching { NotificationManagerCompat.from(c).notify(id, n) }
    }

    /** Envoie une notification une seule fois pour une clé donnée (ex. "free-end-20261023-1730"). */
    private fun once(c: Context, key: String, id: Int, title: String, text: String) {
        val sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (sp.getString("last_$id", "") == key) return
        sp.edit().putString("last_$id", key).apply()
        post(c, id, title, text)
    }

    /** Appelé régulièrement par le service : regarde ce qui va se passer et prévient. */
    fun check(c: Context) {
        if (!Prefs.isStarted(c)) return
        val now = System.currentTimeMillis()
        val day = Prefs.today()

        // 1) Fin d'un créneau libre dans 5 minutes
        val free = Prefs.currentFreeWindow(c)
        if (free != null && !Prefs.inFocus(c)) {
            val end = Prefs.parseWindow(free)?.second
            if (end != null) {
                val left = (end - Prefs.nowMinutes() + 1440) % 1440
                if (left in 1..WARN_FREE_MIN) {
                    once(c, "free-end-$day-$free", 10,
                        "Le blocage reprend dans $left min",
                        "Ton créneau libre se termine à ${free.substringAfter("-")}. Termine ce que tu fais.")
                }
            }
            // 2) Début d'un créneau libre
            once(c, "free-start-$day-$free", 11,
                "Créneau libre",
                "Tu es libre jusqu'à ${free.substringAfter("-")}. Profites-en bien.")
        }

        // 3) Fin de la pause bonus dans 1 minute
        if (Prefs.inPass(c)) {
            val left = Prefs.passUntil(c) - now
            if (left in 1..60_000) {
                once(c, "pass-end-${Prefs.passUntil(c)}", 12,
                    "Fin de la pause bonus dans 1 min",
                    "Le blocage reprend juste après.")
            }
        }

        // 4) Fin du mode modification dans 1 minute
        if (Prefs.inEditMode(c)) {
            val left = Prefs.editUntil(c) - now
            if (left in 1..60_000) {
                once(c, "edit-end-${Prefs.editUntil(c)}", 13,
                    "Modification bientôt terminée",
                    "Il te reste moins d'une minute pour changer tes réglages.")
            }
        }

        // 5) Fin de la session Focus
        val focusEnd = Prefs.focusUntil(c)
        if (focusEnd in 1..now && now - focusEnd < 5 * 60_000) {
            once(c, "focus-end-$focusEnd", 14,
                "Session Focus terminée",
                "Bravo, tu as tenu jusqu'au bout.")
        }
    }
}
