package com.perso.stopapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

/**
 * Écran affiché quand on essaie de désinstaller stop#app :
 * on rappelle tes progrès et on te propose de changer d'avis.
 * Si tu insistes, il faut attendre 30 secondes avant de pouvoir désinstaller.
 */
class QuitActivity : AppCompatActivity() {

    private var timer: CountDownTimer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quit)

        val total = Prefs.blocksTotal(this)
        val streak = Prefs.streak(this)
        val minutes = total * Prefs.MINUTES_PER_BLOCK

        findViewById<TextView>(R.id.quit_quote).text = Encouragements.random(Encouragements.quit)
        findViewById<TextView>(R.id.quit_stats).text = buildString {
            append("Depuis que tu utilises stop#app :\n")
            append("🔥 $streak jour(s) d'affilée\n")
            append("🛡️ $total tentative(s) évitée(s)\n")
            append("⏱️ environ ${formatMinutes(minutes)} gagnées")
        }

        val keep = findViewById<MaterialButton>(R.id.btn_keep)
        val leave = findViewById<MaterialButton>(R.id.btn_leave)
        val countdown = findViewById<TextView>(R.id.quit_countdown)

        keep.setOnClickListener { keepApp() }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = keepApp()
        })

        leave.setOnClickListener {
            leave.isEnabled = false
            countdown.visibility = View.VISIBLE
            timer = object : CountDownTimer(30_000, 1_000) {
                override fun onTick(ms: Long) {
                    countdown.text = "Prends 30 secondes pour y réfléchir… ${(ms / 1000) + 1}"
                }
                override fun onFinish() {
                    countdown.text = "D'accord. C'est ton choix, et il est respecté."
                    leave.text = "Désinstaller stop#app"
                    leave.isEnabled = true
                    leave.setOnClickListener { uninstall() }
                }
            }.start()
        }
    }

    private fun keepApp() {
        timer?.cancel()
        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra(MainActivity.EXTRA_KEPT, true)
        )
        finish()
    }

    private fun uninstall() {
        Prefs.allowUninstallFor(this, 2 * 60 * 1000L)
        startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$packageName")))
        finish()
    }

    override fun onDestroy() {
        timer?.cancel()
        super.onDestroy()
    }

    companion object {
        fun formatMinutes(m: Int): String =
            if (m < 60) "$m min" else "${m / 60} h ${"%02d".format(m % 60)}"
    }
}
