package com.perso.stopapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.CountDownTimer
import android.provider.Settings
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

/**
 * Questionnaire affiché quand on essaie de désinstaller stop#app ou d'ouvrir
 * sa page dans les Paramètres. Il propose des alternatives, rappelle les progrès,
 * puis — si on insiste — laisse 30 secondes de réflexion avant de donner l'accès.
 */
class QuitActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_MODE = "mode"
        const val MODE_UNINSTALL = "uninstall"
        const val MODE_SETTINGS = "settings"

        /** Durée pendant laquelle l'accès est libre une fois le questionnaire terminé. */
        private const val ACCESS_MS = 5 * 60 * 1000L

        fun formatMinutes(m: Int): String =
            if (m < 60) "$m min" else "${m / 60} h ${"%02d".format(m % 60)}"
    }

    private var timer: CountDownTimer? = null
    private var mode = MODE_UNINSTALL
    private var openedAt = 0L

    private lateinit var title: TextView
    private lateinit var subtitle: TextView
    private lateinit var stats: TextView
    private lateinit var options: LinearLayout
    private lateinit var countdown: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quit)
        title = findViewById(R.id.quit_title)
        subtitle = findViewById(R.id.quit_quote)
        stats = findViewById(R.id.quit_stats)
        options = findViewById(R.id.quit_options)
        countdown = findViewById(R.id.quit_countdown)

        findViewById<MaterialButton>(R.id.btn_keep).setOnClickListener { keepApp() }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // On ignore un « retour » qui arrive juste à l'ouverture (il ne vient pas de toi)
                if (System.currentTimeMillis() - openedAt < 1500) return
                keepApp()
            }
        })
        start(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        start(intent)
    }

    private fun start(i: Intent) {
        timer?.cancel()
        openedAt = System.currentTimeMillis()
        mode = i.getStringExtra(EXTRA_MODE) ?: MODE_UNINSTALL
        stepWhat()
    }

    // ---------- Étape 1 : que veux-tu faire ? ----------

    private fun stepWhat() {
        title.text = "Qu'est-ce que tu veux faire ?"
        subtitle.text = if (mode == MODE_SETTINGS)
            "Tu ouvres les réglages de stop#app dans les Paramètres du téléphone."
        else "Tu essaies de désinstaller stop#app."
        stats.visibility = View.GONE
        countdown.visibility = View.GONE
        setOptions(
            "Modifier mes horaires ou mes applis" to {
                Toast.makeText(this, "Dans stop#app : « Demander à modifier », puis 5 min d'attente.", Toast.LENGTH_LONG).show()
                openMain()
            },
            "Faire une pause" to {
                Toast.makeText(this, "Utilise ta pause bonus de 10 min dans stop#app.", Toast.LENGTH_LONG).show()
                openMain()
            },
            (if (mode == MODE_SETTINGS) "Arrêter ou désactiver stop#app" else "Désinstaller stop#app") to { stepWhy() },
            "Rien, je me suis trompé" to { keepApp() }
        )
    }

    // ---------- Étape 2 : pourquoi ? ----------

    private fun stepWhy() {
        title.text = "Pourquoi veux-tu arrêter ?"
        subtitle.text = "Ta réponse aide à trouver une meilleure solution."
        setOptions(
            "Il me bloque trop souvent" to {
                stepAdvice("Tu peux ajouter des créneaux libres ou autoriser plus d'applis, sans tout arrêter.")
            },
            "Il y a un bug" to {
                stepAdvice("Une mise à jour peut corriger le problème. Décris-le pour qu'il soit réglé, au lieu de perdre tes progrès.")
            },
            "Je n'en ai plus besoin" to { stepProgress() },
            "Autre raison" to { stepProgress() }
        )
    }

    private fun stepAdvice(text: String) {
        title.text = "Une autre solution ?"
        subtitle.text = text
        setOptions(
            "Ajuster mes réglages" to { openMain() },
            "Continuer quand même" to { stepProgress() }
        )
    }

    // ---------- Étape 3 : tes progrès ----------

    private fun stepProgress() {
        val total = Prefs.blocksTotal(this)
        val streak = Prefs.streak(this)
        val level = Badges.level(Badges.stats(this).xp)
        title.text = "Regarde ce que tu as accompli"
        subtitle.text = Encouragements.random(Encouragements.quit)
        stats.visibility = View.VISIBLE
        stats.text = buildString {
            append("• $streak jour(s) consécutif(s)\n")
            append("• $total tentative(s) évitée(s)\n")
            append("• environ ${formatMinutes(total * Prefs.MINUTES_PER_BLOCK)} de temps gagné\n")
            append("• niveau ${level.number} · ${level.name}")
        }
        setOptions("Continuer quand même" to { stepWait() })
    }

    // ---------- Étape 4 : 30 secondes de réflexion ----------

    private fun stepWait() {
        title.text = "Prends 30 secondes"
        subtitle.text = "Respire. Si tu veux toujours continuer après, l'accès sera libre pendant 5 minutes."
        stats.visibility = View.GONE
        countdown.visibility = View.VISIBLE
        options.removeAllViews()
        timer = object : CountDownTimer(30_000, 1_000) {
            override fun onTick(ms: Long) {
                countdown.text = "${(ms / 1000) + 1}"
            }
            override fun onFinish() {
                countdown.text = "C'est ton choix, il est respecté."
                setOptions(
                    (if (mode == MODE_SETTINGS) "Ouvrir les paramètres de stop#app" else "Désinstaller stop#app") to { grantAccess() }
                )
            }
        }.start()
    }

    private fun grantAccess() {
        Prefs.allowUninstallFor(this, ACCESS_MS)
        val i = if (mode == MODE_SETTINGS)
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        else Intent(Intent.ACTION_DELETE, Uri.parse("package:$packageName"))
        startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }

    // ---------- Outils ----------

    private fun setOptions(vararg items: Pair<String, () -> Unit>) {
        options.removeAllViews()
        items.forEach { (label, action) ->
            val b = layoutInflater.inflate(R.layout.item_quit_option, options, false) as MaterialButton
            b.text = label
            b.setOnClickListener { action() }
            options.addView(b)
        }
        options.alpha = 0f
        options.animate().alpha(1f).setDuration(250).start()
    }

    private fun openMain() {
        timer?.cancel()
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
        finish()
    }

    private fun keepApp() {
        timer?.cancel()
        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra(MainActivity.EXTRA_KEPT, true)
        )
        finish()
    }

    override fun onDestroy() {
        timer?.cancel()
        super.onDestroy()
    }
}
